package celestial;

import java.nio.charset.StandardCharsets;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AutoReconnect extends Module {
   public Object[] id_break;
   private static byte[] id_byte;
   private static short[] id_protected;
   private static long[] id_throws;
   private static String[] id_catch;
   private static boolean[] id_private;

   public AutoReconnect() {
      super(id_catch[0], id_catch[1], (Category)Category.staticFieldse67813cd60183787b1de54ac6b91c916[id_protected[0]]);
      this.id_continue();
   }

   private static void ntfClinit() {
      id_new();
      id_public();
      id_else();
      id_super();
      id_return();
   }

   static {
      ntfClinit();
   }

   private void id_this() {
      this.id_continue();
      PI var1 = C_throws.id_byte().id_native().id_protected();
      if (var1 != null) {
         Pf_1 var2 = var1.id_class();
         if (var2.id_break()) {
            String var7 = var2.id_class() + var1.id_break();
            this.id_break[id_protected[6]] = var7;
         } else if (!rql_3.id_break((String)this.id_break[id_protected[7]])
            && (Integer)((cb_3)id_import.id_class[id_protected[8]]).id_throws[id_protected[9]] != 0
            && (Integer)((cb_3)id_import.id_class[id_protected[10]]).id_throws[id_protected[11]] % id_byte[0] == 0) {
            ((cb_3)id_import.id_class[id_protected[12]]).id_case("/" + (String)this.id_break[id_protected[13]]);
         }
      }
   }

   private void id_class(SL var1) {
      this.id_continue();
      String var2 = C_throws.id_byte().id_final().id_throws();
      if (!rql_3.id_break(var2)) {
         String var7 = var2;
         this.id_break[id_protected[17]] = var7;
      } else if (!rql_3.id_break((String)this.id_break[id_protected[18]])) {
         var1.id_class(new SF((String)this.id_break[id_protected[19]], id_throws[1]));
      }
   }

   @EventTarget
   public void id_class(q_1 var1) {
      if (var1.id_class() == (Y)Y.staticFields22c81230f53b33f2a682b4198db24cc4[id_protected[1]]) {
         if ((rrfq_3)rrfp_3.id_class[id_protected[2]] == null) {
            return;
         }

         SL var2 = C_throws.id_byte().id_default();
         if (var2.id_throws()) {
            return;
         }

         switch (((int[])rrlQ_2.id_class[id_protected[3]])[((rrfq_3)rrfp_3.id_class[id_protected[4]]).ordinal()]) {
            case 1:
            case 2:
               this.id_this();
               break;
            case 3:
               this.id_break(var2);
               break;
            case 4:
               this.id_class(var2);
         }
      }
   }

   private static long id_class(long var0) {
      return Long.rotateLeft(var0, 32) ^ -7277647066595262163L;
   }

   @EventTarget
   public void id_class(rrFK var1) {
      this.id_continue();
      Object var6 = null;
      this.id_break[id_protected[5]] = var6;
   }

   private static int id_class(int var0) {
      return Integer.rotateLeft(var0, 16) ^ -448057592;
   }

   public static String id_break(String var0) throws Exception {
      Cipher var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeySpec var2 = new SecretKeySpec(new byte[]{119, -67, 17, 11, 10, -120, -11, 82}, "DES");
      IvParameterSpec var3 = new IvParameterSpec(new byte[8]);
      var1.init(2, var2, var3);
      return new String(var1.doFinal(var0.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
   }

   private void id_break(SL var1) {
      this.id_continue();
      Po_1 var2 = C_throws.id_byte().P().id_break();
      if (var2 != null) {
         PK var3 = var2.id_break();
         if (var3.id_break()) {
            String var8 = var3.id_class() + var2.id_class();
            this.id_break[id_protected[14]] = var8;
         } else if (!rql_3.id_break((String)this.id_break[id_protected[15]])) {
            var1.id_class(new SF((String)this.id_break[id_protected[16]], id_throws[0]));
         }
      }
   }

   @Override
   public void id_throws(boolean var1) {
      this.id_continue();
      super.id_throws(var1);
      Object var6 = null;
      this.id_break[id_protected[20]] = var6;
   }

   private void id_continue() {
      if (this.id_break == null) {
         this.id_break = new Object[1];
      }
   }

   private static void id_else() {
      id_throws = new long[2];
   }

   private static void id_new() {
      id_private = new boolean[]{true};
   }

   private static void id_return() {
      id_byte = new byte[]{20};
   }

   private static void id_super() {
      id_protected = new short[]{3, 0, 1, 0, 1, 0, 0, 0, 57, 41, 57, 41, 57, 0, 0, 0, 0, 0, 0, 0, 0};
   }

   private static void id_public() {
      id_catch = new String[]{new String("Auto Reconnect"), new String("Автоматически перезаходит на\nпоследний игровой режим")};
   }
}
