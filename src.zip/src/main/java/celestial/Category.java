package celestial;

import java.nio.charset.StandardCharsets;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public enum Category {
   COMBAT,
   MOVEMENT,
   RENDER,
   PLAYER,
   UTIL,
   CONFIGS,
   THEMES,
   AUTOBUY_ITEMS,
   AUTOBUY_HISTORY;

   Category() {}

   private static short[] shortse67813cd60183787b1de54ac6b91c916;
   private static boolean[] booleanse67813cd60183787b1de54ac6b91c916;
   private static byte[] bytese67813cd60183787b1de54ac6b91c916;
   public static Object[] staticFieldse67813cd60183787b1de54ac6b91c916;
   private static String[] stringse67813cd60183787b1de54ac6b91c916;
   public Object[] fieldse67813cd60183787b1de54ac6b91c916;

   public rqO_2 id_byte() {
      return (rqO_2)this.fieldse67813cd60183787b1de54ac6b91c916[shortse67813cd60183787b1de54ac6b91c916[8]];
   }

   public void initCategory(String var3, String var4, String var5) {
      this.id_finally();
      String var10 = var3;
      this.fieldse67813cd60183787b1de54ac6b91c916[shortse67813cd60183787b1de54ac6b91c916[1]] = var10;
      String var11 = var4;
      this.fieldse67813cd60183787b1de54ac6b91c916[shortse67813cd60183787b1de54ac6b91c916[2]] = var11;
      String var12 = var5;
      this.fieldse67813cd60183787b1de54ac6b91c916[shortse67813cd60183787b1de54ac6b91c916[3]] = var12;
      rqO_2 var13 = new rqO_2("celestial/images/category/" + var4 + ".png");
      this.fieldse67813cd60183787b1de54ac6b91c916[shortse67813cd60183787b1de54ac6b91c916[4]] = var13;
   }

   private static void ntfClinit() {
      id_throws();
      id_implements();
      id_case();
      id_extends();
      id_catch();
   }
   static {
      ntfClinit();
   }

   private static long id_class(long var0) {
      return Long.rotateLeft(var0, 32) ^ -3600156721038959069L;
   }

   private static int id_class(int var0) {
      return Integer.rotateLeft(var0, 16) ^ 1983107440;
   }

   public String id_class() {
      return (String)this.fieldse67813cd60183787b1de54ac6b91c916[shortse67813cd60183787b1de54ac6b91c916[7]];
   }

   public static String id_class(String var0) throws Exception {
      Cipher var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeySpec var2 = new SecretKeySpec(new byte[]{54, 51, 43, -26, 119, 76, 80, 1}, "DES");
      IvParameterSpec var3 = new IvParameterSpec(new byte[8]);
      var1.init(2, var2, var3);
      return new String(var1.doFinal(var0.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
   }

   public String id_break() {
      return (String)this.fieldse67813cd60183787b1de54ac6b91c916[shortse67813cd60183787b1de54ac6b91c916[6]];
   }

   private static void id_throws() {
      booleanse67813cd60183787b1de54ac6b91c916 = new boolean[]{false, true, false, false, true, true};
   }

   private void id_finally() {
      if (this.fieldse67813cd60183787b1de54ac6b91c916 == null) {
         this.fieldse67813cd60183787b1de54ac6b91c916 = new Object[bytese67813cd60183787b1de54ac6b91c916[23]];
         Object[] var1 = this.fieldse67813cd60183787b1de54ac6b91c916;
      }
   }

   private static void id_catch() {
      COMBAT.initCategory(stringse67813cd60183787b1de54ac6b91c916[1], stringse67813cd60183787b1de54ac6b91c916[2], stringse67813cd60183787b1de54ac6b91c916[3]);
      MOVEMENT.initCategory(stringse67813cd60183787b1de54ac6b91c916[5], stringse67813cd60183787b1de54ac6b91c916[6], stringse67813cd60183787b1de54ac6b91c916[7]);
      RENDER.initCategory(stringse67813cd60183787b1de54ac6b91c916[9], stringse67813cd60183787b1de54ac6b91c916[10], stringse67813cd60183787b1de54ac6b91c916[11]);
      PLAYER.initCategory(stringse67813cd60183787b1de54ac6b91c916[13], stringse67813cd60183787b1de54ac6b91c916[14], stringse67813cd60183787b1de54ac6b91c916[15]);
      UTIL.initCategory(stringse67813cd60183787b1de54ac6b91c916[17], stringse67813cd60183787b1de54ac6b91c916[18], stringse67813cd60183787b1de54ac6b91c916[19]);
      CONFIGS.initCategory(stringse67813cd60183787b1de54ac6b91c916[21], stringse67813cd60183787b1de54ac6b91c916[22], stringse67813cd60183787b1de54ac6b91c916[23]);
      THEMES.initCategory(stringse67813cd60183787b1de54ac6b91c916[25], stringse67813cd60183787b1de54ac6b91c916[26], stringse67813cd60183787b1de54ac6b91c916[27]);
      AUTOBUY_ITEMS.initCategory(stringse67813cd60183787b1de54ac6b91c916[29], stringse67813cd60183787b1de54ac6b91c916[30], stringse67813cd60183787b1de54ac6b91c916[31]);
      AUTOBUY_HISTORY.initCategory(stringse67813cd60183787b1de54ac6b91c916[33], stringse67813cd60183787b1de54ac6b91c916[34], stringse67813cd60183787b1de54ac6b91c916[35]);
      Object[] var0 = new Object[]{COMBAT, MOVEMENT, RENDER, PLAYER, UTIL, CONFIGS, THEMES, AUTOBUY_ITEMS, AUTOBUY_HISTORY, null};
      var0[9] = new Category[]{COMBAT, MOVEMENT, RENDER, PLAYER, UTIL, CONFIGS, THEMES, AUTOBUY_ITEMS, AUTOBUY_HISTORY};
      staticFieldse67813cd60183787b1de54ac6b91c916 = var0;
   }

   private static void id_extends() {
      bytese67813cd60183787b1de54ac6b91c916 = new byte[]{9, 2, 3, 4, 5, 6, 7, 8, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 4, 10};
   }

   private static void id_case() {
      shortse67813cd60183787b1de54ac6b91c916 = new short[]{9, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 4, 5, 6, 7, 8};
   }

   private static void id_implements() {
      stringse67813cd60183787b1de54ac6b91c916 = new String[]{
         new String("COMBAT"),
         new String("Combat"),
         new String("combat"),
         new String("Основные"),
         new String("MOVEMENT"),
         new String("Movement"),
         new String("movement"),
         new String("Основные"),
         new String("RENDER"),
         new String("Render"),
         new String("render"),
         new String("Основные"),
         new String("PLAYER"),
         new String("Player"),
         new String("player"),
         new String("Основные"),
         new String("UTIL"),
         new String("Util"),
         new String("util"),
         new String("Основные"),
         new String("CONFIGS"),
         new String("Configs"),
         new String("configs"),
         new String("Другие"),
         new String("THEMES"),
         new String("Themes"),
         new String("themes"),
         new String("Другие"),
         new String("AUTOBUY_ITEMS"),
         new String("Items"),
         new String("autobuy_items"),
         new String("Авто. покупка"),
         new String("AUTOBUY_HISTORY"),
         new String("History"),
         new String("autobuy_history"),
         new String("Авто. покупка")
      };
   }

   public String id_protected() {
      return (String)this.fieldse67813cd60183787b1de54ac6b91c916[shortse67813cd60183787b1de54ac6b91c916[5]];
   }
}
