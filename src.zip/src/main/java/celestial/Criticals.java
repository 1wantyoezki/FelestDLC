package celestial;

import com.viaversion.viaversion.api.protocol.version.ProtocolVersion;
import java.nio.charset.StandardCharsets;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class Criticals extends Module {
   private static float[] id_break;
   private static short[] id_byte;
   private static boolean[] id_protected;
   private static String[] id_throws;

   public Criticals() {
      super(id_throws[0], id_throws[1], (Category)Category.staticFieldse67813cd60183787b1de54ac6b91c916[id_byte[0]]);
   }

   private static void ntfClinit() {
      id_continue();
      id_this();
      id_else();
      id_super();
   }

   static {
      ntfClinit();
   }

   private static void id_this() {
      id_throws = new String[]{
         new String("Criticals"), new String("Позволяет всегда бить\nкритическами ударами"), new String("Необходимо использовать версию 1.17.1 или выше")
      };
   }

   @EventTarget
   public void id_class(q_1 var1) {
      if (var1.id_class() == (Y)Y.staticFields22c81230f53b33f2a682b4198db24cc4[id_byte[11]] && !this.id_return()) {
         this.id_byte(id_protected[1]);
      }
   }

   @Override
   public void id_class(boolean var1) {
      if (!this.id_return()) {
         this.id_byte(id_protected[2]);
      } else {
         super.id_class(var1);
      }
   }

   @EventTarget
   public void id_class(rrFj_1 var1) {
      if (!((cb_3)id_import.id_class[id_byte[1]]).BL()) {
         float var2 = (Float)((cb_3)id_import.id_class[id_byte[2]]).id_throws[id_byte[3]] + rrfQ_2.id_byte(id_break[0], id_break[1]);
         float var3 = (Float)((cb_3)id_import.id_class[id_byte[4]]).id_throws[id_byte[5]] + rrfQ_2.id_byte(id_break[2], id_break[3]);
         double var4 = ((cb_3)id_import.id_class[id_byte[6]]).re() - rrfQ_2.id_byte(id_break[4], id_break[5]);
         ((Aq_1)((cb_3)id_import.id_class[id_byte[7]]).id_break[id_byte[8]])
            .id_break(new rZX(((cb_3)id_import.id_class[id_byte[9]]).rx(), var4, ((cb_3)id_import.id_class[id_byte[10]]).BO(), var2, var3, id_protected[0]));
      }
   }

   private static int id_class(int var0) {
      return Integer.rotateLeft(var0, 16) ^ 75817713;
   }

   private static long id_class(long var0) {
      return Long.rotateLeft(var0, 32) ^ 5623468838187463472L;
   }

   public static String id_break(String var0) throws Exception {
      Cipher var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeySpec var2 = new SecretKeySpec(new byte[]{-84, 118, -29, -41, -70, -38, -3, -105}, "DES");
      IvParameterSpec var3 = new IvParameterSpec(new byte[8]);
      var1.init(2, var2, var3);
      return new String(var1.doFinal(var0.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
   }

   private static void id_continue() {
      id_protected = new boolean[]{false, false, false, false, true, true, false};
   }

   private static void id_else() {
      id_byte = new short[]{0, 57, 57, 15, 57, 16, 57, 57, 0, 57, 57, 0, 0, 2000, 57, 57};
   }

   public boolean id_new() {
      return this.aJ_() && (cb_3)id_import.id_class[id_byte[14]] != null && !((cb_3)id_import.id_class[id_byte[15]]).BL() ? id_protected[5] : id_protected[6];
   }

   private boolean id_return() {
      if (rrjA_2.id_protected().id_throws().id_throws(ProtocolVersion.v1_17_1)) {
         String var1 = id_throws[2];
         rrfu_3.id_byte(rrfu_3.id_class(this) + var1);
         ((rrth_3)rrth_3.staticFields39e3fc1d50923a0b997a92f976964031[id_byte[12]]).id_class(new rrtx_3(this.id_final(), var1, id_byte[13]));
         return id_protected[3];
      } else {
         return id_protected[4];
      }
   }

   private static void id_super() {
      id_break = new float[]{-0.0015F, 0.00105F, -0.0015F, 0.00105F, 3.5E-5F, 6.5E-5F};
   }
}
