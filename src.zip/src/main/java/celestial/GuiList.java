package celestial;

import celestial.Ml_1;
import celestial.rrIc_1;
import celestial.rrIk_1;
import celestial.AnimValue;
import celestial.rrZF;
import celestial.FontManager;
import celestial.rrZO;
import celestial.ColorHelper;
import celestial.rrtF_2;
import celestial.rrtI_2;
import celestial.rrtN_2;
import celestial.rrtf_3;
import celestial.rrtm_3;
import celestial.rrtn_3;
import celestial.rrtu_3;
import celestial.rrtw_3;
import celestial.rruv_1;
import celestial.rrwB_2;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class GuiList extends rrtw_3 {
    public Object[] id_throws;
    private static float[] id_native;
    private static double[] id_volatile;
    private static boolean[] id_final;
    private static byte[] id_package;
    private static short[] id_int;
    private static String[] id_new;

    private static void id_char() {
        id_package = new byte[]{6, 2};
    }

    private static void id_long() {
        boolean[] blArray = new boolean[11];
        blArray[2] = true;
        blArray[5] = true;
        blArray[6] = true;
        blArray[8] = true;
        blArray[10] = true;
        id_final = blArray;
    }

    public GuiList(rrtN_2 rrtN_22, rrIc_1 rrIc_12, float f, float f2, float f3, float f4) {
        super(rrtN_22, (rrtf_3<?>)rrIc_12, f, f2, f3, f4);
        ArrayList<rrwB_2> arrayList;
        this.id_instanceof();
        this.id_throws[GuiList.id_int[0]] = arrayList = new ArrayList<>();
        for (rrIk_1 rrIk_12 : rrIc_12.id_class()) {
            ((List<rrwB_2>)this.id_throws[id_int[1]]).add(new rrwB_2(rrIk_12));
        }
    }

    static {
        GuiList.ntfClinit();
    }

    private static void id_interface() {
        id_new = new String[]{new String("\u041d\u0435\u0442\u0443 :(")};
    }

    @Override
    public void id_class(Ml_1 ml_1, rrtI_2 rrtI_22, int n, int n2) {
        this.id_instanceof();
        float f = rrtI_22.id_break();
        float f2 = rrtI_22.id_byte();
        float f3 = rrtI_22.id_throws();
        float f4 = rrtI_22.id_class();
        AnimValue rrNs_12 = this.id_return();
        float f5 = rrNs_12.id_byte();
        int n3 = (int)(id_native[0] * f5);
        GuiList.id_class(ml_1, this, f, f2, f3, f4);
        rrtF_2.id_class((Ml_1)ml_1, (rrtm_3)this, (float)(f + f3 - id_native[1]), (float)(f2 + id_native[2]), (float)id_native[3], (float)(id_native[4] + f5 * id_native[5]), (int)rrZF.d_, (int)id_int[2]);
        float f6 = id_native[6] * f5 + id_native[7];
        if (!this.id_return().id_case() && f5 <= 0.001f) {
            this.id_throws[GuiList.id_int[4]] = Float.valueOf(0.0f);
        }
        for (rrwB_2 rrwB_22 : this.id_while()) {
            float f7 = f + id_native[8];
            float f8 = f2 + f6;
            rrwB_22.id_throws().id_class(rrwB_22.id_case().id_private());
            rrwB_22.id_break().id_class(rrwB_22.id_protected());
            float f9 = rrwB_22.id_throws().id_byte();
            float f10 = rrwB_22.id_break().id_byte();
            if (!this.id_return().id_case()) continue;
            int n4 = ColorHelper.id_class((int)rrZF.n_, (int)rrZF.d_, (float)f10);
            rrZO rrZO2 = ((FontManager)FontManager.staticFields71d6c26f697c30cf88e2ba2ddc0b4971[id_int[3]]).id_finally();
            rrwB_22.id_class(new rruv_1(f, f8 - id_native[9], f3, (float)(rrZO2.id_class() + id_package[0])));
            rrtF_2.id_protected((Ml_1)ml_1, (rrtm_3)this, (rrZO)rrZO2, (String)rrwB_22.id_byte(), (float)f7, (float)f8, (int)n4, (int)((int)((float)n3 * f5 * f9)));
            Float f11 = Float.valueOf(f6 += id_native[10] * f5 * f9);
            this.id_throws[GuiList.id_int[4]] = f11;
        }
        this.id_class(ml_1, f, f2);
    }

    @Override
    public boolean id_class(rrtu_3 rrtu_32, rrtI_2 rrtI_22, float f, float f2, int n, int n2, int n3) {
        if (!this.id_return().id_case()) {
            return id_final[1];
        }
        for (rrwB_2 rrwB_22 : this.id_while()) {
            if (n3 != 0 || !rrwB_22.id_class().id_break((float)n, (float)n2)) continue;
            rrwB_22.id_case().id_class(Boolean.valueOf(!rrwB_22.id_protected() ? id_final[2] : id_final[3]), id_final[4], id_final[5]);
            return id_final[6];
        }
        return id_final[7];
    }

    private static long id_class(long l) {
        return Long.rotateLeft(l, 32) ^ 0x5D76A9A400014315L;
    }

    private void id_class(Ml_1 ml_1, float f, float f2) {
        List<rrIk_1> list = this.id_while().stream().filter(rrwB_2::id_protected).map(rrwB_2::id_case).sorted(Comparator.comparingInt(rrIk_12 -> -((int)((FontManager)FontManager.staticFields71d6c26f697c30cf88e2ba2ddc0b4971[id_int[11]]).id_finally().id_break(rrIk_12.id_throws())))).toList();
        String string = list.isEmpty() ? id_new[0] : list.get((id_final[0] ? 1 : 0)).id_throws();
        rrtF_2.id_class((Ml_1)ml_1, (rrZO)((FontManager)FontManager.staticFields71d6c26f697c30cf88e2ba2ddc0b4971[id_int[5]]).id_finally(), (String)string, (float)(f + id_native[11]), (float)(f2 + id_native[12]), (int)rrZF.d_, (int)this.id_class(id_int[6]));
    }

    @Override
    public float id_class(float f, float f2) {
        this.id_instanceof();
        float anim = this.id_return().id_byte();
        if (!this.id_return().id_case() && anim <= 0.001f) {
            return 0.0f;
        }
        float baseHeight = ((Float)this.id_throws[id_int[10]]).floatValue() - id_native[13];
        return Math.max(0.0f, baseHeight * anim);
    }

    private static int id_break(int n) {
        return Integer.rotateLeft(n, 16) ^ 0x310375B3;
    }

    private static void ntfClinit() {
        GuiList.id_long();
        GuiList.id_interface();
        GuiList.id_throw();
        GuiList.id_abstract();
        GuiList.id_try();
        GuiList.id_char();
    }

    private void id_instanceof() {
        if (this.id_throws == null) {
            Object[] objectArray = this.id_throws = new Object[id_package[1]];
            objectArray[(GuiList.id_final[10] ? 1 : 0)] = Float.valueOf(id_native[14]);
        }
    }

    private static void id_throw() {
        short[] sArray = new short[12];
        sArray[2] = 255;
        sArray[4] = 1;
        sArray[6] = 255;
        sArray[10] = 1;
        id_int = sArray;
    }

    private static void id_try() {
        double[] dArray = new double[2];
        dArray[1] = 10.0;
        id_volatile = dArray;
    }

    public List<rrwB_2> id_while() {
        this.id_instanceof();
        List<rrwB_2> items = (List<rrwB_2>)this.id_throws[id_int[9]];
        return items.stream().filter(rrwB_22 -> rrwB_22.id_case().id_private() || rrwB_22.id_throws().id_case() ? id_final[8] : id_final[9]).toList();
    }

    @Override
    public float id_public() {
        this.id_instanceof();
        rrZO rrZO2 = ((FontManager)FontManager.staticFields71d6c26f697c30cf88e2ba2ddc0b4971[id_int[7]]).id_finally();
        List<rrwB_2> items = (List<rrwB_2>)this.id_throws[id_int[8]];
        return (float)(items.stream().mapToDouble(rrwB_22 -> rrZO2.id_break(rrwB_22.id_byte())).max().orElse(id_volatile[0]) + id_volatile[1]);
    }

    @Override
    public List<? extends rrtn_3> id_protected() {
        return this.id_while();
    }

    public static String id_protected(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-105, 77, -84, -64, 24, -57, 127, -125}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void id_abstract() {
        float[] fArray = new float[15];
        fArray[0] = 255.0f;
        fArray[1] = 4.0f;
        fArray[2] = 4.5f;
        fArray[3] = 1.0f;
        fArray[4] = 180.0f;
        fArray[5] = 180.0f;
        fArray[6] = 10.0f;
        fArray[7] = 3.0f;
        fArray[8] = 2.0f;
        fArray[9] = 3.0f;
        fArray[10] = 10.0f;
        fArray[11] = 2.0f;
        fArray[12] = 3.0f;
        fArray[13] = 2.0f;
        id_native = fArray;
    }
}
