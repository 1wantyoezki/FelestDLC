package celestial;

import java.nio.charset.StandardCharsets;
import java.util.Collection;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class HudWidget extends rrvR_1 {
   private static boolean[] id_native;
   private static byte[] id_volatile;
   private static float[] id_final;
   private static short[] id_package;
   public Object[] id_protected;
   private static String[] id_int;

   public static String id_byte(String var0) throws Exception {
      Cipher var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeySpec var2 = new SecretKeySpec(new byte[]{-96, 52, 79, -54, -56, -45, 75, -70}, "DES");
      IvParameterSpec var3 = new IvParameterSpec(new byte[8]);
      var1.init(2, var2, var3);
      return new String(var1.doFinal(var0.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
   }

   public HudWidget() {
      super(id_int[0], new AnimValue(id_final[0], id_native[0]), new AnimValue(id_final[1], id_native[1]));
      this.B();
      rrFZ var5 = new rrFZ(this);
      this.id_protected[0] = var5;
      Float var6 = Float.valueOf(this.S());
      this.id_protected[1] = var6;
      this.id_try().id_class(var6.floatValue());
   }

   static {
      ntfClinit();
   }

   private void B() {
      if (this.id_protected == null) {
         this.id_protected = new Object[2];
         this.id_protected[1] = Float.valueOf(47.0F);
      }
   }

   private static FontManager getFontManager() {
      try {
         if (FontManager.staticFields71d6c26f697c30cf88e2ba2ddc0b4971 != null 
             && FontManager.staticFields71d6c26f697c30cf88e2ba2ddc0b4971.length > 0) {
            Object obj = FontManager.staticFields71d6c26f697c30cf88e2ba2ddc0b4971[0];
            if (obj instanceof FontManager zj) {
               return zj;
            }
         }
      } catch (Throwable ignored) {}
      return null;
   }

   private float S() {
      this.B();
      float maxWidth = 0.0F;
      rrFZ fz = this.id_protected != null && this.id_protected.length > 0 ? (rrFZ) this.id_protected[0] : null;
      if (fz != null) {
         try {
            Collection col = fz.id_byte();
            if (col != null) {
               for (Object obj : col) {
                  if (obj instanceof rrqr_3 var4) {
                     maxWidth = Math.max(maxWidth, fz.id_class(var4));
                  }
               }
            }
         } catch (Throwable ignored) {}
      }
      FontManager fontManager = getFontManager();
      rrZO font = fontManager != null ? fontManager.id_class() : null;
      float titleWidth = font != null ? font.id_break(this.id_byte()) : 60.0F;
      float emptyWidth = font != null ? font.id_break("Персонал не найден") : 90.0F;
      return Math.max(Math.max(maxWidth, titleWidth + 20.0F), emptyWidth + 20.0F);
   }

   private static void s() {
      id_int = new String[]{new String("Staff Viewer")};
   }

   public static boolean enabled = true;

   private static boolean hasActiveStaff(StaffViewer staffModule) {
      if (staffModule == null) return false;
      try {
         java.util.List<rrqr_3> list = staffModule.id_super();
         if (list == null || list.isEmpty()) return false;
         for (rrqr_3 item : list) {
            if (!(item instanceof rrFv_1)) {
               AnimValue anim = item.id_break();
               if (anim != null && (anim.id_case() || item.id_catch())) {
                  return true;
               }
            }
         }
      } catch (Throwable ignored) {}
      return false;
   }

   private void id_class(Ml_1 var1, float var2, float var3, float var4, float var5) {
      if (!this.id_package()) {
         return;
      }
      this.B();
      rrfi_3.id_break();
      rrfD_2.id_protected(var1, var2, var3 + id_final[5], var4, var5, id_volatile[0]);
      rrfi_3.id_class(id_native[11] ? 1 : 0);
      rrFZ fz = this.id_protected != null && this.id_protected.length > 0 ? (rrFZ) this.id_protected[0] : null;
      if (fz != null) {
         fz.id_class(var1, var2, var3);
      }

      // If no staff are online and NOT in preview mode, display "Персонал не найден"
      try {
         rrQX client = (rrQX) rrQX.staticFields09f1f28026cd378cb9df490a64ac8f2a[0];
         StaffViewer staffModule = client != null && client.id_private() != null ? client.id_private().o() : null;
         if (!this.id_super() && !hasActiveStaff(staffModule)) {
            FontManager fontManager = getFontManager();
            rrZO font = fontManager != null ? fontManager.id_finally() : null;
            if (font != null) {
               font.id_break(id_strictfp);
               font.id_break(var1, new rgN_2("Персонал не найден").id_class(rgF_2.GRAY), (double)(var2 + 6.0F), (double)(var3 + 17.0F), rrZF.d_, (int)(220 * this.id_long()));
               font.id_byte(id_strictfp);
            }
         }
      } catch (Throwable ignored) {}

      rrfi_3.id_class();
   }

   @Override
   public boolean aq_() {
      if (!this.id_package()) {
         return false;
      }
      return super.aq_();
   }

   @Override
   public void id_class(Ml_1 var1, rrtu_3 var2, int var3, int var4, boolean var5) {
      if (!this.id_package()) {
         return;
      }
      super.id_class(var1, var2, var3, var4, var5);
      float x = this.id_default();
      float y = this.id_abstract();
      float w = this.id_implements();
      float h = this.ao_();
      rrvg_1.id_class(this, var1, () -> this.id_class(var1, x, y, w, h));
   }

   private static void ntfClinit() {
      id_throw();
      s();
      E();
      G();
      M();
   }

   private static void M() {
      id_volatile = new byte[]{-1, 2};
   }

   private static void G() {
      id_package = new short[]{0, 1, 1, 0, 73, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0};
   }

   public float id_goto() {
      this.B();
      return this.id_protected != null && this.id_protected.length > 1 && this.id_protected[1] instanceof Float f ? f : 47.0F;
   }

   public void id_instanceof() {
      this.B();
      super.id_instanceof();
      boolean inEditorOrGui = false;
      try {
         if (id_import != null && id_import.id_class != null && id_package != null && id_package.length > 4) {
            Object scr = id_import.id_class[id_package[4]];
            if (scr instanceof FP || scr instanceof rrFx_1) {
               inEditorOrGui = true;
            }
         }
      } catch (Throwable ignored) {}
      this.id_break(this.id_package() && inEditorOrGui);
      Float var5 = Float.valueOf(this.S());
      if (this.id_protected != null && this.id_protected.length > 1) {
         this.id_protected[1] = var5;
      }
      rrFZ fz = this.id_protected != null && this.id_protected.length > 0 ? (rrFZ) this.id_protected[0] : null;
      if (fz != null) {
         fz.id_throws();
      }
   }

   public boolean id_package() {
      this.B();
      if (!enabled) {
         return false;
      }
      try {
         rrQX client = (rrQX) rrQX.staticFields09f1f28026cd378cb9df490a64ac8f2a[0];
         if (client != null && client.id_private() != null) {
            Hud cui = client.id_private().w();
            if (cui != null && (!cui.aJ_() || (cui.staffViewerToggle != null && !cui.staffViewerToggle.id_class()))) {
               return false;
            }
            StaffViewer staffModule = client.id_private().o();
            if (staffModule != null && !staffModule.aJ_()) {
               return false;
            }
         }
      } catch (Throwable ignored) {}
      return true;
   }

   private static void id_throw() {
      id_native = new boolean[]{
         true, true, true, false, true, false, false, false, false, false, true, true, true
      };
   }

   public float id_while() {
      this.B();
      rrFZ fz = this.id_protected != null && this.id_protected.length > 0 ? (rrFZ) this.id_protected[0] : null;
      float h = fz != null ? fz.id_finally() - id_final[2] : 0.0F;
      if (h <= 18.0F) {
         h = 28.0F;
      }
      return h;
   }

   public boolean id_protected() {
      return id_native[7];
   }

   private static void E() {
      id_final = new float[]{0.5F, 0.5F, 2.0F, 0.0F, 47.0F, 12.5F, 0.0F};
   }

   public float ao_() {
      return this.id_while();
   }

   @Override
   public float id_default() {
      float x = super.id_default();
      float screenW = id_const != null ? id_const.id_volatile() : 640.0F;
      if (screenW > 100.0F) {
         x = Math.max(2.0F, Math.min(x, screenW - this.id_implements() - 2.0F));
      }
      return x;
   }

   @Override
   public float id_abstract() {
      float y = super.id_abstract();
      float screenH = id_const != null ? id_const.id_final() : 360.0F;
      if (screenH > 100.0F) {
         y = Math.max(2.0F, Math.min(y, screenH - this.ao_() - 2.0F));
      }
      return y;
   }
}
