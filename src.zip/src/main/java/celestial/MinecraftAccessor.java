package celestial;

public interface MinecraftAccessor {
   QY id_import = QY.id_instanceof();
   Qg_1 id_const = id_import.id_else();
   pg_3 id_void = id_import.id_case();
   yb_3 id_default = yb_3.id_class();
   lD_2 id_strictfp = id_default.id_byte();
   Hz_1 id_short = id_import.id_float();
   fY_2 id_static = id_import.A();

   default cG_2 O() {
      return (cb_3)id_import.id_class[57];
   }

   static void id_protected(String var0, boolean var1) {
      Pb_1.id_class(var0, var1);
   }

   static void a_(String var0, boolean var1) {
      if (!id_import.id_static()) {
         Pb_1.id_class(var0, var1);
      }
   }
}
