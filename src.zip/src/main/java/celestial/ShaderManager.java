package celestial;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.lwjgl.opengl.ARBShaderObjects;
import org.lwjgl.opengl.GL20;

public class ShaderManager implements MinecraftAccessor {
   private static int[] id_break;
   private static String[] id_byte;
   private static boolean[] id_protected;
   public Object[] id_class;
   private static byte[] id_throws;
   private static short[] id_case;
   private static float[] id_catch;

   public void id_byte() {
      ARBShaderObjects.glUseProgramObjectARB((id_protected[16] ? 1 : 0));
   }

   public void id_byte(String var1) {
      int var2 = ARBShaderObjects.glCreateProgramObjectARB();
      if (var2 == 0) {
         System.out.println(id_byte[29]);
         System.exit((id_protected[19] ? 1 : 0));
      } else {
         int var3 = ARBShaderObjects.glCreateShaderObjectARB(id_break[15]);
         ARBShaderObjects.glShaderSourceARB(var3, var1);
         ARBShaderObjects.glCompileShaderARB(var3);
         if (GL20.glGetShaderi(var3, id_break[16]) == 0) {
            System.out.println("Error [ " + GL20.glGetShaderInfoLog(var3, id_case[15]) + " ]");
         }

         ARBShaderObjects.glAttachObjectARB(var2, var3);
         ARBShaderObjects.glLinkProgramARB(var2);
         Integer var8 = var2;
         this.id_class[id_case[16]] = var8;
      }
   }

   public ShaderManager(String var1, boolean var2) {
      this(var1, id_byte[23], var2);
   }

   public ShaderManager(String var1, String var2, boolean var3) {
      this.id_catch();
      if (!var3) {
         int var4 = GL20.glCreateProgram();

         try {
            String var6 = var1;
            byte var7 = id_throws[0];
            switch (var6.hashCode()) {
               case -1375484743:
                  if (var6.equals(id_byte[9])) {
                     var7 = id_throws[8];
                  }
                  break;
               case -522346544:
                  if (var6.equals(id_byte[5])) {
                     var7 = id_throws[4];
                  }
                  break;
               case -265350775:
                  if (var6.equals(id_byte[8])) {
                     var7 = id_throws[7];
                  }
                  break;
               case -203176731:
                  if (var6.equals(id_byte[1])) {
                     var7 = (byte)(id_protected[1] ? 1 : 0);
                  }
                  break;
               case 276341117:
                  if (var6.equals(id_byte[4])) {
                     var7 = id_throws[3];
                  }
                  break;
               case 987499862:
                  if (var6.equals(id_byte[2])) {
                     var7 = id_throws[1];
                  }
                  break;
               case 1185175638:
                  if (var6.equals(id_byte[3])) {
                     var7 = id_throws[2];
                  }
                  break;
               case 1522987411:
                  if (var6.equals(id_byte[7])) {
                     var7 = id_throws[6];
                  }
                  break;
               case 1978403102:
                  if (var6.equals(id_byte[10])) {
                     var7 = id_throws[9];
                  }
                  break;
               case 2048730166:
                  if (var6.equals(id_byte[0])) {
                     var7 = (byte)(id_protected[0] ? 1 : 0);
                  }
                  break;
               case 2087269388:
                  if (var6.equals(id_byte[6])) {
                     var7 = id_throws[5];
                  }
            }
            int var5 = switch (var7) {
               case 0 -> this.id_class(new ByteArrayInputStream(id_byte[11].getBytes()), id_break[0]);
               case 1 -> this.id_class(new ByteArrayInputStream(id_byte[12].getBytes()), id_break[1]);
               case 2 -> this.id_class(new ByteArrayInputStream(id_byte[13].getBytes()), id_break[2]);
               case 3 -> this.id_class(new ByteArrayInputStream(id_byte[14].getBytes()), id_break[3]);
               case 4 -> this.id_class(new ByteArrayInputStream(id_byte[15].getBytes()), id_break[4]);
               case 5 -> this.id_class(new ByteArrayInputStream(id_byte[16].getBytes()), id_break[5]);
               case 6 -> this.id_class(new ByteArrayInputStream(id_byte[17].getBytes()), id_break[6]);
               case 7 -> this.id_class(new ByteArrayInputStream(id_byte[18].getBytes()), id_break[7]);
               case 8 -> this.id_class(new ByteArrayInputStream(id_byte[19].getBytes()), id_break[8]);
               case 9 -> this.id_class(new ByteArrayInputStream(id_byte[20].getBytes()), id_break[9]);
               case 10 -> this.id_class(new ByteArrayInputStream(id_byte[21].getBytes()), id_break[10]);
               default -> this.id_class(id_import.F().id_class(new rqO_2(var1)).id_break(), id_break[11]);
            };
            GL20.glAttachShader(var4, var5);
            int var15 = this.id_class(id_import.F().id_class(new rqO_2(var2)).id_break(), id_break[12]);
            GL20.glAttachShader(var4, var15);
         } catch (IOException var13) {
            var13.printStackTrace();
         }

         GL20.glLinkProgram(var4);
         int var14 = GL20.glGetProgrami(var4, id_break[13]);
         if (var14 == 0) {
            throw new IllegalStateException(id_byte[22]);
         }

         Integer var12 = var4;
         this.id_class[id_case[0]] = var12;
      } else {
         this.id_protected(var1);
      }
   }

   private static void ntfClinit() {
      id_extends();
      id_private();
      id_throws();
      id_case();
      id_finally();
      id_implements();
   }

   static {
      ntfClinit();
   }

   public void id_class(String var1, float var2, float var3, float var4) {
      int var5 = GL20.glGetUniformLocation((Integer)this.id_class[id_case[6]], var1);
      GL20.glUniform3f(var5, var2, var3, var4);
   }

   public static void id_class(Ml_1 var0, float var1, float var2, float var3, float var4) {
      rjV_2 var5 = var0.id_byte().id_class();
      id_strictfp.id_class(var5, var1, var2, id_catch[28]).id_class(id_catch[29], id_catch[30]).id_class();
      id_strictfp.id_class(var5, var1, var2 + var4, id_catch[31]).id_class(id_catch[32], id_catch[33]).id_class();
      id_strictfp.id_class(var5, var1 + var3, var2 + var4, id_catch[34]).id_class(id_catch[35], id_catch[36]).id_class();
      id_strictfp.id_class(var5, var1 + var3, var2, id_catch[37]).id_class(id_catch[38], id_catch[39]).id_class();
   }

   public static void id_class(Ml_1 var0) {
      rjV_2 var1 = var0.id_byte().id_class();
      float var2 = id_const.id_volatile();
      float var3 = id_const.id_final();
      id_strictfp.id_class(id_throws[10], ju_3.id_synchronized);
      id_strictfp.id_class(var1, id_catch[0], id_catch[1], id_catch[2]).id_class(id_catch[3], id_catch[4]).id_class();
      id_strictfp.id_class(var1, id_catch[5], var3, id_catch[6]).id_class(id_catch[7], id_catch[8]).id_class();
      id_strictfp.id_class(var1, var2, var3, id_catch[9]).id_class(id_catch[10], id_catch[11]).id_class();
      id_strictfp.id_class(var1, var2, id_catch[12], id_catch[13]).id_class(id_catch[14], id_catch[15]).id_class();
      id_default.id_break();
   }

   public void id_class(String var1, float... var2) {
      int var3 = GL20.glGetUniformLocation((Integer)this.id_class[id_case[3]], var1);
      switch (var2.length) {
         case 1:
            GL20.glUniform1f(var3, var2[(id_protected[3] ? 1 : 0)]);
            break;
         case 2:
            GL20.glUniform2f(var3, var2[(id_protected[4] ? 1 : 0)], var2[(id_protected[5] ? 1 : 0)]);
            break;
         case 3:
            GL20.glUniform3f(var3, var2[(id_protected[6] ? 1 : 0)], var2[(id_protected[7] ? 1 : 0)], var2[id_throws[13]]);
            break;
         case 4:
            GL20.glUniform4f(var3, var2[(id_protected[8] ? 1 : 0)], var2[(id_protected[9] ? 1 : 0)], var2[id_throws[14]], var2[id_throws[15]]);
      }
   }

   public void id_class() {
      GL20.glUseProgram((Integer)this.id_class[id_case[1]]);
   }

   private static int id_class(int var0) {
      return Integer.rotateLeft(var0, 16) ^ 1944379076;
   }

   private static long id_class(long var0) {
      return Long.rotateLeft(var0, 32) ^ 3921480524147402818L;
   }

   public void id_class(String var1, float var2, float var3, float var4, float var5) {
      ARBShaderObjects.glUniform4fARB(ARBShaderObjects.glGetUniformLocationARB((Integer)this.id_class[id_case[13]], var1), var2, var3, var4, var5);
   }

   private int id_class(InputStream var1, int var2) {
      int var3 = GL20.glCreateShader(var2);
      GL20.glShaderSource(var3, id_class(var1));
      GL20.glCompileShader(var3);
      if (GL20.glGetShaderi(var3, id_break[14]) == 0) {
         System.out.println(GL20.glGetShaderInfoLog(var3, id_case[9]));
         String var10002 = id_byte[24];
         Object[] var10003 = new Object[(id_protected[14] ? 1 : 0)];
         var10003[(id_protected[15] ? 1 : 0)] = var2;
         throw new IllegalStateException(String.format(var10002, var10003));
      } else {
         return var3;
      }
   }

   public void id_class(String var1, float var2) {
      ARBShaderObjects.glUniform1fARB(ARBShaderObjects.glGetUniformLocationARB((Integer)this.id_class[id_case[11]], var1), var2);
   }

   public void id_class(String var1, float var2, float var3) {
      ARBShaderObjects.glUniform2fARB(ARBShaderObjects.glGetUniformLocationARB((Integer)this.id_class[id_case[12]], var1), var2, var3);
   }

   public void id_class(String var1, int... var2) {
      int var3 = GL20.glGetUniformLocation((Integer)this.id_class[id_case[8]], var1);
      if (var2.length > (id_protected[10] ? 1 : 0)) {
         GL20.glUniform2i(var3, var2[(id_protected[11] ? 1 : 0)], var2[(id_protected[12] ? 1 : 0)]);
      } else {
         GL20.glUniform1i(var3, var2[(id_protected[13] ? 1 : 0)]);
      }
   }

   public static String id_class(InputStream var0) {
      StringBuilder var1 = new StringBuilder();

      try {
         BufferedReader var2 = new BufferedReader(new InputStreamReader(var0));

         String var3;
         while ((var3 = var2.readLine()) != null) {
            var1.append(var3).append((char)id_throws[11]);
         }
      } catch (Exception var4) {
      }

      return var1.toString();
   }

   public int id_class(String var1) {
      return GL20.glGetUniformLocation((Integer)this.id_class[id_case[2]], var1);
   }

   public static void id_break(Ml_1 var0, float var1, float var2, float var3, float var4) {
      rjV_2 var5 = var0.id_byte().id_class();
      id_strictfp.id_class(id_throws[12], ju_3.id_synchronized);
      id_strictfp.id_class(var5, var1, var2, id_catch[16]).id_class(id_catch[17], id_catch[18]).id_class();
      id_strictfp.id_class(var5, var1, var2 + var4, id_catch[19]).id_class(id_catch[20], id_catch[21]).id_class();
      id_strictfp.id_class(var5, var1 + var3, var2 + var4, id_catch[22]).id_class(id_catch[23], id_catch[24]).id_class();
      id_strictfp.id_class(var5, var1 + var3, var2, id_catch[25]).id_class(id_catch[26], id_catch[27]).id_class();
      id_default.id_break();
   }

   public void id_break(String var1, float var2) {
      int var3 = GL20.glGetUniformLocation((Integer)this.id_class[id_case[4]], var1);
      GL20.glUniform1f(var3, var2);
   }

   public void id_break(String var1, float var2, float var3, float var4, float var5) {
      int var6 = GL20.glGetUniformLocation((Integer)this.id_class[id_case[7]], var1);
      GL20.glUniform4f(var6, var2, var3, var4, var5);
   }

   public void id_break() {
      GL20.glUseProgram((id_protected[2] ? 1 : 0));
   }

   public void id_break(String var1, float var2, float var3) {
      int var4 = GL20.glGetUniformLocation((Integer)this.id_class[id_case[5]], var1);
      GL20.glUniform2f(var4, var2, var3);
   }

   private String id_break(InputStream var1) throws IOException {
      ByteArrayOutputStream var3 = new ByteArrayOutputStream();
      byte[] var4 = new byte[id_case[14]];

      int var2;
      while ((var2 = var1.read(var4, (id_protected[17] ? 1 : 0), var4.length)) != id_throws[16]) {
         var3.write(var4, (id_protected[18] ? 1 : 0), var2);
      }

      return var3.toString();
   }

   public static String id_break(String var0) throws Exception {
      Cipher var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeySpec var2 = new SecretKeySpec(new byte[]{-106, 72, 83, 13, 2, -124, -124, 79}, "DES");
      IvParameterSpec var3 = new IvParameterSpec(new byte[8]);
      var1.init(2, var2, var3);
      return new String(var1.doFinal(var0.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
   }

   private static void id_throws() {
      id_case = new short[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 4096, 0, 0, 0, 0, 512, 500, 0};
   }

   private static void id_finally() {
      id_throws = new byte[]{-1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 7, 10, 7, 2, 2, 3, -1};
   }

   private void id_catch() {
      if (this.id_class == null) {
         this.id_class = new Object[1];
         this.id_class[0] = 0;
      }
   }

   private static void id_extends() {
      id_protected = new boolean[]{
         false,
         true,
         false,
         false,
         false,
         true,
         false,
         true,
         false,
         true,
         true,
         false,
         true,
         false,
         true,
         false,
         false,
         false,
         false,
         false,
         true,
         false,
         false
      };
   }

   private static void id_case() {
      id_catch = new float[]{
         0.0F,
         0.0F,
         0.0F,
         0.0F,
         1.0F,
         0.0F,
         0.0F,
         0.0F,
         0.0F,
         0.0F,
         1.0F,
         0.0F,
         0.0F,
         0.0F,
         1.0F,
         1.0F,
         0.0F,
         0.0F,
         0.0F,
         0.0F,
         0.0F,
         1.0F,
         0.0F,
         1.0F,
         1.0F,
         0.0F,
         1.0F,
         0.0F,
         0.0F,
         0.0F,
         0.0F,
         0.0F,
         0.0F,
         1.0F,
         0.0F,
         1.0F,
         1.0F,
         0.0F,
         1.0F,
         0.0F
      };
   }

   private static void id_implements() {
      id_break = new int[]{35632, 35632, 35632, 35632, 35632, 35632, 35632, 35632, 35632, 35632, 35632, 35632, 35633, 35714, 35713, 35632, 35713};
   }

   private void id_protected(String var1) {
      try {
         String var2 = this.id_break(QY.id_instanceof().F().id_class(new rqO_2("celestial/shaders/" + var1 + ".glsl")).id_break());
         this.id_byte(var2.replace(id_byte[25], id_byte[26]).replace(id_byte[27], id_byte[28]));
      } catch (Exception var3) {
         var3.printStackTrace();
      }
   }

   public void id_protected() {
      ARBShaderObjects.glUseProgramObjectARB((Integer)this.id_class[id_case[10]]);
   }

   private static void id_private() {
      id_byte = new String[]{
         new String("rounded_rect"),
         new String("gradient_rounded_rect"),
         new String("glow_rect"),
         new String("outline_gradient_rect"),
         new String("substring_font"),
         new String("glow_esp"),
         new String("kawase_up_bloom"),
         new String("kawase_down_bloom"),
         new String("rounded_texture"),
         new String("targethud_head"),
         new String("colored_texture"),
         new String(
            "#version 120\n\nuniform vec2 location, rectSize;\nuniform vec4 color;\nuniform float radius;\n\nfloat roundSDF(vec2 p, vec2 b, float r) {\n    return length(max(abs(p) - b, 0.0)) - r;\n}\n\n\nvoid main() {\n    vec2 rectHalf = rectSize * .5;\n    // Smooth the result (free antialiasing).\n    float smoothedAlpha =  (1.0-smoothstep(0.0, 2.0, roundSDF(rectHalf - (gl_TexCoord[0].st * rectSize), rectHalf - radius - 1., radius))) * color.a;\n    gl_FragColor = vec4(color.rgb, smoothedAlpha);// mix(quadColor, shadowColor, 0.0);\n\n}"
         ),
         new String(
            "#version 120\n\nuniform float width;\nuniform float height;\nuniform vec4 color1, color2, color3, color4;\nuniform float radius;\n\nfloat roundSDF(vec2 p, vec2 b, float r) {\n    return length(max(abs(p) - b , 0.)) - r;\n}\n\nvec3 createGradient(vec2 coords, vec3 color1, vec3 color2, vec3 color3, vec3 color4){\n    vec3 color = mix(mix(color1.rgb, color2.rgb, coords.y), mix(color3.rgb, color4.rgb, coords.y), coords.x);\n    return color;\n}\n\nvoid main() {\n    vec2 rectSize = vec2(width, height);\n    vec2 st = gl_TexCoord[0].st;\n    vec2 halfSize = rectSize * .5;\n    float smoothedAlpha = (1. - smoothstep(0., 1., roundSDF(halfSize - (gl_TexCoord[0].st * rectSize), halfSize - radius - 1., radius))) * color1.a;\n    gl_FragColor = vec4(createGradient(st, color1.rgb, color2.rgb, color3.rgb, color4.rgb), smoothedAlpha);\n}"
         ),
         new String(
            "#version 120\n\nuniform float width;\nuniform float height;\nuniform vec4 color1, color2, color3, color4;\nuniform float radius, glowRadius;\n\nfloat roundSDF(vec2 p, vec2 b, float r) {\nreturn length(max(abs(p) - b , 0.)) - r;\n}\n\nvec3 createGradient(vec2 coords, vec3 color1, vec3 color2, vec3 color3, vec3 color4){\nvec3 color = mix(mix(color1.rgb, color2.rgb, coords.y), mix(color3.rgb, color4.rgb, coords.y), coords.x);\nreturn color;\n}\n\nvoid main() {\nvec2 rectSize = vec2(width, height);\nvec2 st = gl_TexCoord[0].st;\nvec2 halfSize = rectSize * 0.5;\nfloat dist = roundSDF(halfSize - (gl_TexCoord[0].st * rectSize), halfSize - (glowRadius + (radius * 0.75)), radius);\nfloat smoothedAlpha = (1.0-smoothstep(-glowRadius, glowRadius, dist)) * color1.a;\ngl_FragColor = mix(vec4(createGradient(st, color1.rgb, color2.rgb, color3.rgb, color4.rgb), 0.0f), vec4(createGradient(st, color1.rgb, color2.rgb, color3.rgb, color4.rgb), smoothedAlpha), smoothedAlpha);\n}\n"
         ),
         new String(
            "#version 120\n\nuniform float width;\nuniform float height;\nuniform float radius;\nuniform float thickness;\nuniform vec2 smoothness;\nuniform vec4 color;\nuniform vec4 color2;\nuniform vec4 color3;\nuniform vec4 color4;\n\nfloat dstfn(vec2 p, vec2 b, float r) {\n    return length(max(abs(p),b) - b) - r;\n}\n\nvoid main() {\n    vec2 size = vec2(width, height);\n    vec2 tex = gl_TexCoord[0].st;\n    vec2 pixel = tex * size;\n    vec2 centre = 0.5 * size;\n    float d = dstfn(centre - pixel, centre - radius - thickness, radius);\n    float sa = smoothstep(smoothness.x, smoothness.y, abs(d) / thickness);\n    vec4 c = mix(vec4(color.rgb, 1), vec4(color.rgb, 0), sa);\n    vec4 endColor = mix(mix(color, color2, tex.y), mix(color3,color4, tex.y), tex.x);\n    gl_FragColor = vec4(endColor.rgb, color.a * c.a);\n}\n"
         ),
         new String(
            "#version 120\nuniform sampler2D font;\nuniform vec4 inColor;\nuniform float width;\nuniform float maxWidth;\nuniform float smoothness;\nuniform float startCutoff;\n\nvoid main() {\n    float t = clamp((gl_FragCoord.x - maxWidth) / width, 0.0, 1.0);\n    float f = clamp(smoothstep(startCutoff, 1.0, 1.0 - smoothness * t), 0.0, 1.0);\n    vec2 pos = gl_TexCoord[0].xy;\n    vec4 color = texture2D(font, pos);\n\n    if (color.a > 0.0) {\n        color.a = color.a * f;\n    }\n\n    gl_FragColor = color * inColor;\n}\n"
         ),
         new String(
            "#version 120\n\nuniform sampler2D textureIn, textureToCheck;\nuniform vec2 texelSize, direction;\nuniform vec3 color1, color2, color3, color4, color5;\nuniform bool avoidTexture;\nuniform float exposure, radius, time;\nuniform float weights[256];\n\n#define offset direction * texelSize\n\nvoid main() {\n    if (direction.y == 1 && avoidTexture) {\n        if (texture2D(textureToCheck, gl_TexCoord[0].st).a != 0.0) discard;\n    }\n\n    float innerAlpha = texture2D(textureIn, gl_TexCoord[0].st).a * weights[0];\n\n    for (float r = 1.0; r <= radius; r ++) {\n        innerAlpha += texture2D(textureIn, gl_TexCoord[0].st + offset * r).a * weights[int(r)];\n        innerAlpha += texture2D(textureIn, gl_TexCoord[0].st - offset * r).a * weights[int(r)];\n    }\n\n    float r = length(gl_TexCoord[0].st - vec2(0.5));\n    float theta = atan((gl_TexCoord[0].st.y - 0.5) / (gl_TexCoord[0].st.x - 0.5)) + step(gl_TexCoord[0].st.x, 0.5) * 3.1415926535897932384626433832795;\n\n    vec3 color1 = color1;\n    vec3 color2 = color2;\n    vec3 color3 = color3;\n    vec3 color4 = color4;\n    vec3 color5 = color5;\n\n    vec3 color;\n    float t = mod(theta + time, 2.0 * 3.1415926535897932384626433832795) / (2.0 * 3.1415926535897932384626433832795);\n    if (t < 0.2) {\n        color = mix(color1, color2, smoothstep(0.0, 0.2, t));\n    } else if (t < 0.4) {\n        color = mix(color2, color3, smoothstep(0.2, 0.4, t));\n    } else if (t < 0.6) {\n        color = mix(color3, color4, smoothstep(0.4, 0.6, t));\n    } else if (t < 0.8) {\n        color = mix(color4, color5, smoothstep(0.6, 0.8, t));\n    } else {\n        color = mix(color5, color1, smoothstep(0.8, 1.0, t));\n    }\n\n    gl_FragColor = vec4(color, mix(innerAlpha, 1.0 - exp(-innerAlpha * exposure), step(0.0, direction.y)));\n}\n"
         ),
         new String(
            "#version 120\n\nuniform sampler2D inTexture, textureToCheck;\nuniform vec2 halfpixel, offset, iResolution;\nuniform int check;\n\nvoid main() {\n    vec2 uv = vec2(gl_FragCoord.xy / iResolution);\n\n    vec4 sum = texture2D(inTexture, uv + vec2(-halfpixel.x * 2.0, 0.0) * offset);\n    sum.rgb *= sum.a;\n    vec4 smpl1 =  texture2D(inTexture, uv + vec2(-halfpixel.x, halfpixel.y) * offset);\n    smpl1.rgb *= smpl1.a;\n    sum += smpl1 * 2.0;\n    vec4 smp2 = texture2D(inTexture, uv + vec2(0.0, halfpixel.y * 2.0) * offset);\n    smp2.rgb *= smp2.a;\n    sum += smp2;\n    vec4 smp3 = texture2D(inTexture, uv + vec2(halfpixel.x, halfpixel.y) * offset);\n    smp3.rgb *= smp3.a;\n    sum += smp3 * 2.0;\n    vec4 smp4 = texture2D(inTexture, uv + vec2(halfpixel.x * 2.0, 0.0) * offset);\n    smp4.rgb *= smp4.a;\n    sum += smp4;\n    vec4 smp5 = texture2D(inTexture, uv + vec2(halfpixel.x, -halfpixel.y) * offset);\n    smp5.rgb *= smp5.a;\n    sum += smp5 * 2.0;\n    vec4 smp6 = texture2D(inTexture, uv + vec2(0.0, -halfpixel.y * 2.0) * offset);\n    smp6.rgb *= smp6.a;\n    sum += smp6;\n    vec4 smp7 = texture2D(inTexture, uv + vec2(-halfpixel.x, -halfpixel.y) * offset);\n    smp7.rgb *= smp7.a;\n    sum += smp7 * 2.;\n    vec4 result = sum / 12.;\n    gl_FragColor = vec4(result.rgb / result.a, mix(result.a, result.a * (1. - texture2D(textureToCheck, gl_TexCoord[0].st).a),check));\n}\n"
         ),
         new String(
            "#version 120\n\nuniform sampler2D inTexture;\nuniform vec2 offset, halfpixel, iResolution;\n\nvoid main() {\n    vec2 uv = vec2(gl_FragCoord.xy / iResolution);\n    vec4 sum = texture2D(inTexture, gl_TexCoord[0].st);\n    sum.rgb *= sum.a;\n    sum *= 4.0;\n    vec4 smp1 = texture2D(inTexture, uv - halfpixel.xy * offset);\n    smp1.rgb *= smp1.a;\n    sum += smp1;\n    vec4 smp2 = texture2D(inTexture, uv + halfpixel.xy * offset);\n    smp2.rgb *= smp2.a;\n    sum += smp2;\n    vec4 smp3 = texture2D(inTexture, uv + vec2(halfpixel.x, -halfpixel.y) * offset);\n    smp3.rgb *= smp3.a;\n    sum += smp3;\n    vec4 smp4 = texture2D(inTexture, uv - vec2(halfpixel.x, -halfpixel.y) * offset);\n    smp4.rgb *= smp4.a;\n    sum += smp4;\n    vec4 result = sum / 8.;\n    gl_FragColor = vec4(result.rgb / result.a, result.a);\n}\n"
         ),
         new String(
            "uniform vec2 rectSize; // Координаты и размер прямоугольника\nuniform sampler2D textureIn; // Входная текстура\nuniform float radius, alpha; // Радиус закругления углов прямоугольника и прозрачность\n\n// Создаем функцию для определения расстояния от текущей позиции до края прямоугольника\nfloat roundedSDF(vec2 centerPos, vec2 size, float radius) {\n    return length(max(abs(centerPos) - size, 0.)) - radius;\n}\n\nvoid main() {\n    // Определяем расстояние от текущей позиции до края прямоугольника\n    float distance = roundedSDF((rectSize * .5) - (gl_TexCoord[0].st * rectSize), (rectSize * .5) - radius - 1., radius);\n    \n    // Создаем плавный переход от границы прямоугольника к прозрачной области\n    float smoothedAlpha = (1.0 - smoothstep(0.0, 2.0, distance)) * alpha;\n\n    // Создаем окончательный цвет пикселя, используя цвет из входной текстуры и плавный переход между границей прямоугольника и прозрачной областью\n    gl_FragColor = vec4(texture2D(textureIn, gl_TexCoord[0].st).rgb, smoothedAlpha);\n}\n"
         ),
         new String(
            "#version 120\n\nuniform sampler2D texture;\nuniform float width;\nuniform float height;\nuniform float radius;\nuniform float hurtStrength;\nuniform float alpha;\nuniform vec3 hurtColor;\n\nfloat dstfn(vec2 p, vec2 b, float r) {\n    return length(max(abs(p) - b, 0.)) - r;\n}\n\nvoid main() {\n    vec2 tex = gl_TexCoord[0].st;\n    vec2 clippedTexCoord = vec2(\n           mix(8.0 / 64.0, 16.0 / 64.0, tex.x),\n           mix(8.0 / 64.0, 16.0 / 64.0, tex.y)\n    );\n    vec4 smpl = texture2D(texture, clippedTexCoord);\n    vec2 size = vec2(width, height);\n    vec2 pixel = tex * size;\n    vec2 centre = .5 * size;\n    float sa = smoothstep(0., 1, dstfn(centre - pixel, centre - radius - 1, radius));\n    vec4 c = mix(vec4(smpl.rgb, 1), vec4(smpl.rgb, 0), sa);\n    gl_FragColor = vec4(mix(smpl.rgb, hurtColor, hurtStrength), c.a * alpha);\n}\n"
         ),
         new String(
            "        #version 120\n\n        uniform sampler2D texture;\n        uniform float width;\n        uniform float height;\n        uniform float radius;\n        uniform vec4 color1;\n        uniform vec4 color2;\n        uniform vec4 color3;\n        uniform vec4 color4;\n\n        vec3 createGradient(vec2 coords, vec3 color1, vec3 color2, vec3 color3, vec3 color4){\n        vec3 color = mix(mix(color1.rgb, color2.rgb, coords.y), mix(color3.rgb, color4.rgb, coords.y), coords.x);\n        return color;\n        }\n\n        float dstfn(vec2 p, vec2 b, float r) {\n        return length(max(abs(p) - b, 0.)) - r;\n        }\n\n        void main() {\n        vec2 tex = gl_TexCoord[0].st;\n        vec4 smpl = texture2D(texture, tex);\n        vec2 size = vec2(width, height);\n        vec2 pixel = gl_TexCoord[0].st * size;\n        vec2 centre = .5 * size;\n        float sa = smoothstep(0., 1, dstfn(centre - pixel, centre - radius - 1, radius));\n        vec4 c = mix(vec4(smpl.rgb, 1), vec4(smpl.rgb, 0), sa);\n        gl_FragColor = vec4(mix(smpl.rgb,createGradient(tex, color1.rgb, color2.rgb, color3.rgb, color4.rgb), smpl.a), smpl.a * c.a * color1.a);\n        }\n"
         ),
         new String("Shader failed to link!"),
         new String("celestial/shaders/vertex.vsh"),
         new String("Shader (%s) failed to compile!"),
         new String("PIDORAS"),
         new String("\n"),
         new String("gl_TexCoord[0];"),
         new String("gl_TexCoord[0].xy;"),
         new String("PC Issue: Shader program creation failed.")
      };
   }
}
