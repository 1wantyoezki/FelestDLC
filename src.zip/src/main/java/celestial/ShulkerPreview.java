package celestial;

import com.mojang.blaze3d.systems.RenderSystem;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class ShulkerPreview extends Module {
   private static float[] id_protected;
   private static byte[] id_throws;
   private static double[] id_catch;
   private static String[] id_private;
   public Object[] id_break;
   private static int[] id_implements;
   public static Object[] id_byte;
   private static short[] id_finally;
   private static boolean[] id_extends;

   public ShulkerPreview() {
      super(id_private[0], id_private[1], (Category)Category.staticFieldse67813cd60183787b1de54ac6b91c916[id_finally[0]]);
      this.id_while();
      rrIF var5 = new rrIF(id_private[2], (KeyBind)KeyBind.staticFields7d889755b225350f87e436adc34ba83e[id_finally[1]]);
      this.id_break[id_finally[2]] = var5;
      this.id_class((rrIF)this.id_break[id_finally[3]]);
   }

   private static void ntfClinit() {
      id_goto();
      id_continue();
      id_super();
      id_new();
      id_this();
      id_public();
      id_return();
      id_else();
   }

   static {
      ntfClinit();
   }

   private static void id_this() {
      id_catch = new double[1];
   }

   public static void id_class(Ml_1 var0, List<rdn_3> var1, float var2, float var3, float[] var4) {
      id_class(var0, var1, var2, var3, var4, id_protected[1]);
   }

   private void id_class(List<rdn_3> var1, vm_3 var2, rdn_3 var3, float[] var4) {
      this.id_while();
      Runnable var9 = () -> {
         try {
            rJr_1 var4x = (rJr_1)((cb_3)id_import.id_class[id_finally[31]]).id_implements[id_finally[32]];
            rrTN var5 = new rrTN(var1);
            cb_3 var10000 = (cb_3)id_import.id_class[id_finally[33]];
            rrTN var10 = var5;
            var10000.id_implements[id_finally[34]] = var10;
            id_import.id_break(new rrTW(var2, var4x, var5, var3.id_continue(), var4));
         } catch (Exception var11) {
            var11.printStackTrace();
            System.out.println("Failed to open Shulker Preview screen: " + var11.getMessage());
         }
      };
      this.id_break[id_finally[9]] = var9;
   }

   private static void id_class(List<rdn_3> var0) {
      int var1 = Math.min(var0.size(), id_throws[20]);
      if (var1 != 0) {
         QY var2 = QY.id_instanceof();
         Hz_1 var3 = var2.id_float();
         float var4 = var3.id_break;
         var3.id_break = id_protected[47];
         byte var5 = id_throws[21];
         byte var6 = id_throws[22];

         for (int var7 = (id_extends[43] ? 1 : 0); var7 < var1; var7++) {
            rdn_3 var8 = (rdn_3)var0.get(var7);
            if (var8 != null && !var8.id_class()) {
               int var9 = var7 / id_throws[23];
               int var10 = var7 % id_throws[24];
               int var11 = var5 + var10 * id_throws[25] + (id_extends[44] ? 1 : 0);
               int var12 = var6 + var9 * id_throws[26] + (id_extends[45] ? 1 : 0);
               var3.id_class(var8, (float)var11, (float)var12);
               var3.id_class((cm_3)var2.id_class[id_finally[28]], var8, var11, var12, null);
            }
         }

         var3.id_break = var4;
      }
   }

   public static void id_class(Ml_1 var0, List<? extends rrTu_1> var1) {
      if (!var1.isEmpty()) {
         QY var2 = QY.id_instanceof();
         Hz_1 var3 = var2.id_float();
         var2.A().id_class(fJ_2.id_class);
         var2.A().id_break(fJ_2.id_class).id_class(id_extends[3], id_extends[4]);
         RenderSystem.enableRescaleNormal();
         RenderSystem.enableAlphaTest();
         RenderSystem.defaultAlphaFunc();
         RenderSystem.enableBlend();
         RenderSystem.blendFunc(OP.SRC_ALPHA, MK.ONE_MINUS_SRC_ALPHA);
         RenderSystem.color4f(id_protected[7], id_protected[8], id_protected[9], id_protected[10]);
         Hd_1 var4 = var2.id_interface().id_break();
         Ml_1 var5 = (Ml_1)id_byte[id_finally[11]];
         int var6 = var1.size();
         if (((boolean[])id_byte[id_finally[12]]).length < var6) {
            boolean[] var23 = new boolean[var6];
            id_byte[id_finally[13]] = var23;
            boolean[] var24 = new boolean[var6];
            id_byte[id_finally[14]] = var24;
         }

         boolean var7 = id_extends[5];
         boolean var8 = id_extends[6];
         boolean var9 = id_extends[7];

         for (int var10 = (id_extends[8] ? 1 : 0); var10 < var6; var10++) {
            rrTu_1 var11 = (rrTu_1)var1.get(var10);
            float var12 = id_protected[11] + var10 * id_protected[12];
            var0.id_class();
            var0.id_class((double)var11.id_private(), (double)var11.id_break(), (double)var12);
            if (var11.id_class() != id_protected[13]) {
               var0.id_class(var11.id_class(), var11.id_class(), id_protected[14]);
            }

            id_class(var0, var11.id_throws(), id_extends[9]);
            if (var11.id_byte() != null) {
               ((cm_3)var2.id_class[id_finally[15]])
                  .id_class(
                     var11.id_byte().id_catch(),
                     id_protected[15],
                     id_protected[16],
                     id_implements[0],
                     id_extends[10],
                     var0.id_byte().id_class(),
                     var4,
                     id_extends[11],
                     (id_extends[12] ? 1 : 0),
                     id_implements[1]
                  );
               var9 = id_extends[13];
            }

            var0.id_break();
            IJ[] var13 = var11.id_catch();
            int var14 = Math.min(var11.id_protected().size(), id_throws[1]);
            boolean var15 = id_extends[14];
            boolean var16 = id_extends[15];

            for (int var17 = (id_extends[16] ? 1 : 0); var17 < var14; var17++) {
               IJ var18 = var13[var17];
               if (var18 != null) {
                  if (var18.id_byte()) {
                     var15 = id_extends[17];
                  } else {
                     var16 = id_extends[18];
                  }

                  if (var15 && var16) {
                     break;
                  }
               }
            }

            ((boolean[])id_byte[id_finally[16]])[var10] = var15;
            ((boolean[])id_byte[id_finally[17]])[var10] = var16;
            var7 |= var15;
            var8 |= var16;
         }

         if (var9) {
            var4.id_break();
         }

         if (var7) {
            for (int var25 = (id_extends[19] ? 1 : 0); var25 < var6; var25++) {
               if (((boolean[])id_byte[id_finally[18]])[var25]) {
                  id_class(var3, var4, var5, (rrTu_1)var1.get(var25), id_extends[20], id_protected[17] + var25 * id_protected[18]);
               }
            }

            var4.id_break();
         }

         if (var8) {
            HF.id_byte();

            for (int var26 = (id_extends[21] ? 1 : 0); var26 < var6; var26++) {
               if (((boolean[])id_byte[id_finally[19]])[var26]) {
                  id_class(var3, var4, var5, (rrTu_1)var1.get(var26), id_extends[22], id_protected[19] + var26 * id_protected[20]);
               }
            }

            var4.id_break();
            HF.id_protected();
         }

         boolean var27 = id_extends[23];

         for (int var28 = (id_extends[24] ? 1 : 0); var28 < var6; var28++) {
            if (id_class((cm_3)var2.id_class[id_finally[20]], var4, (rrTu_1)var1.get(var28), id_protected[21] + var28 * id_protected[22])) {
               var27 = id_extends[25];
            }
         }

         if (var27) {
            var4.id_break();
         }

         HF.id_break();
         RenderSystem.disableLighting();
         RenderSystem.disableRescaleNormal();
         RenderSystem.disableAlphaTest();
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.depthMask(id_extends[26]);
         RenderSystem.depthFunc(id_finally[21]);
         RenderSystem.enableDepthTest();
         RenderSystem.color4f(id_protected[23], id_protected[24], id_protected[25], id_protected[26]);
         HF.id_protected();
      }
   }

   public static void id_class(Ml_1 var0, List<rdn_3> var1, float var2, float var3, float[] var4, float var5) {
      var0.id_class();
      var0.id_class(var2, var3, id_catch[0]);
      if (var5 != id_protected[2]) {
         var0.id_class(var5, var5, id_protected[3]);
      }

      id_class(var0, var4, id_extends[2]);
      var0.id_break();
      RenderSystem.pushMatrix();
      RenderSystem.translatef(var2, var3, id_protected[4]);
      if (var5 != id_protected[5]) {
         RenderSystem.scalef(var5, var5, id_protected[6]);
      }

      id_class(var1);
      RenderSystem.popMatrix();
   }

   private static int id_class(int var0) {
      return Integer.rotateLeft(var0, 16) ^ 851305851;
   }

   private static long id_class(long var0) {
      return Long.rotateLeft(var0, 32) ^ -5663269859304031022L;
   }

   public static float[] id_class(rxL_2 var0) {
      return (float[])((Map)id_byte[id_finally[29]]).getOrDefault(var0, (float[])((Map)id_byte[id_finally[30]]).get(null));
   }

   @EventTarget
   public void id_class(j_1 var1) {
      this.id_while();
      Object var6 = null;
      this.id_break[id_finally[7]] = var6;
   }

   private static void id_class(Hz_1 var0, Hx_1 var1, Ml_1 var2, rrTu_1 var3, boolean var4, float var5) {
      List var6 = var3.id_protected();
      IJ[] var7 = var3.id_catch();
      int var8 = Math.min(var6.size(), id_throws[2]);
      float var9 = var3.id_class();
      float var10 = var3.id_private();
      float var11 = var3.id_break();

      for (int var12 = (id_extends[27] ? 1 : 0); var12 < var8; var12++) {
         rdn_3 var13 = (rdn_3)var6.get(var12);
         if (var13 != null && !var13.id_class()) {
            IJ var14 = var7[var12];
            if (var14 != null && var14.id_byte() == var4) {
               int var15 = var12 / id_throws[3];
               int var16 = var12 % id_throws[4];
               float var17 = var10 + (id_throws[5] + var16 * id_throws[6] + (id_extends[28] ? 1 : 0)) * var9;
               float var18 = var11 + (id_throws[7] + var15 * id_throws[8] + (id_extends[29] ? 1 : 0)) * var9;
               var2.id_class();
               var2.id_class((double)(var17 + id_protected[27] * var9), (double)(var18 + id_protected[28] * var9), (double)(var5 + id_protected[29]));
               var2.id_class(id_protected[30] * var9, id_protected[31] * var9, id_protected[32] * var9);
               var0.id_class(var13, IQ.GUI, id_extends[30], var2, var1, id_implements[2], fZ_2.id_class, var14);
               var2.id_break();
            }
         }
      }
   }

   @EventTarget
   public void id_class(rrnS_2 var1) {
      vm_3 var2 = var1.id_break();
      if (var2 instanceof Fu_1 var3) {
         rJY var4 = var3.id_int();
         vZ_2 var5 = var3.id_instanceof();
         if (var4 == null || var5 == null) {
            return;
         }

         Ml_1 var6 = var1.id_throws();
         rdn_3 var7 = var4.id_class();
         if (var7.id_break() instanceof rxJ_2 var8 && var8.id_catch() instanceof Wp_1 var9) {
            rxL_2 var16 = var9.id_break();
            List var11 = rrjm_3.id_class(var7);
            float[] var12 = this.id_break(var16);
            if (!var11.isEmpty()) {
               int var13 = (int)var5.id_class();
               int var14 = (int)(var5.id_break() + var5.id_protected() + id_protected[0]);
               this.id_class(var2, var11, var13, var14, var12, var6);
               this.id_class(var11, var2, var7, var12);
               var2.id_this = id_throws[0];
            }
         }
      }
   }

   @EventTarget
   public void id_class(rrLs_1 var1) {
      this.id_while();
      if (var1.id_protected() == ((rrIF)this.id_break[id_finally[4]]).id_finally().id_byte() && (Runnable)this.id_break[id_finally[5]] != null) {
         var1.id_class(id_extends[0]);
         ((Runnable)this.id_break[id_finally[6]]).run();
      }
   }

   public void id_class(vm_3 var1, List<rdn_3> var2, int var3, int var4, float[] var5, Ml_1 var6) {
      if (var1 != null) {
         var1.id_class(id_finally[10]);
      }

      id_class(var6, var2, var3, var4, var5);
      if (var1 != null) {
         var1.id_class(id_extends[1]);
      }
   }

   private static void id_class(Ml_1 var0, float[] var1, boolean var2) {
      QY var3 = QY.id_instanceof();
      var3.A().id_class(var2 ? (rqO_2)id_byte[id_finally[23]] : (rqO_2)id_byte[id_finally[24]]);
      RenderSystem.color4f(var1[(id_extends[39] ? 1 : 0)], var1[(id_extends[40] ? 1 : 0)], var1[id_throws[17]], id_protected[40]);
      byte var4 = var2 ? id_throws[18] : id_throws[19];
      ch_3.id_class(var0, (id_extends[41] ? 1 : 0), (id_extends[42] ? 1 : 0), id_protected[41], id_protected[42], id_finally[25], var4, id_finally[26], id_finally[27]);
      RenderSystem.color4f(id_protected[43], id_protected[44], id_protected[45], id_protected[46]);
   }

   private static boolean id_class(cm_3 var0, Hx_1 var1, rrTu_1 var2, float var3) {
      List var4 = var2.id_protected();
      int var5 = Math.min(var4.size(), id_throws[9]);
      float var6 = var2.id_class();
      Ml_1 var7 = (Ml_1)id_byte[id_finally[22]];
      var7.id_class();
      var7.id_class((double)var2.id_private(), (double)var2.id_break(), (double)(var3 + id_protected[33]));
      if (var6 != id_protected[34]) {
         var7.id_class(var6, var6, id_protected[35]);
      }

      boolean var8 = id_extends[31];

      for (int var9 = (id_extends[32] ? 1 : 0); var9 < var5; var9++) {
         rdn_3 var10 = (rdn_3)var4.get(var9);
         if (var10 != null && !var10.id_class() && var10.id_char() >= id_throws[10]) {
            int var11 = var9 / id_throws[11];
            int var12 = var9 % id_throws[12];
            String var13 = String.valueOf(var10.id_char());
            float var14 = id_throws[13] + var12 * id_throws[14] + (id_extends[33] ? 1 : 0);
            float var15 = id_throws[15] + var11 * id_throws[16] + (id_extends[34] ? 1 : 0);
            float var16 = var14 + id_protected[36] - id_protected[37] - var0.id_break(var13);
            float var17 = var15 + id_protected[38] + id_protected[39];
            var0.id_class(
               var13, var16, var17, id_implements[3], id_extends[35], var7.id_byte().id_class(), var1, id_extends[36], (id_extends[37] ? 1 : 0), id_implements[4]
            );
            var8 = id_extends[38];
         }
      }

      var7.id_break();
      return var8;
   }

   public static String id_break(String var0) throws Exception {
      Cipher var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeySpec var2 = new SecretKeySpec(new byte[]{11, 115, -7, -33, 30, -94, -52, -99}, "DES");
      IvParameterSpec var3 = new IvParameterSpec(new byte[8]);
      var1.init(2, var2, var3);
      return new String(var1.doFinal(var0.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
   }

   private float[] id_break(rxL_2 var1) {
      return id_class(var1);
   }

   @Override
   public void id_throws(boolean var1) {
      this.id_while();
      super.id_throws(var1);
      Object var6 = null;
      this.id_break[id_finally[8]] = var6;
   }

   private static void id_goto() {
      id_extends = new boolean[]{
         true,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         true,
         false,
         true,
         false,
         true,
         false,
         false,
         false,
         true,
         true,
         false,
         true,
         false,
         false,
         false,
         false,
         true,
         true,
         false,
         true,
         true,
         false,
         false,
         false,
         true,
         true,
         true,
         false,
         false,
         true,
         false,
         true,
         false,
         false,
         false,
         true,
         true,
         false,
         true,
         false,
         false
      };
   }

   private static void id_continue() {
      id_private = new String[]{
         new String("Shulker Preview"),
         new String("Отображает содержимое шалкера\nпри наведении на него"),
         new String("Открыть меню"),
         new String("celestial/images/shulker_preview/container_with_title.png"),
         new String("celestial/images/shulker_preview/container.png")
      };
   }

   private static void id_else() {
      Object[] var0 = new Object[]{
         new rqO_2(id_private[3]),
         new rqO_2(id_private[4]),
         18,
         9,
         3,
         10,
         176,
         78,
         68,
         0.0F,
         new Ml_1(),
         new Ml_1(),
         new boolean[0],
         new boolean[0],
         new rrTQ()
      };
      id_byte = var0;
   }

   private static void id_new() {
      id_protected = new float[]{
         2.0F,
         1.0F,
         1.0F,
         1.0F,
         32.0F,
         1.0F,
         1.0F,
         1.0F,
         1.0F,
         1.0F,
         1.0F,
         250.0F,
         25.0F,
         1.0F,
         1.0F,
         8.0F,
         6.0F,
         250.0F,
         25.0F,
         250.0F,
         25.0F,
         250.0F,
         25.0F,
         1.0F,
         1.0F,
         1.0F,
         1.0F,
         8.0F,
         8.0F,
         10.0F,
         16.0F,
         -16.0F,
         16.0F,
         20.0F,
         1.0F,
         1.0F,
         19.0F,
         2.0F,
         6.0F,
         3.0F,
         1.0F,
         0.0F,
         0.0F,
         1.0F,
         1.0F,
         1.0F,
         1.0F,
         300.0F,
         250.0F
      };
   }

   private static void id_return() {
      id_implements = new int[]{4210752, 15728880, 15728880, 16777215, 15728880};
   }

   private static void id_super() {
      id_finally = new short[]{
         2, 3, 1, 1, 1, 0, 0, 0, 0, 0, 200, 10, 12, 12, 13, 15, 12, 13, 12, 13, 15, 515, 11, 0, 1, 176, 256, 256, 15, 14, 14, 57, 4, 57, 4, 176
      };
   }

   private void id_while() {
      if (this.id_break == null) {
         this.id_break = new Object[2];
      }
   }

   private static void id_public() {
      id_throws = new byte[]{
         70,
         27,
         27,
         9,
         9,
         7,
         18,
         17,
         18,
         27,
         2,
         9,
         9,
         7,
         18,
         17,
         18,
         2,
         78,
         68,
         27,
         7,
         7,
         9,
         9,
         18,
         18,
         10,
         11,
         12,
         13,
         14,
         2,
         15,
         2,
         18,
         3,
         9,
         4,
         3,
         5,
         10,
         6,
         7,
         78,
         8,
         68,
         9
      };
   }
}
