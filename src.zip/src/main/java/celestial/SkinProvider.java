package celestial;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Iterables;
import com.google.common.collect.Maps;
import com.google.common.hash.Hashing;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import com.mojang.authlib.minecraft.MinecraftProfileTexture.Type;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import com.mojang.authlib.properties.Property;
import com.mojang.blaze3d.systems.RenderSystem;
import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class SkinProvider {
   private static final ExecutorService SKIN_EXECUTOR = Executors.newFixedThreadPool(2, runnable -> {
      Thread thread = new Thread(runnable, "Celestial-Skin-Worker");
      thread.setDaemon(true);
      return thread;
   });

   private final fY_2 id_class;
   private final File id_break;
   private final MinecraftSessionService id_byte;
   private final LoadingCache<String, Map<Type, MinecraftProfileTexture>> id_protected;

   public SkinProvider(fY_2 textureManager, File skinCacheDir, MinecraftSessionService sessionService) {
      this.id_class = textureManager;
      this.id_break = skinCacheDir;
      this.id_byte = sessionService;
      this.id_protected = CacheBuilder.newBuilder()
         .expireAfterAccess(15L, TimeUnit.SECONDS)
         .build(new jD_2(this, sessionService));
   }

   private void id_class(GameProfile profile, boolean requireSecure, jU_2 callback) {
      HashMap<Type, MinecraftProfileTexture> textures = Maps.newHashMap();

      try {
         textures.putAll(this.id_byte.getTextures(profile, requireSecure));
      } catch (Throwable ignored) {
      }

      if (textures.isEmpty()) {
         profile.getProperties().clear();
         if (profile.getId().equals(QY.id_instanceof().id_while().id_throws().getId())) {
            profile.getProperties().putAll(QY.id_instanceof().id_byte());

            try {
               textures.putAll(this.id_byte.getTextures(profile, false));
            } catch (Throwable ignored) {
            }
         } else {
            try {
               this.id_byte.fillProfileProperties(profile, requireSecure);
            } catch (Throwable ignored) {
            }

            try {
               textures.putAll(this.id_byte.getTextures(profile, requireSecure));
            } catch (Throwable ignored) {
            }
         }
      }

      QY.id_instanceof().execute(() -> this.id_class(textures, callback));
   }

   private void id_class(Map<Type, MinecraftProfileTexture> textures, jU_2 callback) {
      RenderSystem.recordRenderCall(() -> this.id_break(textures, callback));
   }

   private void id_break(Map<Type, MinecraftProfileTexture> textures, jU_2 callback) {
      ImmutableList.of(Type.SKIN, Type.CAPE).forEach(type -> this.id_class(textures, callback, type));
   }

   private void id_class(Map<Type, MinecraftProfileTexture> textures, jU_2 callback, Type type) {
      if (textures.containsKey(type)) {
         this.id_class(textures.get(type), type, callback);
      }
   }

   private static void id_class(jU_2 callback, Type type, rqO_2 resourceLocation, MinecraftProfileTexture texture) {
      if (callback != null) {
         callback.onSkinTextureAvailable(type, resourceLocation, texture);
      }
   }

   private rqO_2 id_class(MinecraftProfileTexture texture, Type type, jU_2 callback) {
      String hash = Hashing.sha1().hashUnencodedChars(texture.getHash()).toString();
      rqO_2 location = new rqO_2("skins/" + hash);
      ff_3 existing = this.id_class.id_break(location);
      if (existing != null) {
         if (callback != null) {
            callback.onSkinTextureAvailable(type, location, texture);
         }
      } else {
         File subDir = new File(this.id_break, hash.length() > 2 ? hash.substring(0, 2) : "xx");
         File targetFile = new File(subDir, hash);
         fd_3 downloadingTexture = new fd_3(
            targetFile,
            texture.getUrl(),
            jH_2.id_class(),
            type == Type.SKIN,
            () -> id_class(callback, type, location, texture)
         );
         this.id_class.id_class(location, downloadingTexture);
      }

      return location;
   }

   public rqO_2 id_class(MinecraftProfileTexture texture, Type type) {
      return this.id_class(texture, type, null);
   }

   public void id_class(GameProfile profile, jU_2 callback, boolean requireSecure) {
      SKIN_EXECUTOR.execute(() -> this.id_class(profile, requireSecure, callback));
   }

   public Map<Type, MinecraftProfileTexture> id_class(GameProfile profile) {
      Property property = Iterables.getFirst(profile.getProperties().get("textures"), null);
      return property == null ? ImmutableMap.of() : this.id_protected.getUnchecked(property.getValue());
   }
}
