package celestial;

import java.nio.charset.StandardCharsets;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class SwingAnimations extends Module {
   public Object[] id_break;
   private static double[] id_byte;
   private static short[] id_protected;
   private static float[] id_throws;
   private static String[] id_catch;
   private static boolean[] id_private;
   private static byte[] id_implements;

   public SwingAnimations() {
      super(id_catch[0], id_catch[1], (Category)Category.staticFieldse67813cd60183787b1de54ac6b91c916[id_protected[0]]);
      this.id_new();
      String var10003 = id_catch[2];
      String var10004 = id_catch[3];
      String[] var10005 = new String[id_implements[0]];
      var10005[(id_private[0] ? 1 : 0)] = id_catch[4];
      var10005[(id_private[1] ? 1 : 0)] = id_catch[5];
      var10005[id_implements[1]] = id_catch[6];
      rrIQ var5 = new rrIQ(var10003, var10004, var10005);
      this.id_break[id_protected[1]] = var5;
      rrIk_1 var6 = new rrIk_1(id_catch[7], id_private[2]);
      this.id_break[id_protected[2]] = var6;
      rrIm_1 var7 = new rrIm_1(id_catch[8], id_throws[0], id_throws[1], id_throws[2], id_throws[3]).id_class(() -> {
         this.id_new();
         return !((String)((rrIQ)this.id_break[id_protected[38]]).id_byte()).equals(id_catch[22]) ? id_private[19] : id_private[20];
      });
      this.id_break[id_protected[3]] = var7;
      rrIm_1 var8 = new rrIm_1(id_catch[9], id_throws[4], id_throws[5], id_throws[6], id_throws[7]);
      this.id_break[id_protected[4]] = var8;
      rrIm_1 var9 = new rrIm_1(id_catch[10], id_throws[8], id_throws[9], id_throws[10], id_throws[11]);
      this.id_break[id_protected[5]] = var9;
      rrIm_1 var10 = new rrIm_1(id_catch[11], id_throws[12], id_throws[13], id_throws[14], id_throws[15]);
      this.id_break[id_protected[6]] = var10;
      rrIm_1 var11 = new rrIm_1(id_catch[12], id_throws[16], id_throws[17], id_throws[18], id_throws[19]);
      this.id_break[id_protected[7]] = var11;
      rrIm_1 var12 = new rrIm_1(id_catch[13], id_throws[20], id_throws[21], id_throws[22], id_throws[23]);
      this.id_break[id_protected[8]] = var12;
      rrIm_1 var13 = new rrIm_1(id_catch[14], id_throws[24], id_throws[25], id_throws[26], id_throws[27]);
      this.id_break[id_protected[9]] = var13;
      rrIm_1 var14 = new rrIm_1(id_catch[15], id_throws[28], id_throws[29], id_throws[30], id_throws[31]);
      this.id_break[id_protected[10]] = var14;
      Setting[] var10001 = new Setting[id_implements[2]];
      byte var15 = (byte)(id_private[3] ? 1 : 0);
      String var10006 = id_catch[16];
      Setting[] var10007 = new Setting[id_implements[3]];
      var10007[(id_private[4] ? 1 : 0)] = (rrIQ)this.id_break[id_protected[11]];
      var10007[(id_private[5] ? 1 : 0)] = (rrIm_1)this.id_break[id_protected[12]];
      var10007[id_implements[4]] = (rrIm_1)this.id_break[id_protected[13]];
      var10001[var15] = new GroupSetting(var10006, var10007);
      byte var16 = (byte)(id_private[6] ? 1 : 0);
      var10006 = id_catch[17];
      var10007 = new Setting[id_implements[5]];
      var10007[(id_private[7] ? 1 : 0)] = (rrIm_1)this.id_break[id_protected[14]];
      var10007[(id_private[8] ? 1 : 0)] = (rrIm_1)this.id_break[id_protected[15]];
      var10007[id_implements[6]] = (rrIm_1)this.id_break[id_protected[16]];
      var10001[var16] = new GroupSetting(var10006, var10007);
      byte var17 = id_implements[7];
      var10006 = id_catch[18];
      var10007 = new Setting[id_implements[8]];
      var10007[(id_private[9] ? 1 : 0)] = (rrIm_1)this.id_break[id_protected[17]];
      var10007[(id_private[10] ? 1 : 0)] = (rrIm_1)this.id_break[id_protected[18]];
      var10007[id_implements[9]] = (rrIm_1)this.id_break[id_protected[19]];
      var10001[var17] = new GroupSetting(var10006, var10007);
      byte var18 = id_implements[10];
      var10006 = id_catch[19];
      var10007 = new Setting[(id_private[11] ? 1 : 0)];
      var10007[(id_private[12] ? 1 : 0)] = (rrIk_1)this.id_break[id_protected[20]];
      var10001[var18] = new GroupSetting(var10006, var10007);
      this.id_class(var10001);
   }

   private static void ntfClinit() {
      id_this();
      id_return();
      id_super();
      id_while();
      id_goto();
      id_public();
   }

   static {
      ntfClinit();
   }

   private static void id_this() {
      id_private = new boolean[]{
         false, true, false, false, false, true, true, false, true, false, true, true, false, true, false, true, false, true, true, true, false
      };
   }

   private static long id_class(long var0) {
      return Long.rotateLeft(var0, 32) ^ -2565377070511132123L;
   }

   private void id_class(Ml_1 var1, float var2, float var3) {
      this.id_new();
      float var4 = rfU_2.id_byte(var2);
      var1.id_class(rje_3.id_protected.id_byte(var3 * (id_throws[33] + rfU_2.id_class(var2 * var2 * id_throws[34]) / id_throws[35] * id_throws[36])));
      var1.id_class(rje_3.id_case.id_byte(var3 * rfU_2.id_class(var4 * id_throws[37]) * id_throws[38]));
      var1.id_class(rje_3.id_break.id_byte(rfU_2.id_class(var4 * id_throws[39]) * -(Float)((rrIm_1)this.id_break[id_protected[36]]).id_byte()));
      var1.id_class(rje_3.id_protected.id_byte(var3 * id_throws[40]));
   }

   @EventTarget
   public void id_class(rrAi_1 var1) {
      this.id_new();
      if (this.id_continue()) {
         Ml_1 var2 = var1.id_break();
         rpZ_2 var3 = var1.id_class();
         float var4 = var1.id_catch();
         byte var5 = (byte)(var3 == rpZ_2.RIGHT ? (id_private[13] ? 1 : 0) : id_implements[11]);
         switch (((int[])rrqj_3.id_class[id_protected[21]])[var1.id_throws().ordinal()]) {
            case 1:
               switch (((int[])rrqj_3.id_class[id_protected[22]])[var3.ordinal()]) {
                  case 1:
                     var2.id_class(
                        (double)((Float)((rrIm_1)this.id_break[id_protected[23]]).id_byte()).floatValue(),
                        (double)((Float)((rrIm_1)this.id_break[id_protected[24]]).id_byte()).floatValue(),
                        (double)((Float)((rrIm_1)this.id_break[id_protected[25]]).id_byte()).floatValue()
                     );
                     return;
                  case 2:
                     var2.id_class(
                        (double)((Float)((rrIm_1)this.id_break[id_protected[26]]).id_byte()).floatValue(),
                        (double)((Float)((rrIm_1)this.id_break[id_protected[27]]).id_byte()).floatValue(),
                        (double)((Float)((rrIm_1)this.id_break[id_protected[28]]).id_byte()).floatValue()
                     );
                     return;
                  default:
                     return;
               }
            case 2:
               if (var3 == ((Qw_1)id_import.id_class[id_protected[29]]).id_continue) {
                  String var6 = (String)((rrIQ)this.id_break[id_protected[30]]).id_byte();
                  byte var7 = id_implements[12];
                  switch (var6.hashCode()) {
                     case -1774937877:
                        if (var6.equals(id_catch[20])) {
                           var7 = (byte)(id_private[14] ? 1 : 0);
                        }
                        break;
                     case -1774937876:
                        if (var6.equals(id_catch[21])) {
                           var7 = (byte)(id_private[15] ? 1 : 0);
                        }
                  }

                  switch (var7) {
                     case 0:
                        this.id_class(var1, var2, var5);
                        this.id_class(var2, var4, var5);
                        break;
                     case 1:
                        this.id_class(var1, var2, var5);
                        this.id_break(var2, var4, var5);
                  }
               }
         }
      }
   }

   private void id_class(rrAi_1 var1, Ml_1 var2, int var3) {
      var1.id_class(id_private[18]);
      var2.id_class(var3 * id_throws[47], id_byte[2], id_byte[3]);
   }

   @EventTarget
   public void id_class(rrLl_1 var1) {
      this.id_new();
      if (this.id_continue()) {
         float var2 = ((rrIm_1)this.id_break[id_protected[31]]).id_native()
            - (Float)((rrIm_1)this.id_break[id_protected[32]]).id_byte()
            + ((rrIm_1)this.id_break[id_protected[33]]).id_class();
         var1.id_class(var2 * id_throws[32]);
      }
   }

   private static int id_class(int var0) {
      return Integer.rotateLeft(var0, 16) ^ 563666554;
   }

   private void id_break(Ml_1 var1, float var2, float var3) {
      this.id_new();
      var1.id_class(rje_3.id_protected.id_byte(var3 * id_throws[41]));
      var1.id_class(rje_3.id_case.id_byte(var3 * id_throws[42]));
      var1.id_class(
         rje_3.id_break
            .id_byte(
               id_throws[43]
                  - id_throws[44]
                     * (float)Math.sin(var2 * id_byte[0] * id_byte[1])
                     * (Float)((rrIm_1)this.id_break[id_protected[37]]).id_byte()
                     / id_throws[45]
            )
      );
      var1.id_class(rje_3.id_break.id_byte(var3 * id_throws[46]));
   }

   public static String id_break(String var0) throws Exception {
      Cipher var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeySpec var2 = new SecretKeySpec(new byte[]{114, -81, 7, -85, -2, 7, 116, 78}, "DES");
      IvParameterSpec var3 = new IvParameterSpec(new byte[8]);
      var1.init(2, var2, var3);
      return new String(var1.doFinal(var0.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
   }

   private static void id_goto() {
      id_byte = new double[]{Math.PI / 2, 2.0, -0.52F, -0.72F};
   }

   private boolean id_continue() {
      this.id_new();
      return ((rrIk_1)this.id_break[id_protected[34]]).id_class()
            && !((rrQX)rrQX.staticFields09f1f28026cd378cb9df490a64ac8f2a[id_protected[35]]).id_private().E().aJ_()
         ? id_private[16]
         : id_private[17];
   }

   private void id_new() {
      if (this.id_break == null) {
         this.id_break = new Object[10];
      }
   }

   private static void id_return() {
      id_catch = new String[]{
         new String("Swing Animations"),
         new String("Изменяет положение предметов\nв руках"),
         new String("Режим"),
         new String("Type 1"),
         new String("Type 1"),
         new String("Type 2"),
         new String("Default"),
         new String("Только с AttackAura"),
         new String("Сила"),
         new String("Скорость"),
         new String("X координата"),
         new String("Y координата"),
         new String("Z координата"),
         new String("X координата"),
         new String("Y координата"),
         new String("Z координата"),
         new String("Анимация"),
         new String("Позиция правой руки"),
         new String("Позиция левой руки"),
         new String("Другое"),
         new String("Type 1"),
         new String("Type 2"),
         new String("Default")
      };
   }

   private static void id_super() {
      id_protected = new short[]{2, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 2, 3, 7, 8, 9, 4, 5, 6, 1, 1, 0, 7, 8, 9, 4, 5, 6, 20, 0, 3, 3, 3, 1, 0, 2, 2, 0};
   }

   private static void id_while() {
      id_throws = new float[]{
         70.0F,
         10.0F,
         100.0F,
         10.0F,
         7.0F,
         1.0F,
         10.0F,
         1.0F,
         0.0F,
         -1.5F,
         1.5F,
         0.1F,
         0.0F,
         -1.5F,
         1.5F,
         0.1F,
         0.0F,
         -1.5F,
         1.5F,
         0.1F,
         0.0F,
         -1.5F,
         1.5F,
         0.1F,
         0.0F,
         -1.5F,
         1.5F,
         0.1F,
         0.0F,
         -1.5F,
         1.5F,
         0.1F,
         2.0F,
         45.0F,
         (float) Math.PI,
         4.0F,
         -20.0F,
         (float) Math.PI,
         -20.0F,
         (float) Math.PI,
         -45.0F,
         90.0F,
         -60.0F,
         -60.0F,
         40.0F,
         50.0F,
         -20.0F,
         0.56F
      };
   }

   private static void id_public() {
      id_implements = new byte[]{3, 2, 4, 3, 2, 3, 2, 2, 3, 2, 3, -1, -1, 10};
   }
}
