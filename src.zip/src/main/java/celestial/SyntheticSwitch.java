package celestial;

import java.nio.charset.StandardCharsets;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

// $VF: synthetic class
public class SyntheticSwitch {
   public static Object[] id_class;
   private static boolean[] id_break;
   private static byte[] id_byte;

   private static void id_byte() {
      id_break = new boolean[]{false, false, true, true, false, false, false, true};
   }

   private static void ntfClinit() {
      id_byte();
      id_class();
      id_break();
   }

   static {
      ntfClinit();
   }

   private static long id_class(long var0) {
      return Long.rotateLeft(var0, 32) ^ -4973301509855501414L;
   }

   public static String id_class(String var0) throws Exception {
      Cipher var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeySpec var2 = new SecretKeySpec(new byte[]{64, 94, -96, 52, -97, -104, -103, 70}, "DES");
      IvParameterSpec var3 = new IvParameterSpec(new byte[8]);
      var1.init(2, var2, var3);
      return new String(var1.doFinal(var0.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
   }

   private static void id_class() {
      id_byte = new byte[]{2, 2, 3};
   }

   private static int id_class(int var0) {
      return Integer.rotateLeft(var0, 16) ^ 748739808;
   }

   private static void id_break() {
      Object[] var0 = new Object[]{new int[]{3, 1, 2}};
      id_class = var0;
   }
}
