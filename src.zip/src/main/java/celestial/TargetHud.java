/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  celestial.FP
 *  celestial.Ml_1
 *  celestial.cb_3
 *  celestial.iB_2
 *  celestial.rfU_2
 *  celestial.rgF_2
 *  celestial.rql_3
 *  celestial.rrFA
 *  celestial.rrFC
 *  celestial.AnimValue
 *  celestial.rrQK
 *  celestial.rrQX
 *  celestial.rrZF
 *  celestial.FontManager
 *  celestial.rrfD_2
 *  celestial.ColorHelper
 *  celestial.rrfp_3
 *  celestial.rrfq_3
 *  celestial.StreamerMode
 *  celestial.TriggerBot
 *  celestial.AttackAura
 *  celestial.rrtu_3
 *  celestial.rrvT
 *  celestial.rrvj_1
 *  celestial.vm_3
 */
package celestial;

import celestial.FP;
import celestial.Ml_1;
import celestial.cb_3;
import celestial.iB_2;
import celestial.rfU_2;
import celestial.rgF_2;
import celestial.rql_3;
import celestial.rrFA;
import celestial.rrFC;
import celestial.AnimValue;
import celestial.rrQK;
import celestial.rrQX;
import celestial.rrZF;
import celestial.FontManager;
import celestial.rrfD_2;
import celestial.ColorHelper;
import celestial.rrfp_3;
import celestial.rrfq_3;
import celestial.StreamerMode;
import celestial.TriggerBot;
import celestial.AttackAura;
import celestial.rrtu_3;
import celestial.rrvT;
import celestial.rrvj_1;
import celestial.vm_3;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class TargetHud
extends rrvj_1 {
    private static byte[] id_native;
    public Object[] id_byte;
    private static short[] id_volatile;
    private static float[] id_final;
    private static boolean[] id_package;
    private static String[] id_int;
    public static Object[] id_protected;
    private static iB_2 lastTarget = null;
    private static long lastTargetTime = 0L;

    public TargetHud() {
        super(id_int[0], () -> Float.valueOf(id_final[48]), () -> Float.valueOf(id_final[47]));
        this.s();
        rrFC rrFC2 = new rrFC();
        this.id_byte[TargetHud.id_volatile[0]] = rrFC2;
        rrFA rrFA2 = new rrFA();
        this.id_byte[TargetHud.id_volatile[1]] = rrFA2;
        AnimValue rrNs_12 = new AnimValue((rrQK)rrQK.staticFieldsd7edc8a98bf936d38fa97cfea6cbd552[id_volatile[2]], id_final[0], id_package[0]);
        this.id_byte[TargetHud.id_volatile[3]] = rrNs_12;
        AnimValue rrNs_13 = new AnimValue((rrQK)rrQK.staticFieldsd7edc8a98bf936d38fa97cfea6cbd552[id_volatile[4]], id_final[1], id_package[1]);
        this.id_byte[TargetHud.id_volatile[5]] = rrNs_13;
    }

    static {
        TargetHud.ntfClinit();
    }

    private static void B() {
        float[] fArray = new float[53];
        fArray[0] = 0.4f;
        fArray[1] = 0.4f;
        fArray[2] = 10.0f;
        fArray[4] = 8.0f;
        fArray[5] = 4.0f;
        fArray[6] = 255.0f;
        fArray[8] = 255.0f;
        fArray[10] = 90.0f;
        fArray[11] = 270.0f;
        fArray[12] = 180.0f;
        fArray[13] = 4.0f;
        fArray[14] = 5.0f;
        fArray[15] = 5.0f;
        fArray[16] = 9.0f;
        fArray[17] = 33.0f;
        fArray[18] = 2.0f;
        fArray[19] = 2.5f;
        fArray[20] = 2.5f;
        fArray[21] = 20.0f;
        fArray[22] = 5.0f;
        fArray[23] = 1.0f;
        fArray[24] = 5.0f;
        fArray[25] = 2.0f;
        fArray[26] = 2.0f;
        fArray[27] = 2.0f;
        fArray[28] = 2.0f;
        fArray[29] = 1.0f;
        fArray[30] = 2.0f;
        fArray[31] = 1.0f;
        fArray[32] = 10.0f;
        fArray[33] = 2.0f;
        fArray[34] = 4.0f;
        fArray[35] = 4.0f;
        fArray[36] = 2.0f;
        fArray[37] = 2.0f;
        fArray[39] = 1.0f;
        fArray[40] = 5.0f;
        fArray[41] = 2.0f;
        fArray[42] = 2.0f;
        fArray[43] = 0.5f;
        fArray[44] = 2.0f;
        fArray[45] = 11.0f;
        fArray[47] = 33.0f;
        fArray[48] = 100.0f;
        fArray[49] = 100.0f;
        fArray[50] = 33.0f;
        fArray[51] = 4.0f;
        fArray[52] = 2.5f;
        id_final = fArray;
    }

    private static void S() {
        boolean[] blArray = new boolean[13];
        blArray[3] = true;
        blArray[7] = true;
        blArray[9] = true;
        blArray[12] = true;
        id_package = blArray;
    }

    private void s() {
        if (this.id_byte == null) {
            Object[] objectArray = this.id_byte = new Object[id_native[2]];
        }
    }

    private static void h() {
        id_int = new String[]{new String("Target HUD"), new String("HP: \u041d\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043d\u043e"), new String("HP: "), new String(" + "), new String(" AB")};
    }

    private void id_class(Ml_1 ml_1, iB_2 iB_22, float f, float f2, float f3, int n) {
        boolean bl = (rrfq_3)rrfp_3.id_class[id_volatile[17]] == (rrfq_3)rrfq_3.staticFields8f8c034c8eef39ccbbc33e665d937d16[id_volatile[18]] ? id_package[3] : id_package[4];
        StreamerMode rrlH_22 = ((rrQX)rrQX.staticFields09f1f28026cd378cb9df490a64ac8f2a[id_volatile[19]]).id_private().id_throws();
        String string = rrlH_22.id_break(iB_22.id_extends());
        ((FontManager)FontManager.staticFields71d6c26f697c30cf88e2ba2ddc0b4971[id_volatile[20]]).id_case().id_class(ml_1, string, f, f2, n, f3 * id_final[43] + id_final[44]);
        ((FontManager)FontManager.staticFields71d6c26f697c30cf88e2ba2ddc0b4971[id_volatile[21]]).id_native().id_break(ml_1, this.id_class(iB_22, bl), (double)f, (double)(f2 + id_final[45]), n, id_package[5], id_package[6]);
    }

    private static int id_class(int n) {
        return Integer.rotateLeft(n, 16) ^ 0x9C10B696;
    }

    public boolean id_class() {
        return id_package[9];
    }

    private String id_class(iB_2 iB_22, boolean bl) {
        this.s();
        if (bl && iB_22 != (cb_3)TargetHud.id_import.id_class[id_volatile[22]] && iB_22.Pp()) {
            return id_int[1];
        }
        StringBuilder stringBuilder = new StringBuilder(id_int[2]).append(rql_3.id_class((float)((AnimValue)this.id_byte[id_volatile[23]]).id_byte()));
        if (iB_22.Sd() > id_final[46] && !bl) {
            stringBuilder.append(rgF_2.GRAY).append(id_int[3]).append(rgF_2.YELLOW).append(rql_3.id_class((float)((AnimValue)this.id_byte[id_volatile[24]]).id_byte())).append(id_int[4]);
        }
        return stringBuilder.toString();
    }

    @Override
    public boolean aq_() {
        if (!this.id_package()) {
            return false;
        }
        return super.aq_();
    }

    @Override
    public void id_class(Ml_1 ml_1, rrtu_3 rrtu_32, int n, int n2, boolean bl) {
        this.s();
        if (!this.id_package()) {
            return;
        }
        super.id_class(ml_1, rrtu_32, n, n2, bl);
        iB_2 iB_23 = this.id_while();
        iB_2 iB_22 = iB_23 != null ? iB_23 : (iB_2)this.id_byte[id_volatile[7]];
        if (iB_22 == null) {
            return;
        }
        ((rrFA)this.id_byte[id_volatile[8]]).id_class(iB_22);
        ((AnimValue)this.id_byte[id_volatile[9]]).id_break(iB_22.u_());
        ((AnimValue)this.id_byte[id_volatile[10]]).id_break(iB_22.Sd());
        float f = this.id_long();
        float f2 = this.id_default() + this.id_implements();
        float f3 = this.id_abstract() - id_final[4] - id_final[5];
        ((rrFA)this.id_byte[id_volatile[11]]).id_class(ml_1, f2, f3, f);
        this.id_class(ml_1, iB_22);
    }

    private void id_class(Ml_1 ml_1, float f, float f2, float f3, float f4, int n, int n2, int n3, int n4, int n5) {
        rrfD_2.id_class((Ml_1)ml_1, (float)f, (float)f2, (float)(f3 - id_final[23]), (float)id_final[24], (float)id_final[25], (float)id_final[26], (float)id_final[27], (float)id_final[28], (int)ColorHelper.id_class((int)id_native[1], (int)n5));
        if (!((rrQX)rrQX.staticFields09f1f28026cd378cb9df490a64ac8f2a[id_volatile[16]]).id_private().w().id_goto()) {
            rrfD_2.id_class((Ml_1)ml_1, (float)(f - id_final[29]), (float)(f2 - id_final[30]), (float)(f4 + id_final[31]), (float)id_final[32], (float)id_final[33], (float)id_final[34], (int)n, (int)n2, (int)n3, (int)n4);
        }
        float f5 = f4 < id_final[35] || f4 > f3 - id_final[36] ? id_final[37] : id_final[38];
        rrfD_2.id_break((Ml_1)ml_1, (float)f, (float)f2, (float)(f4 - id_final[39]), (float)id_final[40], (float)id_final[41], (float)f5, (float)f5, (float)id_final[42], (int)n, (int)n2, (int)n3, (int)n4);
    }

    private void id_class(Ml_1 ml_1, iB_2 iB_22) {
        this.s();
        float f = this.id_default();
        float f2 = this.id_abstract();
        float f3 = this.id_implements();
        float f4 = this.id_long();
        int n = (int)rfU_2.id_class((float)(id_final[6] * f4), (float)id_final[7], (float)id_final[8]);
        int n2 = Math.min(n, id_volatile[12]);
        int n3 = ColorHelper.id_break((int)rrZF.d_, (int)n);
        int n4 = ColorHelper.id_class((float)id_final[9], (int)n2);
        int n5 = ColorHelper.id_class((float)id_final[10], (int)n2);
        int n6 = ColorHelper.id_class((float)id_final[11], (int)n2);
        int n7 = ColorHelper.id_class((float)id_final[12], (int)n2);
        byte by = id_native[0];
        float f5 = f + (float)by + id_final[13];
        float f6 = f2 + id_final[14];
        float f7 = f + (float)by + id_final[15];
        float f8 = f3 - (float)by - id_final[16];
        float f9 = iB_22.SK();
        float f10 = Math.min(((AnimValue)this.id_byte[id_volatile[13]]).id_byte(), f9) / f9 * f8;
        rrfD_2.id_class((Ml_1)ml_1, (float)f, (float)f2, (float)f3, (float)id_final[17], (int)n2, (int)n4, (int)n5, (int)n6, (int)n7, (boolean)id_package[2]);
        this.id_class(ml_1, iB_22, f5, f6, f3, n3);
        ((rrFC)this.id_byte[id_volatile[14]]).id_class(ml_1, iB_22, f + id_final[18], f2 + id_final[19], (int)by, (int)by, id_final[20], (float)((Integer)iB_22.id_private[id_volatile[15]]).intValue() / id_final[21], (float)n);
        this.id_class(ml_1, f7, f2 + (float)by - id_final[22], f8, f10, n4, n5, n6, n7, n);
    }

    private static long id_class(long l) {
        return Long.rotateLeft(l, 32) ^ 0xAA65956D44FE140DL;
    }

    public static String id_break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{99, 59, -93, 1, -125, -128, 9, -126}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static /* synthetic */ void ntfClinit() {
        TargetHud.S();
        TargetHud.h();
        TargetHud.M();
        TargetHud.B();
        TargetHud.G();
        TargetHud.E();
    }

    private static void M() {
        short[] sArray = new short[31];
        sArray[1] = 1;
        sArray[3] = 2;
        sArray[5] = 3;
        sArray[6] = 1;
        sArray[7] = 4;
        sArray[8] = 1;
        sArray[9] = 2;
        sArray[10] = 3;
        sArray[11] = 1;
        sArray[12] = 225;
        sArray[13] = 2;
        sArray[15] = 10;
        sArray[17] = 1;
        sArray[18] = 2;
        sArray[22] = 57;
        sArray[23] = 2;
        sArray[24] = 3;
        sArray[25] = 73;
        sArray[26] = 57;
        sArray[27] = 4;
        sArray[29] = 4;
        sArray[30] = 1;
        id_volatile = sArray;
    }

    private static void G() {
        id_native = new byte[]{28, 35, 5, 7, 2, 3, 5, 4, 2, 5, 6, 5};
    }

    public static boolean enabled = true;
    public static boolean testMode = false;

    public boolean id_package() {
        if (!enabled) {
            return false;
        }
        try {
            rrQX client = (rrQX) rrQX.staticFields09f1f28026cd378cb9df490a64ac8f2a[0];
            if (client != null && client.id_private() != null) {
                Hud cui = client.id_private().w();
                if (cui != null && (!cui.aJ_() || (cui.targetHudToggle != null && !cui.targetHudToggle.id_class()))) {
                    return false;
                }
            }
        } catch (Throwable ignored) {}
        return this.id_while() != null ? id_package[7] : id_package[8];
    }

    @Override
    public float id_default() {
        float x = super.id_default();
        float screenWidth = id_const != null ? id_const.id_volatile() : 640.0f;
        float width = this.id_implements();
        if (x > screenWidth - width - 10.0f) {
            x = Math.max(10.0f, screenWidth - width - 10.0f);
        }
        if (x < 10.0f) {
            x = 10.0f;
        }
        return x;
    }

    @Override
    public float id_abstract() {
        float y = super.id_abstract();
        float screenHeight = id_const != null ? id_const.id_final() : 360.0f;
        float height = this.id_import();
        if (y > screenHeight - height - 10.0f) {
            y = Math.max(10.0f, screenHeight - height - 10.0f);
        }
        if (y < 10.0f) {
            y = 10.0f;
        }
        return y;
    }

    public iB_2 id_while() {
        this.s();
        if (!enabled) {
            lastTarget = null;
            return null;
        }
        try {
            rrQX client = (rrQX) rrQX.staticFields09f1f28026cd378cb9df490a64ac8f2a[0];
            if (client != null && client.id_private() != null) {
                Hud cui = client.id_private().w();
                if (cui != null && (!cui.aJ_() || (cui.targetHudToggle != null && !cui.targetHudToggle.id_class()))) {
                    lastTarget = null;
                    return null;
                }
            }
        } catch (Throwable ignored) {}
        vm_3 screen = (TargetHud.id_import != null && TargetHud.id_import.id_class != null) ? (vm_3)TargetHud.id_import.id_class[id_volatile[25]] : null;
        if (this.id_super() || screen instanceof FP || testMode) {
            cb_3 cb_32 = (TargetHud.id_import != null && TargetHud.id_import.id_class != null) ? (cb_3)TargetHud.id_import.id_class[id_volatile[26]] : null;
            if (cb_32 != null) {
                this.id_byte[TargetHud.id_volatile[27]] = cb_32;
                return cb_32;
            }
        }
        rrvT rrvT2 = ((rrQX)rrQX.staticFields09f1f28026cd378cb9df490a64ac8f2a[id_volatile[28]]).id_private();
        AttackAura rrno_32 = rrvT2 != null ? rrvT2.E() : null;
        TriggerBot rrnV_22 = rrvT2 != null ? rrvT2.id_long() : null;
        iB_2 iB_22 = rrno_32 != null ? rrno_32.id_native() : null;
        if (iB_22 == null && rrnV_22 != null) {
            iB_22 = rrnV_22.id_native();
        }
        if (iB_22 == null && TargetHud.id_import != null && TargetHud.id_import.id_class != null) {
            an_3 target = TargetHud.id_import.id_catch();
            if (target instanceof iB_2 && target != TargetHud.id_import.id_class[id_volatile[26]]) {
                iB_2 living = (iB_2) target;
                if (living.u_() > 0.0f) {
                    iB_22 = living;
                }
            }
        }
        long now = System.currentTimeMillis();
        if (iB_22 != null) {
            lastTarget = iB_22;
            lastTargetTime = now;
            this.id_byte[TargetHud.id_volatile[29]] = iB_22;
        } else if (lastTarget != null && (now - lastTargetTime < 3500L) && lastTarget.u_() > 0.0f) {
            iB_22 = lastTarget;
            this.id_byte[TargetHud.id_volatile[29]] = iB_22;
        } else if (testMode && TargetHud.id_import != null && TargetHud.id_import.id_class != null) {
            cb_3 localPlayer = (cb_3)TargetHud.id_import.id_class[id_volatile[26]];
            if (localPlayer != null) {
                iB_22 = localPlayer;
                this.id_byte[TargetHud.id_volatile[29]] = iB_22;
            }
        }
        return iB_22;
    }

    public boolean id_protected() {
        return id_package[10];
    }

    private static void E() {
        Object[] objectArray = new Object[]{Float.valueOf(0.0f), Float.valueOf(0.0f), Float.valueOf(0.0f), 5, 2, Float.valueOf(0.0f), 5};
        id_protected = objectArray;
    }

    public void ar_() {
        this.s();
        super.ar_();
        ((rrFA)this.id_byte[id_volatile[30]]).id_break();
    }

    public float au_() {
        this.s();
        return ((rrFA)this.id_byte[id_volatile[6]]).id_class() ? id_final[2] : id_final[3];
    }
}
