package com.felest;

import com.felest.gui.GuiHandler;
import com.felest.module.ModuleManager;
import com.felest.module.impl.Aimbot;
import com.felest.module.impl.Arrows;
import com.felest.module.impl.AspectRatio;
import com.felest.module.impl.AutoSwap;
import com.felest.module.impl.Esp;
import com.felest.module.impl.FreeCam;
import com.felest.module.impl.Fullbright;
import com.felest.module.impl.Hud;
import com.felest.module.impl.MiniChat;
import com.felest.module.impl.NoRender;
import com.felest.module.impl.Optimization;
import com.felest.module.impl.Trajectories;
import com.felest.module.impl.TriggerBot;
import com.felest.render.ArrowsRenderer;
import com.felest.render.EspRenderer;
import com.felest.render.TrajectoriesRenderer;
import com.felest.util.ConfigManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;

public class FelestDLC implements ClientModInitializer {
    public static final String NAME = "FelestDLC";
    public static final String VERSION = "1.0.0";
    public static ModuleManager moduleManager;
    public static FreeCam freeCam;
    public static Aimbot aimbot;

    @Override
    public void onInitializeClient() {
        System.out.println("[FelestDLC] Загружен! Версия: " + VERSION);

        moduleManager = new ModuleManager();
        moduleManager.register(new TriggerBot());
        aimbot = new Aimbot();
        moduleManager.register(aimbot);
        freeCam = new FreeCam();
        moduleManager.register(freeCam);
        moduleManager.register(new Fullbright());
        moduleManager.register(new NoRender());
        moduleManager.register(new Optimization());
        moduleManager.register(new Hud());
        moduleManager.register(new AutoSwap());
        moduleManager.register(new Esp());
        moduleManager.register(new Trajectories());
        moduleManager.register(new AspectRatio());
        moduleManager.register(new Arrows());
        moduleManager.register(new MiniChat());

        EspRenderer.register();
        TrajectoriesRenderer.register();
        ArrowsRenderer.register();

        GuiHandler.register();
        ConfigManager.load();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            moduleManager.getModules().forEach(module -> {
                if (module.isEnabled()) module.onUpdate();
            });
        });

        // Aimbot обновляется КАЖДЫЙ КАДР — плавность без дёрганья
        WorldRenderEvents.START.register(context -> {
            if (aimbot != null && aimbot.isEnabled()) {
                aimbot.renderUpdate(context.tickCounter().getTickDelta(false));
            }
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            ConfigManager.save();
        });
    }
}
