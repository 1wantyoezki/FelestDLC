package com.felest;

import com.felest.gui.GuiHandler;
import com.felest.module.ModuleManager;
import com.felest.util.FontLoader;
import net.fabricmc.api.ClientModInitializer;

public class FelestDLC implements ClientModInitializer {
    public static final String NAME = "FelestDLC";
    public static final String VERSION = "1.0.0";
    public static ModuleManager moduleManager;

    @Override
    public void onInitializeClient() {
        System.out.println("[FelestDLC] Загружен! Версия: " + VERSION);

        FontLoader.load();

        moduleManager = new ModuleManager();
        // Регистрация модулей (пока пусто, потом добавим KillAura)
        // moduleManager.register(new KillAura());

        GuiHandler.register();
    }
}
