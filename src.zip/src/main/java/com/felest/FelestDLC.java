package com.felest;

import com.felest.gui.GuiHandler;
import com.felest.module.ModuleManager;
import com.felest.util.FontLoader;
import net.fabricmc.api.ClientModInitializer;

public class FelestDLC implements ClientModInitializer {
    public static final String MOD_ID = "felestdlc";
    public static final String MOD_NAME = "FelestDLC";
    public static final String VERSION = "1.0.0";

    @Override
    public void onInitializeClient() {
        System.out.println("[" + MOD_NAME + "] Загружен! Версия: " + VERSION);
        FontLoader.load();
        ModuleManager.init();
        GuiHandler.init();
    }
}
