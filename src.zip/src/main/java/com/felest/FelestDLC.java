package com.felest;

import com.felest.gui.GuiHandler;
import com.felest.module.ModuleManager;
import com.felest.module.impl.KillAura;
import com.felest.util.FontLoader;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class FelestDLC implements ClientModInitializer {
    public static final String NAME = "FelestDLC";
    public static final String VERSION = "1.0.0";
    public static ModuleManager moduleManager;

    @Override
    public void onInitializeClient() {
        System.out.println("[FelestDLC] Загружен! Версия: " + VERSION);

        FontLoader.load();

        moduleManager = new ModuleManager();
        moduleManager.register(new KillAura());

        GuiHandler.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            moduleManager.getModules().forEach(module -> {
                if (module.isEnabled()) module.onUpdate();
            });
        });
    }
}
