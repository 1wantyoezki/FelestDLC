package com.felest.gui;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.awt.Color;
import java.util.List;

public class ClickGUI extends Screen {

    private static final int BG_COLOR = new Color(15, 15, 20, 235).getRGB();
    private static final int PANEL_COLOR = new Color(28, 28, 34, 255).getRGB();
    private static final int HEADER_COLOR = new Color(20, 20, 25, 255).getRGB();
    private static final int ACCENT_COLOR = new Color(60, 130, 255).getRGB();
    private static final int TEXT_COLOR = new Color(220, 220, 220).getRGB();
    private static final int TEXT_DISABLED = new Color(110, 110, 120).getRGB();
    private static final int BORDER_COLOR = new Color(55, 55, 65).getRGB();

    private static final int PANEL_WIDTH = 450;
    private static final int PANEL_HEIGHT = 280;
    private static final int CATEGORY_WIDTH = 130;

    private Category selectedCategory = Category.COMBAT;

    public ClickGUI() {
        super(Text.literal("FelestDLC"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);

        int x = (this.width - PANEL_WIDTH) / 2;
        int y = (this.height - PANEL_HEIGHT) / 2;

        // Основной фон панели
        context.fill(x, y, x + PANEL_WIDTH, y + PANEL_HEIGHT, BG_COLOR);
        drawBorder(context, x, y, PANEL_WIDTH, PANEL_HEIGHT, BORDER_COLOR);

        // Заголовок
        context.fill(x, y, x + PANEL_WIDTH, y + 25, HEADER_COLOR);
        context.drawTextWithShadow(this.textRenderer, "FelestDLC", x + 8, y + 8, ACCENT_COLOR);
        context.drawTextWithShadow(this.textRenderer, "v1.0.0", x + 95, y + 8, TEXT_DISABLED);

        // Кнопка закрытия
        context.drawTextWithShadow(this.textRenderer, "X", x + PANEL_WIDTH - 15, y + 8, TEXT_COLOR);

        // Левая панель — категории
        int catX = x + 5;
        int catY = y + 30;
        context.fill(catX, catY, catX + CATEGORY_WIDTH, y + PANEL_HEIGHT - 5, PANEL_COLOR);

        int catOffset = 0;
        for (Category category : Category.values()) {
            int cY = catY + 5 + catOffset;
            boolean selected = (category == selectedCategory);

            if (selected) {
                context.fill(catX + 2, cY, catX + CATEGORY_WIDTH - 2, cY + 18, ACCENT_COLOR);
            }

            context.drawTextWithShadow(
                    this.textRenderer,
                    category.getName(),
                    catX + 8,
                    cY + 5,
                    selected ? 0xFFFFFF : TEXT_COLOR
            );
            catOffset += 20;
        }

        // Правая панель — модули
        int modX = catX + CATEGORY_WIDTH + 5;
        int modY = catY;
        context.fill(modX, modY, x + PANEL_WIDTH - 5, y + PANEL_HEIGHT - 5, PANEL_COLOR);

        List<Module> modules = ModuleManager.getModulesByCategory(selectedCategory);
        if (modules.isEmpty()) {
            context.drawTextWithShadow(this.textRenderer, "Нет модулей",
                    modX + 10, modY + 10, TEXT_DISABLED);
        } else {
            int modOffset = 0;
            for (Module module : modules) {
                int mY = modY + 5 + modOffset;
                int color = module.isEnabled() ? ACCENT_COLOR : TEXT_DISABLED;

                context.drawTextWithShadow(this.textRenderer, module.getName(), modX + 8, mY + 5, color);
                context.drawTextWithShadow(this.textRenderer, module.getDescription(),
                        modX + 8, mY + 18, new Color(100, 100, 110).getRGB());

                modOffset += 30;
            }
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int x = (this.width - PANEL_WIDTH) / 2;
        int y = (this.height - PANEL_HEIGHT) / 2;

        // Закрытие по X
        if (mouseX >= x + PANEL_WIDTH - 20 && mouseX <= x + PANEL_WIDTH - 5
                && mouseY >= y + 5 && mouseY <= y + 20) {
            this.close();
            return true;
        }

        // Клик по категориям
        int catX = x + 5;
        int catY = y + 30;
        int catOffset = 0;
        for (Category category : Category.values()) {
            int cY = catY + 5 + catOffset;
            if (mouseX >= catX + 2 && mouseX <= catX + CATEGORY_WIDTH - 2
                    && mouseY >= cY && mouseY <= cY + 18) {
                selectedCategory = category;
                return true;
            }
            catOffset += 20;
        }

        // Клик по модулям (ЛКМ — вкл/выкл)
        int modX = catX + CATEGORY_WIDTH + 5;
        int modY = catY;
        List<Module> modules = ModuleManager.getModulesByCategory(selectedCategory);
        int modOffset = 0;
        for (Module module : modules) {
            int mY = modY + 5 + modOffset;
            if (mouseX >= modX + 5 && mouseX <= x + PANEL_WIDTH - 10
                    && mouseY >= mY && mouseY <= mY + 28) {
                if (button == 0) {
                    module.toggle();
                }
                return true;
            }
            modOffset += 30;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void drawBorder(DrawContext context, int x, int y, int w, int h, int color) {
        context.fill(x, y, x + w, y + 1, color);
        context.fill(x, y + h - 1, x + w, y + h, color);
        context.fill(x, y, x + 1, y + h, color);
        context.fill(x + w - 1, y, x + w, y + h, color);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
