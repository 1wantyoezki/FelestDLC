package com.felest.gui;

import com.felest.FelestDLC;
import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class ClickGUI extends Screen {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    private Category selectedCategory = Category.Combat;
    private Module settingsModule = null;
    private final List<Module> visibleModules = new ArrayList<>();

    private final int BG_COLOR = new Color(20, 20, 25, 220).getRGB();
    private final int CAT_BG = new Color(30, 30, 40, 200).getRGB();
    private final int CAT_SELECTED = new Color(60, 120, 200, 255).getRGB();
    private final int TEXT_COLOR = new Color(220, 220, 230).getRGB();
    private final int ACCENT = new Color(80, 140, 220).getRGB();
    private final int SETTINGS_BG = new Color(15, 15, 20, 230).getRGB();
    private final int RADIUS = 6;

    public ClickGUI() {
        super(Text.literal("FelestDLC"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.getMatrices().push();
        context.getMatrices().scale(0.66f, 0.66f, 1.0f);

        int scaledMouseX = (int) (mouseX / 0.66f);
        int scaledMouseY = (int) (mouseY / 0.66f);

        int guiWidth = 420;
        int guiHeight = 260;
        int x = (int) ((mc.getWindow().getScaledWidth() / 0.66f - guiWidth) / 2);
        int y = (int) ((mc.getWindow().getScaledHeight() / 0.66f - guiHeight) / 2);

        // Фон
        drawRoundedRect(context, x, y, guiWidth, guiHeight, BG_COLOR, RADIUS);

        // Шапка
        context.drawTextWithShadow(mc.textRenderer, "FelestDLC", x + 12, y + 10, ACCENT);
        context.drawTextWithShadow(mc.textRenderer, "v0.0.1", x + 100, y + 10, new Color(150, 150, 160).getRGB());
        context.drawTextWithShadow(mc.textRenderer, "X", x + guiWidth - 18, y + 10, new Color(200, 80, 80).getRGB());

        // Категории слева
        int catY = y + 35;
        for (Category cat : Category.values()) {
            boolean hovered = scaledMouseX >= x + 5 && scaledMouseX <= x + 100 && scaledMouseY >= catY && scaledMouseY <= catY + 20;
            int color = (cat == selectedCategory) ? CAT_SELECTED : CAT_BG;
            if (hovered && cat != selectedCategory) color = new Color(50, 50, 65, 220).getRGB();
            drawRoundedRect(context, x + 5, catY, 95, 20, color, 4);
            context.drawTextWithShadow(mc.textRenderer, cat.name(), x + 12, catY + 6, TEXT_COLOR);
            catY += 24;
        }

        // Модули
        visibleModules.clear();
        int modY = y + 35;
        for (Module mod : FelestDLC.moduleManager.getModules(selectedCategory)) {
            visibleModules.add(mod);
            boolean hovered = scaledMouseX >= x + 110 && scaledMouseX <= x + guiWidth - 10 && scaledMouseY >= modY && scaledMouseY <= modY + 20;
            int color = mod.isEnabled() ? new Color(60, 120, 200, 200).getRGB() : CAT_BG;
            if (hovered) color = new Color(50, 50, 65, 220).getRGB();
            drawRoundedRect(context, x + 110, modY, guiWidth - 120, 20, color, 4);
            context.drawTextWithShadow(mc.textRenderer, mod.getName(), x + 118, modY + 6, mod.isEnabled() ? Color.WHITE.getRGB() : TEXT_COLOR);
            modY += 24;
        }

        if (visibleModules.isEmpty()) {
            context.drawTextWithShadow(mc.textRenderer, "Нет модулей", x + 120, y + 45, new Color(120, 120, 130).getRGB());
        }

        // Панель настроек слева
        if (settingsModule != null) {
            int sx = x - 150;
            int sy = y;
            int sWidth = 140;
            int sHeight = 40 + settingsModule.getSettings().size() * 22;

            drawRoundedRect(context, sx, sy, sWidth, sHeight, SETTINGS_BG, RADIUS);
            context.drawTextWithShadow(mc.textRenderer, settingsModule.getName(), sx + 10, sy + 10, ACCENT);

            int setY = sy + 30;
            for (Setting<?> set : settingsModule.getSettings()) {
                String valText;
                if (set.isBoolean()) {
                    valText = set.getName() + ": " + (((Boolean) set.getValue()) ? "ON" : "OFF");
                } else {
                    valText = set.getName() + ": " + set.getValue();
                }
                boolean hovered = scaledMouseX >= sx + 5 && scaledMouseX <= sx + sWidth - 5 && scaledMouseY >= setY && scaledMouseY <= setY + 20;
                if (hovered) {
                    drawRoundedRect(context, sx + 5, setY, sWidth - 10, 20, new Color(40, 40, 55, 220).getRGB(), 4);
                }
                context.drawTextWithShadow(mc.textRenderer, valText, sx + 10, setY + 6, TEXT_COLOR);
                setY += 22;
            }
        }

        context.getMatrices().pop();
        super.render(context, mouseX, mouseY, delta);
    }

    private void drawRoundedRect(DrawContext context, int x, int y, int width, int height, int color, int radius) {
        context.fill(x + radius, y, x + width - radius, y + height, color);
        context.fill(x, y + radius, x + radius, y + height - radius, color);
        context.fill(x + width - radius, y + radius, x + width, y + height - radius, color);
        context.fill(x + 1, y + 1, x + radius, y + radius, color);
        context.fill(x + width - radius, y + 1, x + width - 1, y + radius, color);
        context.fill(x + 1, y + height - radius, x + radius, y + height - 1, color);
        context.fill(x + width - radius, y + height - radius, x + width - 1, y + height - 1, color);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        double scaledMouseX = mouseX / 0.66;
        double scaledMouseY = mouseY / 0.66;

        int guiWidth = 420;
        int guiHeight = 260;
        int x = (int) ((mc.getWindow().getScaledWidth() / 0.66f - guiWidth) / 2);
        int y = (int) ((mc.getWindow().getScaledHeight() / 0.66f - guiHeight) / 2);

        // Закрыть
        if (scaledMouseX >= x + guiWidth - 20 && scaledMouseX <= x + guiWidth - 5 && scaledMouseY >= y + 5 && scaledMouseY <= y + 20) {
            this.close();
            return true;
        }

        // Клик по настройкам
        if (settingsModule != null) {
            int sx = x - 150;
            int sy = y;
            int sWidth = 140;
            int setY = sy + 30;
            for (Setting<?> set : settingsModule.getSettings()) {
                if (scaledMouseX >= sx + 5 && scaledMouseX <= sx + sWidth - 5 && scaledMouseY >= setY && scaledMouseY <= setY + 20) {
                    if (button == 0) { // ЛКМ
                        if (set.isBoolean()) {
                            set.setValue(!((Boolean) set.getValue()));
                        } else {
                            set.nextOption();
                        }
                    }
                    return true;
                }
                setY += 22;
            }
        }

        // Категории
        int catY = y + 35;
        for (Category cat : Category.values()) {
            if (scaledMouseX >= x + 5 && scaledMouseX <= x + 100 && scaledMouseY >= catY && scaledMouseY <= catY + 20) {
                selectedCategory = cat;
                settingsModule = null;
                return true;
            }
            catY += 24;
        }

        // Модули
        int modY = y + 35;
        for (Module mod : visibleModules) {
            if (scaledMouseX >= x + 110 && scaledMouseX <= x + guiWidth - 10 && scaledMouseY >= modY && scaledMouseY <= modY + 20) {
                if (button == 0) {
                    mod.toggle();
                } else if (button == 1) { // ПКМ — настройки
                    settingsModule = (settingsModule == mod) ? null : mod;
                }
                return true;
            }
            modY += 24;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
