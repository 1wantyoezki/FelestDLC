package com.felest.gui;

import com.felest.FelestDLC;
import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.module.impl.AutoSwap;
import com.felest.setting.Setting;
import com.felest.util.RenderUtil;
import com.felest.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class ClickGUI extends Screen {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    private static final float SCALE = 0.75f;

    private Category selectedCategory = Category.Combat;
    private Module settingsModule = null;
    private Module bindModule = null;
    private AutoSwap bindSwapModule = null;
    private Setting draggingSlider = null;

    private boolean searchActive = false;
    private String searchBuffer = "";

    private final Category[] CATEGORIES = {
            Category.Combat, Category.Movement, Category.Render, Category.Player, Category.Misc, Category.Themes
    };

    // Размеры
    private final int GUI_W = 400;
    private final int GUI_H = 240;
    private final int SIDE_W = 110;
    private final int HEADER_H = 28;
    private final int ROW_H = 30;

    // Цвета
    private final int BG = new Color(18, 18, 22, 245).getRGB();
    private final int BG_SIDE = new Color(24, 24, 30, 240).getRGB();
    private final int BG_ROW = new Color(32, 32, 40, 220).getRGB();
    private final int BG_ROW_HOVER = new Color(42, 42, 52, 240).getRGB();
    private final int TEXT = new Color(230, 230, 240).getRGB();
    private final int TEXT_DIM = new Color(120, 120, 135).getRGB();
    private final int TEXT_DESC = new Color(140, 140, 155).getRGB();
    private final int SEARCH_BG = new Color(28, 28, 34, 240).getRGB();
    private final int BORDER = new Color(45, 45, 55, 200).getRGB();

    public ClickGUI() { super(Text.literal("FelestDLC")); }

    private int accent() { return Theme.getAccent(); }

    private int gx() { return (int)((width / SCALE - GUI_W) / 2); }
    private int gy() { return (int)((height / SCALE - GUI_H) / 2); }

    private List<Module> filter(List<Module> in) {
        if (searchBuffer.isEmpty()) return in;
        String q = searchBuffer.toLowerCase();
        List<Module> out = new ArrayList<>();
        for (Module m : in) if (m.getName().toLowerCase().contains(q)) out.add(m);
        return out;
    }

    private String getCategoryIcon(Category c) {
        switch (c) {
            case Combat:   return "⚔";
            case Movement: return "»";
            case Render:   return "◈";
            case Player:   return "☺";
            case Misc:     return "✦";
            case Themes:   return "◐";
            default:       return "•";
        }
    }

    private String getCategoryName(Category c) {
        switch (c) {
            case Render: return "Visuals";
            default:     return c.name();
        }
    }

    private String getDescription(String moduleName) {
        switch (moduleName) {
            case "TriggerBot":  return "Auto-attack on crosshair";
            case "Aimbot":      return "Smooth aim on targets";
            case "AutoSwap":    return "Swap items to offhand";
            case "FreeCam":     return "Free camera movement";
            case "Fullbright":  return "Night vision effect";
            case "NoRender":    return "Disable weather and entities";
            case "Optimization":return "FPS boost, hide particles";
            case "HUD":         return "On-screen info overlay";
            case "ESP":         return "Highlight entities through walls";
            case "Trajectories":return "Projectile path preview";
            case "AspectRatio": return "Change render aspect";
            case "Arrows":      return "Player direction pointers";
            case "MiniChat":    return "Compact chat overlay";
            default:            return "";
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        int acc = accent();

        ctx.getMatrices().push();
        ctx.getMatrices().scale(SCALE, SCALE, 1f);

        int smx = (int)(mouseX / SCALE);
        int smy = (int)(mouseY / SCALE);

        int x = gx();
        int y = gy();

        // Основное окно
        RenderUtil.roundedRect(ctx, x + 3, y + 3, GUI_W, GUI_H, 10, new Color(0, 0, 0, 100).getRGB());
        RenderUtil.roundedRect(ctx, x, y, GUI_W, GUI_H, 10, BG);

        // Логотип F + название
        RenderUtil.roundedGradient(ctx, x + 10, y + 7, 16, 16, 4, acc, Theme.getAccent());
        ctx.drawTextWithShadow(mc.textRenderer, "F", x + 16, y + 11, 0xFFFFFFFF);
        ctx.drawTextWithShadow(mc.textRenderer, "FelestDLC", x + 32, y + 11, TEXT);

        // Поиск справа сверху
        int searchW = 150;
        int searchX = x + GUI_W - searchW - 10;
        int searchY = y + 7;
        int searchH = 16;
        RenderUtil.roundedRect(ctx, searchX, searchY, searchW, searchH, 5, SEARCH_BG);
        RenderUtil.roundedOutline(ctx, searchX, searchY, searchW, searchH, 5,
                searchActive ? acc : BORDER, 1);

        String searchTxt = searchBuffer.isEmpty() ? "Search..." : searchBuffer;
        int searchCol = searchBuffer.isEmpty() ? TEXT_DIM : TEXT;
        ctx.drawTextWithShadow(mc.textRenderer, "⌕", searchX + 5, searchY + 4, searchCol);
        ctx.drawTextWithShadow(mc.textRenderer, searchTxt, searchX + 16, searchY + 4, searchCol);

        // Разделитель под шапкой
        ctx.fill(x + 8, y + HEADER_H, x + GUI_W - 8, y + HEADER_H + 1, BORDER);

        // Сайдбар (слева)
        int sidebarH = GUI_H - HEADER_H - 12;
        RenderUtil.roundedRect(ctx, x + 6, y + HEADER_H + 6, SIDE_W, sidebarH, 6, BG_SIDE);

        int catY = y + HEADER_H + 12;
        for (Category cat : CATEGORIES) {
            boolean hovered = smx >= x + 8 && smx <= x + 8 + SIDE_W - 4 && smy >= catY && smy <= catY + 26;
            boolean selected = (cat == selectedCategory);

            if (selected) {
                RenderUtil.roundedRect(ctx, x + 8, catY, SIDE_W - 4, 26, 5, new Color(acc & 0x00FFFFFF | 0xB0000000, true).getRGB());
                // Цветная полоска слева
                RenderUtil.roundedRect(ctx, x + 8, catY + 4, 3, 18, 2, acc);
                // Иконка
                ctx.drawTextWithShadow(mc.textRenderer, getCategoryIcon(cat), x + 18, catY + 9, 0xFFFFFFFF);
                ctx.drawTextWithShadow(mc.textRenderer, getCategoryName(cat), x + 34, catY + 9, 0xFFFFFFFF);
            } else if (hovered) {
                RenderUtil.roundedRect(ctx, x + 8, catY, SIDE_W - 4, 26, 5, BG_ROW_HOVER);
                ctx.drawTextWithShadow(mc.textRenderer, getCategoryIcon(cat), x + 18, catY + 9, TEXT);
                ctx.drawTextWithShadow(mc.textRenderer, getCategoryName(cat), x + 34, catY + 9, TEXT);
            } else {
                ctx.drawTextWithShadow(mc.textRenderer, getCategoryIcon(cat), x + 18, catY + 9, TEXT_DIM);
                ctx.drawTextWithShadow(mc.textRenderer, getCategoryName(cat), x + 34, catY + 9, TEXT_DIM);
            }
            catY += 28;
        }

        // Правая часть — контент
        int contentX = x + SIDE_W + 14;
        int contentY = y + HEADER_H + 8;
        int contentW = GUI_W - SIDE_W - 22;
        int contentH = GUI_H - HEADER_H - 16;

        // ===== THEMES =====
        if (selectedCategory == Category.Themes) {
            int rowH = 22;
            int ty = contentY;
            for (String c : Theme.COLORS) {
                boolean isCur = Theme.current.equals(c);
                boolean hovered = smx >= contentX && smx <= contentX + contentW && smy >= ty && smy <= ty + rowH - 2;
                int col = Theme.getColorByName(c);

                if (isCur) {
                    RenderUtil.roundedRect(ctx, contentX, ty, contentW, rowH - 2, 5, new Color(col & 0x00FFFFFF | 0xC0000000, true).getRGB());
                    ctx.drawTextWithShadow(mc.textRenderer, c, contentX + 12, ty + 6, 0xFFFFFFFF);
                    ctx.drawTextWithShadow(mc.textRenderer, "✓", contentX + contentW - 16, ty + 6, 0xFFFFFFFF);
                } else if (hovered) {
                    RenderUtil.roundedRect(ctx, contentX, ty, contentW, rowH - 2, 5, BG_ROW_HOVER);
                    ctx.drawTextWithShadow(mc.textRenderer, c, contentX + 12, ty + 6, TEXT);
                } else {
                    RenderUtil.roundedRect(ctx, contentX, ty, contentW, rowH - 2, 5, BG_ROW);
                    ctx.drawTextWithShadow(mc.textRenderer, c, contentX + 12, ty + 6, TEXT_DIM);
                }
                // Квадратик цвета слева
                RenderUtil.roundedRect(ctx, contentX + contentW - 30, ty + 5, 12, 12, 3, col);
                ty += rowH;
            }
        } else {
            // ===== МОДУЛИ =====
            List<Module> mods = filter(FelestDLC.moduleManager.getModules(selectedCategory));

            if (mods.isEmpty()) {
                ctx.drawTextWithShadow(mc.textRenderer, "No modules", contentX + 8, contentY + 8, TEXT_DIM);
            } else {
                int maxRows = Math.max(1, (contentH - 4) / ROW_H);
                int drawn = 0;
                for (Module mod : mods) {
                    if (drawn >= maxRows) break;
                    int ry = contentY + drawn * ROW_H;

                    boolean hovered = smx >= contentX && smx <= contentX + contentW && smy >= ry && smy <= ry + ROW_H - 4;
                    boolean enabled = mod.isEnabled();

                    RenderUtil.roundedRect(ctx, contentX, ry, contentW, ROW_H - 4, 6,
                            hovered ? BG_ROW_HOVER : BG_ROW);

                    // Тумблер (квадратик) слева
                    int toggleColor = enabled ? acc : new Color(60, 60, 70, 220).getRGB();
                    RenderUtil.roundedRect(ctx, contentX + 6, ry + 6, 14, 14, 4, toggleColor);
                    if (enabled) {
                        ctx.drawTextWithShadow(mc.textRenderer, "✓", contentX + 9, ry + 9, 0xFFFFFFFF);
                    }

                    // Название
                    int nameColor = enabled ? 0xFFFFFFFF : TEXT;
                    ctx.drawTextWithShadow(mc.textRenderer, mod.getName(), contentX + 26, ry + 5, nameColor);

                    // Описание под названием
                    String desc = getDescription(mod.getName());
                    if (!desc.isEmpty()) {
                        ctx.getMatrices().push();
                        ctx.getMatrices().translate(contentX + 26, ry + 15, 0);
                        ctx.getMatrices().scale(0.7f, 0.7f, 1f);
                        ctx.drawTextWithShadow(mc.textRenderer, desc, 0, 0, TEXT_DESC);
                        ctx.getMatrices().pop();
                    }

                    // Бинд клавиши справа
                    if (bindModule == mod) {
                        int bColor = 0xFFEEDD55;
                        ctx.drawTextWithShadow(mc.textRenderer, "[...]", contentX + contentW - 36, ry + 10, bColor);
                    } else if (mod.getKeyBind() != -1) {
                        String key = GLFW.glfwGetKeyName(mod.getKeyBind(), 0);
                        if (key == null) key = "?";
                        key = key.toUpperCase();
                        int kw = mc.textRenderer.getWidth(key);
                        int kx = contentX + contentW - kw - 14;
                        RenderUtil.roundedRect(ctx, kx - 4, ry + 8, kw + 10, 14, 3,
                                enabled ? acc : new Color(60, 60, 70, 220).getRGB());
                        ctx.drawTextWithShadow(mc.textRenderer, key, kx + 1, ry + 11, 0xFFFFFFFF);
                    }

                    drawn++;
                }
            }
        }

        // Панель настроек
        if (settingsModule != null) {
            int sw = 140;
            int sx = x - sw - 12;
            if (sx < 6) sx = 6;
            int sy = y;
            boolean isAS = settingsModule instanceof AutoSwap;
            int extra = isAS ? 20 : 0;
            int sHeight = 34 + settingsModule.getSettings().size() * 18 + extra;

            RenderUtil.shadow(ctx, sx, sy, sw, sHeight, 8);
            RenderUtil.roundedRect(ctx, sx, sy, sw, sHeight, 8, BG);
            RenderUtil.roundedOutline(ctx, sx - 1, sy - 1, sw + 2, sHeight + 2, 9, BORDER, 1);

            ctx.drawTextWithShadow(mc.textRenderer, settingsModule.getName(), sx + 10, sy + 10, acc);
            ctx.fill(sx + 8, sy + 24, sx + sw - 8, sy + 25, BORDER);

            int setY = sy + 30;
            for (Setting set : settingsModule.getSettings()) {
                String val;
                if (set.isSlider()) val = set.getName() + ": " + String.format("%.2f", set.getFloat());
                else if (set.isBoolean()) val = set.getName() + ": " + (set.getBool() ? "ON" : "OFF");
                else val = set.getName() + ": " + set.getString();

                boolean hovered = smx >= sx + 5 && smx <= sx + sw - 5 && smy >= setY && smy <= setY + 16;
                if (hovered) RenderUtil.roundedRect(ctx, sx + 5, setY, sw - 10, 16, 4, BG_ROW_HOVER);
                ctx.drawTextWithShadow(mc.textRenderer, val, sx + 10, setY + 4, TEXT);

                if (set.isSlider()) {
                    float pct = (set.getFloat() - set.getMin()) / (set.getMax() - set.getMin());
                    int barY = setY + 14;
                    RenderUtil.roundedRect(ctx, sx + 10, barY, sw - 20, 2, 1, new Color(60, 60, 70).getRGB());
                    RenderUtil.roundedRect(ctx, sx + 10, barY, (int)((sw - 20) * pct), 2, 1, acc);
                }
                setY += 18;
            }

            if (isAS) {
                AutoSwap as = (AutoSwap) settingsModule;
                String txt;
                if (bindSwapModule == as) txt = "Key: [...]";
                else if (as.swapKey != -1) txt = "Key: " + GLFW.glfwGetKeyName(as.swapKey, 0);
                else txt = "Key: none";
                boolean hovered = smx >= sx + 5 && smx <= sx + sw - 5 && smy >= setY && smy <= setY + 16;
                if (hovered) RenderUtil.roundedRect(ctx, sx + 5, setY, sw - 10, 16, 4, BG_ROW_HOVER);
                ctx.drawTextWithShadow(mc.textRenderer, txt, sx + 10, setY + 4, TEXT);
            }
        }

        ctx.getMatrices().pop();
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        double smx = mouseX / SCALE;
        double smy = mouseY / SCALE;
        int x = gx(), y = gy();

        int searchW = 150;
        int searchX = x + GUI_W - searchW - 10;
        int searchY = y + 7;
        if (smx >= searchX && smx <= searchX + searchW && smy >= searchY && smy <= searchY + 16) {
            if (button == 0) { searchActive = true; return true; }
        } else {
            searchActive = false;
        }

        // Настройки
        if (settingsModule != null) {
            int sw = 140;
            int sx = x - sw - 12;
            if (sx < 6) sx = 6;
            int setY = y + 30;
            for (Setting set : settingsModule.getSettings()) {
                if (smx >= sx + 5 && smx <= sx + sw - 5 && smy >= setY && smy <= setY + 16) {
                    if (button == 0) {
                        if (set.isSlider()) { draggingSlider = set; applySlider(set, smx, sx, sw); }
                        else if (set.isBoolean()) set.setValue(!set.getBool());
                        else set.nextOption();
                    }
                    return true;
                }
                setY += 18;
            }
            if (settingsModule instanceof AutoSwap) {
                if (smx >= sx + 5 && smx <= sx + sw - 5 && smy >= setY && smy <= setY + 16) {
                    if (button == 0) bindSwapModule = (AutoSwap) settingsModule;
                    return true;
                }
            }
        }

        // Категории
        int catY = y + HEADER_H + 12;
        for (Category cat : CATEGORIES) {
            if (smx >= x + 8 && smx <= x + 8 + SIDE_W - 4 && smy >= catY && smy <= catY + 26) {
                selectedCategory = cat;
                settingsModule = null;
                return true;
            }
            catY += 28;
        }

        // Контент
        int contentX = x + SIDE_W + 14;
        int contentY = y + HEADER_H + 8;
        int contentW = GUI_W - SIDE_W - 22;
        int contentH = GUI_H - HEADER_H - 16;

        if (selectedCategory == Category.Themes) {
            int rowH = 22;
            int ty = contentY;
            for (String c : Theme.COLORS) {
                if (smx >= contentX && smx <= contentX + contentW && smy >= ty && smy <= ty + rowH - 2) {
                    if (button == 0) { Theme.current = c; com.felest.util.ConfigManager.save(); }
                    return true;
                }
                ty += rowH;
            }
        } else {
            List<Module> mods = filter(FelestDLC.moduleManager.getModules(selectedCategory));
            int maxRows = Math.max(1, (contentH - 4) / ROW_H);
            int drawn = 0;
            for (Module mod : mods) {
                if (drawn >= maxRows) break;
                int ry = contentY + drawn * ROW_H;
                if (smx >= contentX && smx <= contentX + contentW && smy >= ry && smy <= ry + ROW_H - 4) {
                    if (button == 0) mod.toggle();
                    else if (button == 1) settingsModule = (settingsModule == mod) ? null : mod;
                    else if (button == 2) bindModule = mod;
                    return true;
                }
                drawn++;
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (draggingSlider != null && button == 0) {
            double smx = mouseX / SCALE;
            int sw = 140;
            int x = gx();
            int sx = x - sw - 12;
            if (sx < 6) sx = 6;
            applySlider(draggingSlider, smx, sx, sw);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (draggingSlider != null) { draggingSlider = null; return true; }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    private void applySlider(Setting set, double mouseX, int sx, int sw) {
        float pct = (float)(mouseX - (sx + 10)) / (float)(sw - 20);
        set.setFromPercent(Math.max(0f, Math.min(1f, pct)));
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searchActive) {
            if (chr >= 32 && chr < 127 && searchBuffer.length() < 20) searchBuffer += chr;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (searchActive) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!searchBuffer.isEmpty()) searchBuffer = searchBuffer.substring(0, searchBuffer.length() - 1);
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER) {
                searchActive = false;
                return true;
            }
            return true;
        }
        if (bindModule != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE) bindModule.setKeyBind(-1);
            else bindModule.setKeyBind(keyCode);
            bindModule = null;
            return true;
        }
        if (bindSwapModule != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE) bindSwapModule.swapKey = -1;
            else bindSwapModule.swapKey = keyCode;
            bindSwapModule = null;
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() { return false; }
}
