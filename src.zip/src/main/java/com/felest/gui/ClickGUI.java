package com.felest.gui;

import com.felest.FelestDLC;
import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.module.impl.AutoSwap;
import com.felest.setting.Setting;
import com.felest.util.RenderUtil;
import com.felest.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class ClickGUI extends Screen {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    private static final float SCALE = 0.7f;

    private Module settingsModule = null;
    private Module bindModule = null;
    private AutoSwap bindSwapModule = null;
    private Setting draggingSlider = null;

    // Поиск
    private boolean searchActive = false;
    private String searchBuffer = "";
    private static final String SEARCH_HINT = "Поиск...";

    // Категории-колонки
    private final Category[] COLUMNS = {
            Category.Combat,
            Category.Movement,
            Category.Render,
            Category.Player,
            Category.Misc
    };

    // Размеры
    private final int COL_W = 130;
    private final int GAP = 8;
    private final int HEADER_H = 22;
    private final int ROW_H = 20;
    private final int PAD = 12;
    private final int SEARCH_H = 22;

    private final int BG = new Color(14, 14, 20, 240).getRGB();
    private final int HEADER_BG = new Color(28, 28, 38, 240).getRGB();
    private final int ROW_BG = new Color(22, 22, 30, 220).getRGB();
    private final int ROW_HOVER = new Color(38, 38, 50, 240).getRGB();
    private final int TEXT = new Color(220, 220, 230).getRGB();
    private final int TEXT_DIM = new Color(130, 130, 145).getRGB();
    private final int SEARCH_BG = new Color(10, 10, 16, 230).getRGB();

    public ClickGUI() { super(Text.literal("FelestDLC")); }

    private int accent() { return Theme.getAccent(); }

    private String displayName(Category cat) {
        switch (cat) {
            case Render: return "Visuals";
            default: return cat.name();
        }
    }

    // Общая ширина панели
    private int totalWidth() {
        return COLUMNS.length * COL_W + (COLUMNS.length - 1) * GAP;
    }

    // Фильтр модулей (поиск)
    private List<Module> filter(List<Module> in) {
        if (searchBuffer.isEmpty()) return in;
        String q = searchBuffer.toLowerCase();
        List<Module> out = new ArrayList<>();
        for (Module m : in) if (m.getName().toLowerCase().contains(q)) out.add(m);
        return out;
    }

    private int maxColumnHeight() {
        int max = 0;
        for (Category cat : COLUMNS) {
            List<Module> mods = filter(FelestDLC.moduleManager.getModules(cat));
            int h = HEADER_H + Math.max(1, mods.size()) * ROW_H;
            if (h > max) max = h;
        }
        return max;
    }

    private int gx() {
        int totalW = totalWidth();
        int panelW = totalW + PAD * 2;
        return (int)((width / SCALE - panelW) / 2);
    }

    private int gy() {
        int panelH = PAD * 2 + maxColumnHeight() + 10 + SEARCH_H;
        return (int)((height / SCALE - panelH) / 2);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        int acc = accent();
        int acc2 = Theme.getColorByName(Theme.current) & 0x00FFFFFF;
        int accLighter = (0xFF << 24) | Math.min(255, ((acc2 >> 16) & 0xFF) + 60) << 16
                | Math.min(255, ((acc2 >> 8) & 0xFF) + 60) << 8 | Math.min(255, (acc2 & 0xFF) + 60);

        ctx.getMatrices().push();
        ctx.getMatrices().scale(SCALE, SCALE, 1f);

        int smx = (int)(mouseX / SCALE);
        int smy = (int)(mouseY / SCALE);

        int panelX = gx();
        int panelY = gy();
        int colMaxH = maxColumnHeight();
        int panelW = totalWidth() + PAD * 2;
        int panelH = PAD * 2 + colMaxH + 10 + SEARCH_H;

        // Тень + фон
        RenderUtil.shadow(ctx, panelX, panelY, panelW, panelH, 12);
        RenderUtil.roundedRect(ctx, panelX, panelY, panelW, panelH, 12, BG);

        // Колонки
        int colX = panelX + PAD;
        int colY = panelY + PAD;

        for (Category cat : COLUMNS) {
            List<Module> mods = filter(FelestDLC.moduleManager.getModules(cat));

            // Заголовок колонки
            RenderUtil.roundedGradient(ctx, colX, colY, COL_W, HEADER_H, 6, accLighter, acc);
            int headerTextW = mc.textRenderer.getWidth(displayName(cat));
            ctx.drawTextWithShadow(mc.textRenderer, displayName(cat),
                    colX + (COL_W - headerTextW) / 2, colY + 7, 0xFFFFFFFF);

            // Модули
            int rowY = colY + HEADER_H + 2;
            if (mods.isEmpty()) {
                RenderUtil.roundedRect(ctx, colX, rowY, COL_W, ROW_H, 5, ROW_BG);
                ctx.drawTextWithShadow(mc.textRenderer, "—", colX + 8, rowY + 6, TEXT_DIM);
            } else {
                for (Module mod : mods) {
                    boolean hovered = smx >= colX && smx <= colX + COL_W && smy >= rowY && smy <= rowY + ROW_H - 2;
                    boolean enabled = mod.isEnabled();

                    if (enabled) {
                        RenderUtil.roundedRect(ctx, colX, rowY, COL_W, ROW_H - 2, 5, acc);
                        ctx.drawTextWithShadow(mc.textRenderer, mod.getName(), colX + 8, rowY + 5, 0xFFFFFFFF);
                    } else if (hovered) {
                        RenderUtil.roundedRect(ctx, colX, rowY, COL_W, ROW_H - 2, 5, ROW_HOVER);
                        ctx.drawTextWithShadow(mc.textRenderer, mod.getName(), colX + 8, rowY + 5, TEXT);
                    } else {
                        RenderUtil.roundedRect(ctx, colX, rowY, COL_W, ROW_H - 2, 5, ROW_BG);
                        ctx.drawTextWithShadow(mc.textRenderer, mod.getName(), colX + 8, rowY + 5, TEXT_DIM);
                    }

                    // Клавиша/биндинг справа
                    if (bindModule == mod) {
                        ctx.drawTextWithShadow(mc.textRenderer, "[..]", colX + COL_W - 26, rowY + 5, 0xFFEEDD55);
                    } else if (mod.getKeyBind() != -1) {
                        String key = GLFW.glfwGetKeyName(mod.getKeyBind(), 0);
                        if (key == null) key = "?";
                        key = key.toUpperCase();
                        if (key.length() > 4) key = key.substring(0, 4);
                        int kw = mc.textRenderer.getWidth(key);
                        ctx.drawTextWithShadow(mc.textRenderer, key, colX + COL_W - 8 - kw, rowY + 5,
                                enabled ? 0xFFFFFFFF : TEXT_DIM);
                    }

                    rowY += ROW_H;
                }
            }

            colX += COL_W + GAP;
        }

        // ===== ПОИСК =====
        int searchW = 200;
        int searchX = panelX + (panelW - searchW) / 2;
        int searchY = panelY + PAD + colMaxH + 10;

        RenderUtil.roundedRect(ctx, searchX, searchY, searchW, SEARCH_H, 6, SEARCH_BG);
        RenderUtil.roundedOutline(ctx, searchX, searchY, searchW, SEARCH_H, 6,
                RenderUtil.withAlpha(acc, searchActive ? 220 : 80), 1);

        String searchText = searchBuffer.isEmpty() && !searchActive ? SEARCH_HINT : searchBuffer;
        int searchTextColor = searchBuffer.isEmpty() && !searchActive ? TEXT_DIM : TEXT;
        ctx.drawTextWithShadow(mc.textRenderer, searchText, searchX + 8, searchY + 7, searchTextColor);

        // Курсор мигающий
        if (searchActive && (System.currentTimeMillis() / 500) % 2 == 0) {
            int cursorX = searchX + 8 + mc.textRenderer.getWidth(searchBuffer);
            ctx.fill(cursorX, searchY + 5, cursorX + 1, searchY + SEARCH_H - 5, TEXT);
        }

        // Кнопка темы (маленький кружок справа сверху)
        int themeBtnX = panelX + panelW - 24;
        int themeBtnY = panelY + PAD - 2;
        RenderUtil.circle(ctx, themeBtnX + 8, themeBtnY + 8, 7, Theme.getAccent());
        if (smx >= themeBtnX && smx <= themeBtnX + 16 && smy >= themeBtnY && smy <= themeBtnY + 16) {
            RenderUtil.roundedOutline(ctx, themeBtnX, themeBtnY, 16, 16, 8, 0xFFFFFFFF, 1);
        }

        // Панель настроек
        if (settingsModule != null) {
            int sw = 140;
            int sx = panelX - sw - 12;
            if (sx < 6) sx = 6;
            int sy = panelY;
            boolean isAS = settingsModule instanceof AutoSwap;
            int extra = isAS ? 20 : 0;
            int sHeight = 32 + settingsModule.getSettings().size() * 20 + extra;

            RenderUtil.shadow(ctx, sx, sy, sw, sHeight, 10);
            RenderUtil.roundedRect(ctx, sx, sy, sw, sHeight, 10, new Color(10, 10, 14, 250).getRGB());
            RenderUtil.roundedGradient(ctx, sx + 1, sy + 1, sw - 2, 22, 9,
                    RenderUtil.withAlpha(acc, 80), RenderUtil.withAlpha(acc, 0));
            ctx.drawTextWithShadow(mc.textRenderer, settingsModule.getName(), sx + 12, sy + 8, acc);

            int setY = sy + 28;
            for (Setting set : settingsModule.getSettings()) {
                String val;
                if (set.isSlider()) val = set.getName() + ": " + String.format("%.2f", set.getFloat());
                else if (set.isBoolean()) val = set.getName() + ": " + (set.getBool() ? "§aON" : "§cOFF");
                else val = set.getName() + ": " + set.getString();

                boolean hovered = smx >= sx + 6 && smx <= sx + sw - 6 && smy >= setY && smy <= setY + 18;
                if (hovered) RenderUtil.roundedRect(ctx, sx + 6, setY, sw - 12, 18, 4, ROW_HOVER);
                ctx.drawTextWithShadow(mc.textRenderer, val, sx + 12, setY + 5, TEXT);

                if (set.isSlider()) {
                    float pct = (set.getFloat() - set.getMin()) / (set.getMax() - set.getMin());
                    int barY = setY + 16;
                    RenderUtil.roundedRect(ctx, sx + 12, barY, sw - 24, 2, 1, new Color(60, 60, 70).getRGB());
                    RenderUtil.roundedRect(ctx, sx + 12, barY, (int)((sw - 24) * pct), 2, 1, acc);
                }
                setY += 20;
            }

            if (isAS) {
                AutoSwap as = (AutoSwap) settingsModule;
                String txt;
                if (bindSwapModule == as) txt = "Клавиша: [...]";
                else if (as.swapKey != -1) txt = "Клавиша: " + GLFW.glfwGetKeyName(as.swapKey, 0);
                else txt = "Клавиша: нет";
                boolean hovered = smx >= sx + 6 && smx <= sx + sw - 6 && smy >= setY && smy <= setY + 18;
                if (hovered) RenderUtil.roundedRect(ctx, sx + 6, setY, sw - 12, 18, 4, ROW_HOVER);
                ctx.drawTextWithShadow(mc.textRenderer, txt, sx + 12, setY + 5, TEXT);
            }
        }

        ctx.getMatrices().pop();
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        double smx = mouseX / SCALE;
        double smy = mouseY / SCALE;

        int panelX = gx(), panelY = gy();
        int colMaxH = maxColumnHeight();
        int panelW = totalWidth() + PAD * 2;

        // Кнопка темы
        int themeBtnX = panelX + panelW - 24;
        int themeBtnY = panelY + PAD - 2;
        if (smx >= themeBtnX && smx <= themeBtnX + 16 && smy >= themeBtnY && smy <= themeBtnY + 16) {
            if (button == 0) {
                int idx = 0;
                for (int i = 0; i < Theme.COLORS.length; i++) {
                    if (Theme.COLORS[i].equals(Theme.current)) { idx = i; break; }
                }
                Theme.current = Theme.COLORS[(idx + 1) % Theme.COLORS.length];
                com.felest.util.ConfigManager.save();
            }
            return true;
        }

        // Поиск
        int searchW = 200;
        int searchX = panelX + (panelW - searchW) / 2;
        int searchY = panelY + PAD + colMaxH + 10;
        if (smx >= searchX && smx <= searchX + searchW && smy >= searchY && smy <= searchY + SEARCH_H) {
            if (button == 0) { searchActive = true; return true; }
        } else {
            searchActive = false;
        }

        // Настройки
        if (settingsModule != null) {
            int sw = 140;
            int sx = panelX - sw - 12;
            if (sx < 6) sx = 6;
            int setY = panelY + 28;
            for (Setting set : settingsModule.getSettings()) {
                if (smx >= sx + 6 && smx <= sx + sw - 6 && smy >= setY && smy <= setY + 18) {
                    if (button == 0) {
                        if (set.isSlider()) { draggingSlider = set; applySlider(set, smx, sx, sw); }
                        else if (set.isBoolean()) set.setValue(!set.getBool());
                        else set.nextOption();
                    }
                    return true;
                }
                setY += 20;
            }
            if (settingsModule instanceof AutoSwap) {
                if (smx >= sx + 6 && smx <= sx + sw - 6 && smy >= setY && smy <= setY + 18) {
                    if (button == 0) bindSwapModule = (AutoSwap) settingsModule;
                    return true;
                }
            }
        }

        // Колонки с модулями
        int colX = panelX + PAD;
        int colY = panelY + PAD;

        for (Category cat : COLUMNS) {
            List<Module> mods = filter(FelestDLC.moduleManager.getModules(cat));
            int rowY = colY + HEADER_H + 2;
            for (Module mod : mods) {
                if (smx >= colX && smx <= colX + COL_W && smy >= rowY && smy <= rowY + ROW_H - 2) {
                    if (button == 0) mod.toggle();
                    else if (button == 1) settingsModule = (settingsModule == mod) ? null : mod;
                    else if (button == 2) bindModule = mod;
                    return true;
                }
                rowY += ROW_H;
            }
            colX += COL_W + GAP;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (draggingSlider != null && button == 0) {
            double smx = mouseX / SCALE;
            int panelX = gx();
            int sw = 140;
            int sx = panelX - sw - 12;
            if (sx < 6) sx = 6;
            applySlider(draggingSlider, smx, sx, sw);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (draggingSlider != null) { draggingSlider = null; return true; }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    private void applySlider(Setting set, double mouseX, int sx, int sw) {
        float pct = (float)(mouseX - (sx + 12)) / (float)(sw - 24);
        set.setFromPercent(Math.max(0f, Math.min(1f, pct)));
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searchActive) {
            if (chr >= 32 && chr < 127 && searchBuffer.length() < 20) {
                searchBuffer += chr;
            }
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (searchActive) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!searchBuffer.isEmpty()) searchBuffer = searchBuffer.substring(0, searchBuffer.length() - 1);
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER) {
                searchActive = false;
                return true;
            }
            return true; // поглощаем все клавиши пока поиск активен
        }

        if (bindModule != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE) bindModule.setKeyBind(-1);
            else bindModule.setKeyBind(keyCode);
            bindModule = null;
            return true;
        }
        if (bindSwapModule != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE) bindSwapModule.swapKey = -1;
            else bindSwapModule.swapKey = keyCode;
            bindSwapModule = null;
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() { return false; }
}
