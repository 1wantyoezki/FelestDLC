package com.felest.gui;

import com.felest.FelestDLC;
import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.module.impl.AutoSwap;
import com.felest.setting.Setting;
import com.felest.util.RenderUtil;
import com.felest.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class ClickGUI extends Screen {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    private Category selectedCategory = Category.Combat;
    private Module settingsModule = null;
    private Module bindModule = null;
    private AutoSwap bindSwapModule = null;
    private Setting draggingSlider = null;
    private final List<Module> visibleModules = new ArrayList<>();

    // Тёмная тема Nursultan
    private final int BG_TOP = new Color(12, 12, 16, 245).getRGB();
    private final int BG_BOTTOM = new Color(18, 18, 24, 245).getRGB();
    private final int SIDEBAR = new Color(10, 10, 14, 200).getRGB();
    private final int ROW_BG = new Color(24, 24, 30, 200).getRGB();
    private final int ROW_HOVER = new Color(34, 34, 44, 230).getRGB();
    private final int TEXT = new Color(225, 225, 235).getRGB();
    private final int TEXT_DIM = new Color(130, 130, 145).getRGB();
    private final int SETTINGS_BG = new Color(10, 10, 14, 250).getRGB();

    private final int GUI_W = 360;
    private final int GUI_H = 250;
    private final int R_MAIN = 14;
    private final int R_ROW = 8;

    private float openAnim = 0f;
    private float anim = 0f;

    public ClickGUI() { super(Text.literal("FelestDLC")); }

    private int accent() { return Theme.getAccent(); }
    private int accent2() {
        // Второй оттенок для градиента — чуть светлее
        int c = accent();
        int r = Math.min(255, ((c >> 16) & 0xFF) + 60);
        int g = Math.min(255, ((c >> 8) & 0xFF) + 60);
        int b = Math.min(255, (c & 0xFF) + 60);
        return (0xFF << 24) | (r << 16) | (g << 8) | b;
    }

    private int gx() { return (width - GUI_W) / 2; }
    private int gy() { return (height - GUI_H) / 2; }

    @Override
    public void init() {
        openAnim = 0f;
        super.init();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        openAnim = Math.min(1f, openAnim + 0.12f);
        anim += 0.05f;

        int acc = accent();
        int acc2 = accent2();

        int x = gx();
        int y = gy();
        int w = GUI_W;
        int h = GUI_H;

        // Мягкая тень
        RenderUtil.shadow(ctx, x, y, w, h, R_MAIN);
        // Окно с градиентом
        RenderUtil.roundedGradient(ctx, x, y, w, h, R_MAIN, BG_TOP, BG_BOTTOM);
        // Тонкая обводка
        RenderUtil.roundedOutline(ctx, x, y, w, h, R_MAIN, RenderUtil.withAlpha(acc, 80), 1);

        // ===== ШАПКА =====
        int headerH = 32;
        // Градиентная полоса сверху
        RenderUtil.roundedGradient(ctx, x + 1, y + 1, w - 2, headerH, R_MAIN - 1,
                RenderUtil.withAlpha(acc, 60), RenderUtil.withAlpha(acc, 0));

        // Логотип — буква F в квадрате
        int logoSize = 18;
        int lx = x + 12;
        int ly = y + 8;
        RenderUtil.roundedGradient(ctx, lx, ly, logoSize, logoSize, 5, acc2, acc);
        // Буква F по центру
        ctx.drawTextWithShadow(mc.textRenderer, "F", lx + 6, ly + 5, 0xFFFFFFFF);

        // Название
        ctx.drawTextWithShadow(mc.textRenderer, "FelestDLC", x + 36, y + 9, acc);
        ctx.drawTextWithShadow(mc.textRenderer, "v1.0.0", x + 36, y + 19, TEXT_DIM);

        // Разделитель
        ctx.fill(x + 8, y + headerH, x + w - 8, y + headerH + 1, RenderUtil.withAlpha(acc, 40));

        // Кнопка закрытия
        boolean closeHover = mouseX >= x + w - 26 && mouseX <= x + w - 10 && mouseY >= y + 8 && mouseY <= y + 24;
        int closeColor = closeHover ? new Color(220, 60, 60, 220).getRGB() : new Color(80, 60, 60, 150).getRGB();
        RenderUtil.roundedRect(ctx, x + w - 26, y + 8, 16, 16, 5, closeColor);
        ctx.drawTextWithShadow(mc.textRenderer, "✕", x + w - 22, y + 11, 0xFFFFFFFF);

        // ===== ЛЕВАЯ ПАНЕЛЬ КАТЕГОРИЙ =====
        int sidebarW = 100;
        int sidebarX = x + 8;
        int sidebarY = y + headerH + 6;

        int catY = sidebarY;
        for (Category cat : Category.values()) {
            boolean hovered = mouseX >= sidebarX && mouseX <= sidebarX + sidebarW && mouseY >= catY && mouseY <= catY + 22;
            boolean selected = (cat == selectedCategory);

            if (selected) {
                // Градиентная заливка
                RenderUtil.roundedGradient(ctx, sidebarX, catY, sidebarW, 22, 6, acc2, acc);
                // Левая цветная полоска
                RenderUtil.roundedRect(ctx, sidebarX, catY + 3, 3, 16, 2, 0xFFFFFFFF);
            } else if (hovered) {
                RenderUtil.roundedRect(ctx, sidebarX, catY, sidebarW, 22, 6, ROW_HOVER);
            } else {
                RenderUtil.roundedRect(ctx, sidebarX, catY, sidebarW, 22, 6, SIDEBAR);
            }
            ctx.drawTextWithShadow(mc.textRenderer, cat.name(), sidebarX + 14, catY + 7,
                    selected ? 0xFFFFFFFF : (hovered ? TEXT : TEXT_DIM));
            catY += 26;
        }

        // ===== ПРАВАЯ ПАНЕЛЬ КОНТЕНТА =====
        visibleModules.clear();
        int contentX = x + sidebarW + 16;
        int contentW = w - sidebarW - 24;
        int contentY = sidebarY;

        if (selectedCategory == Category.Themes) {
            int ty = contentY;
            for (String c : Theme.COLORS) {
                boolean isCurrent = Theme.current.equals(c);
                boolean hovered = mouseX >= contentX && mouseX <= contentX + contentW && mouseY >= ty && mouseY <= ty + 22;
                int col = Theme.getColorByName(c);

                if (isCurrent) {
                    RenderUtil.roundedGradient(ctx, contentX, ty, contentW, 22, 6, RenderUtil.withAlpha(col, 200), col);
                    ctx.drawTextWithShadow(mc.textRenderer, c, contentX + 12, ty + 7, 0xFFFFFFFF);
                    // Галочка
                    ctx.drawTextWithShadow(mc.textRenderer, "✓", contentX + contentW - 14, ty + 7, 0xFFFFFFFF);
                } else if (hovered) {
                    RenderUtil.roundedRect(ctx, contentX, ty, contentW, 22, 6, ROW_HOVER);
                    ctx.drawTextWithShadow(mc.textRenderer, c, contentX + 12, ty + 7, TEXT);
                } else {
                    RenderUtil.roundedRect(ctx, contentX, ty, contentW, 22, 6, ROW_BG);
                    ctx.drawTextWithShadow(mc.textRenderer, c, contentX + 12, ty + 7, TEXT_DIM);
                }
                // Квадратик цвета слева
                RenderUtil.roundedRect(ctx, contentX + contentW - 24, ty + 6, 10, 10, 3, col);
                ty += 26;
            }
        } else {
            int modY = contentY;
            for (Module mod : FelestDLC.moduleManager.getModules(selectedCategory)) {
                visibleModules.add(mod);
                boolean hovered = mouseX >= contentX && mouseX <= contentX + contentW && mouseY >= modY && mouseY <= modY + 22;
                boolean enabled = mod.isEnabled();

                if (enabled) {
                    // Включённый — градиентный, подсвечен
                    RenderUtil.roundedGradient(ctx, contentX, modY, contentW, 22, 6, acc2, acc);
                    ctx.drawTextWithShadow(mc.textRenderer, mod.getName(), contentX + 12, modY + 7, 0xFFFFFFFF);
                } else if (hovered) {
                    RenderUtil.roundedRect(ctx, contentX, modY, contentW, 22, 6, ROW_HOVER);
                    ctx.drawTextWithShadow(mc.textRenderer, mod.getName(), contentX + 12, modY + 7, TEXT);
                } else {
                    RenderUtil.roundedRect(ctx, contentX, modY, contentW, 22, 6, ROW_BG);
                    ctx.drawTextWithShadow(mc.textRenderer, mod.getName(), contentX + 12, modY + 7, TEXT_DIM);
                }

                // Точка-индикатор справа
                int dotColor = enabled ? 0xFFFFFFFF : RenderUtil.withAlpha(acc, 120);
                if (bindModule == mod) {
                    ctx.drawTextWithShadow(mc.textRenderer, "[нажми...]", contentX + contentW - 70, modY + 7, 0xFFEEDD55);
                } else if (mod.getKeyBind() != -1) {
                    String key = GLFW.glfwGetKeyName(mod.getKeyBind(), 0);
                    if (key == null) key = "?";
                    key = key.toUpperCase();
                    int kw = mc.textRenderer.getWidth(key);
                    ctx.drawTextWithShadow(mc.textRenderer, key, contentX + contentW - 14 - kw, modY + 7,
                            enabled ? 0xFFFFFFFF : TEXT_DIM);
                } else {
                    RenderUtil.circle(ctx, contentX + contentW - 14, modY + 11, 3f,
                            enabled ? 0xFFFFFFFF : RenderUtil.withAlpha(acc, 100));
                }

                modY += 26;
            }
            if (visibleModules.isEmpty()) {
                ctx.drawTextWithShadow(mc.textRenderer, "Нет модулей", contentX + 12, contentY + 8, TEXT_DIM);
            }
        }

        // ===== ПАНЕЛЬ НАСТРОЕК =====
        if (settingsModule != null) {
            int sw = 160;
            int sx = x - sw - 14;
            if (sx < 6) sx = 6;
            int sy = y;
            boolean isAutoSwap = settingsModule instanceof AutoSwap;
            int extra = isAutoSwap ? 22 : 0;
            int sHeight = 46 + settingsModule.getSettings().size() * 22 + extra;

            RenderUtil.shadow(ctx, sx, sy, sw, sHeight, R_MAIN);
            RenderUtil.roundedGradient(ctx, sx, sy, sw, sHeight, R_MAIN, BG_TOP, SETTINGS_BG);
            RenderUtil.roundedOutline(ctx, sx, sy, sw, sHeight, R_MAIN, RenderUtil.withAlpha(acc, 80), 1);

            // Заголовок с полоской
            RenderUtil.roundedGradient(ctx, sx + 1, sy + 1, sw - 2, 26, R_MAIN - 1,
                    RenderUtil.withAlpha(acc, 60), RenderUtil.withAlpha(acc, 0));
            ctx.drawTextWithShadow(mc.textRenderer, settingsModule.getName(), sx + 14, sy + 10, acc);

            int setY = sy + 34;
            for (Setting set : settingsModule.getSettings()) {
                String valText;
                if (set.isSlider()) valText = set.getName() + ": " + String.format("%.2f", set.getFloat());
                else if (set.isBoolean()) valText = set.getName() + ": " + (set.getBool() ? "§aON" : "§cOFF");
                else valText = set.getName() + ": " + set.getString();

                boolean hovered = mouseX >= sx + 8 && mouseX <= sx + sw - 8 && mouseY >= setY && mouseY <= setY + 20;
                if (hovered) RenderUtil.roundedRect(ctx, sx + 8, setY, sw - 16, 20, 6, ROW_HOVER);
                ctx.drawTextWithShadow(mc.textRenderer, valText, sx + 14, setY + 6, TEXT);

                if (set.isSlider()) {
                    float pct = (set.getFloat() - set.getMin()) / (set.getMax() - set.getMin());
                    int barY = setY + 18;
                    RenderUtil.roundedRect(ctx, sx + 14, barY, sw - 28, 2, 1, new Color(60, 60, 70).getRGB());
                    RenderUtil.roundedGradient(ctx, sx + 14, barY, (int)((sw - 28) * pct), 2, 1, acc2, acc);
                }
                setY += 22;
            }

            if (isAutoSwap) {
                AutoSwap as = (AutoSwap) settingsModule;
                String bindText;
                if (bindSwapModule == as) bindText = "Клавиша: [нажми...]";
                else if (as.swapKey != -1) bindText = "Клавиша: " + GLFW.glfwGetKeyName(as.swapKey, 0);
                else bindText = "Клавиша: нет";
                boolean hovered = mouseX >= sx + 8 && mouseX <= sx + sw - 8 && mouseY >= setY && mouseY <= setY + 20;
                if (hovered) RenderUtil.roundedRect(ctx, sx + 8, setY, sw - 16, 20, 6, ROW_HOVER);
                ctx.drawTextWithShadow(mc.textRenderer, bindText, sx + 14, setY + 6, TEXT);
            }
        }

        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int x = gx(), y = gy(), w = GUI_W;

        if (mouseX >= x + w - 26 && mouseX <= x + w - 10 && mouseY >= y + 8 && mouseY <= y + 24) {
            close();
            return true;
        }

        // Панель настроек
        if (settingsModule != null) {
            int sw = 160;
            int sx = x - sw - 14;
            if (sx < 6) sx = 6;
            int setY = y + 34;
            for (Setting set : settingsModule.getSettings()) {
                if (mouseX >= sx + 8 && mouseX <= sx + sw - 8 && mouseY >= setY && mouseY <= setY + 20) {
                    if (button == 0) {
                        if (set.isSlider()) { draggingSlider = set; applySlider(set, mouseX, sx, sw); }
                        else if (set.isBoolean()) set.setValue(!set.getBool());
                        else set.nextOption();
                    }
                    return true;
                }
                setY += 22;
            }
            if (settingsModule instanceof AutoSwap) {
                if (mouseX >= sx + 8 && mouseX <= sx + sw - 8 && mouseY >= setY && mouseY <= setY + 20) {
                    if (button == 0) bindSwapModule = (AutoSwap) settingsModule;
                    return true;
                }
            }
        }

        // Категории
        int headerH = 32;
        int sidebarW = 100;
        int sidebarX = x + 8;
        int catY = y + headerH + 6;
        for (Category cat : Category.values()) {
            if (mouseX >= sidebarX && mouseX <= sidebarX + sidebarW && mouseY >= catY && mouseY <= catY + 22) {
                selectedCategory = cat;
                settingsModule = null;
                return true;
            }
            catY += 26;
        }

        // Контент
        int contentX = x + sidebarW + 16;
        int contentW = w - sidebarW - 24;
        int contentY = y + headerH + 6;

        if (selectedCategory == Category.Themes) {
            int ty = contentY;
            for (String c : Theme.COLORS) {
                if (mouseX >= contentX && mouseX <= contentX + contentW && mouseY >= ty && mouseY <= ty + 22) {
                    if (button == 0) { Theme.current = c; com.felest.util.ConfigManager.save(); }
                    return true;
                }
                ty += 26;
            }
        } else {
            int modY = contentY;
            for (Module mod : visibleModules) {
                if (mouseX >= contentX && mouseX <= contentX + contentW && mouseY >= modY && mouseY <= modY + 22) {
                    if (button == 0) mod.toggle();
                    else if (button == 1) settingsModule = (settingsModule == mod) ? null : mod;
                    else if (button == 2) bindModule = mod;
                    return true;
                }
                modY += 26;
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggingSlider != null && button == 0) {
            int sw = 160;
            int x = gx();
            int sx = x - sw - 14;
            if (sx < 6) sx = 6;
            applySlider(draggingSlider, mouseX, sx, sw);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (draggingSlider != null) { draggingSlider = null; return true; }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    private void applySlider(Setting set, double mouseX, int sx, int sw) {
        float pct = (float)(mouseX - (sx + 14)) / (float)(sw - 28);
        set.setFromPercent(Math.max(0f, Math.min(1f, pct)));
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (bindModule != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE) bindModule.setKeyBind(-1);
            else bindModule.setKeyBind(keyCode);
            bindModule = null;
            return true;
        }
        if (bindSwapModule != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE) bindSwapModule.swapKey = -1;
            else bindSwapModule.swapKey = keyCode;
            bindSwapModule = null;
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() { return false; }
}
