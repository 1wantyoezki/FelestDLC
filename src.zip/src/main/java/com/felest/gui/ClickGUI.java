package com.felest.gui;

import com.felest.FelestDLC;
import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.module.impl.AutoSwap;
import com.felest.setting.Setting;
import com.felest.util.RenderUtil;
import com.felest.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class ClickGUI extends Screen {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    private Category selectedCategory = Category.Combat;
    private Module settingsModule = null;
    private Module bindModule = null;
    private AutoSwap bindSwapModule = null;
    private Setting draggingSlider = null;
    private final List<Module> visibleModules = new ArrayList<>();

    private final int BG_COLOR = new Color(18, 18, 24, 240).getRGB();
    private final int CAT_BG = new Color(32, 32, 44, 230).getRGB();
    private final int TEXT_COLOR = new Color(220, 220, 230).getRGB();
    private final int SETTINGS_BG = new Color(15, 15, 22, 245).getRGB();

    private final int R_MAIN = 16;
    private final int R_BTN = 8;

    // Реальные размеры (без scale)
    private final int GUI_W = 320;
    private final int GUI_H = 220;
    private final int ROW_H = 22;

    public ClickGUI() { super(Text.literal("FelestDLC")); }

    private int getAccent() { return Theme.getAccent(); }

    private int gx() { return (width - GUI_W) / 2; }
    private int gy() { return (height - GUI_H) / 2; }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        int accent = getAccent();
        int x = gx();
        int y = gy();

        // Тень
        RenderUtil.roundedRect(context, x + 3, y + 3, GUI_W, GUI_H, R_MAIN, new Color(0, 0, 0, 100).getRGB());
        // Основное окно
        RenderUtil.roundedRect(context, x, y, GUI_W, GUI_H, R_MAIN, BG_COLOR);

        context.drawTextWithShadow(mc.textRenderer, "FelestDLC", x + 16, y + 12, accent);
        context.drawTextWithShadow(mc.textRenderer, "v0.0.1", x + 90, y + 12, new Color(150, 150, 160).getRGB());
        context.drawTextWithShadow(mc.textRenderer, "✕", x + GUI_W - 22, y + 12, new Color(220, 80, 80).getRGB());

        // Категории
        int catY = y + 36;
        for (Category cat : Category.values()) {
            boolean hovered = mouseX >= x + 8 && mouseX <= x + 98 && mouseY >= catY && mouseY <= catY + 20;
            boolean selected = (cat == selectedCategory);
            int color = selected ? accent : (hovered ? new Color(48, 48, 62, 240).getRGB() : CAT_BG);
            RenderUtil.roundedRect(context, x + 8, catY, 90, 20, R_BTN, color);
            context.drawTextWithShadow(mc.textRenderer, cat.name(), x + 16, catY + 6, TEXT_COLOR);
            catY += 24;
        }

        visibleModules.clear();

        // Контент
        int cx = x + 106;
        int cw = GUI_W - 116;

        if (selectedCategory == Category.Themes) {
            int ty = y + 36;
            for (String c : Theme.COLORS) {
                boolean isCurrent = Theme.current.equals(c);
                boolean hovered = mouseX >= cx && mouseX <= cx + cw && mouseY >= ty && mouseY <= ty + 20;
                int color = isCurrent ? Theme.getColorByName(c) : (hovered ? new Color(50, 50, 65, 240).getRGB() : CAT_BG);
                RenderUtil.roundedRect(context, cx, ty, cw, 20, R_BTN, color);
                context.drawTextWithShadow(mc.textRenderer, c, cx + 10, ty + 6,
                        isCurrent ? Color.WHITE.getRGB() : TEXT_COLOR);
                ty += 24;
            }
        } else {
            int modY = y + 36;
            for (Module mod : FelestDLC.moduleManager.getModules(selectedCategory)) {
                visibleModules.add(mod);
                boolean hovered = mouseX >= cx && mouseX <= cx + cw && mouseY >= modY && mouseY <= modY + 20;
                int color = mod.isEnabled() ? accent : (hovered ? new Color(50, 50, 65, 240).getRGB() : CAT_BG);
                RenderUtil.roundedRect(context, cx, modY, cw, 20, R_BTN, color);
                String modName = mod.getName();
                if (bindModule == mod) modName += " [нажми...]";
                else if (mod.getKeyBind() != -1) modName += " [" + GLFW.glfwGetKeyName(mod.getKeyBind(), 0) + "]";
                context.drawTextWithShadow(mc.textRenderer, modName, cx + 10, modY + 6,
                        mod.isEnabled() ? Color.WHITE.getRGB() : TEXT_COLOR);
                modY += 24;
            }
            if (visibleModules.isEmpty()) {
                context.drawTextWithShadow(mc.textRenderer, "Нет модулей", cx + 10, y + 46, new Color(120, 120, 130).getRGB());
            }
        }

        // Панель настроек (слева)
        if (settingsModule != null) {
            int sw = 150;
            int sx = x - sw - 12;
            if (sx < 4) sx = 4;
            int sy = y;
            boolean isAutoSwap = settingsModule instanceof AutoSwap;
            int extra = isAutoSwap ? 22 : 0;
            int sHeight = 42 + settingsModule.getSettings().size() * 22 + extra;

            RenderUtil.roundedRect(context, sx + 3, sy + 3, sw, sHeight, R_MAIN, new Color(0, 0, 0, 100).getRGB());
            RenderUtil.roundedRect(context, sx, sy, sw, sHeight, R_MAIN, SETTINGS_BG);
            context.drawTextWithShadow(mc.textRenderer, settingsModule.getName(), sx + 14, sy + 12, accent);

            int setY = sy + 32;
            for (Setting set : settingsModule.getSettings()) {
                String valText;
                if (set.isSlider()) valText = set.getName() + ": " + String.format("%.2f", set.getFloat());
                else if (set.isBoolean()) valText = set.getName() + ": " + (set.getBool() ? "ON" : "OFF");
                else valText = set.getName() + ": " + set.getString();

                boolean hovered = mouseX >= sx + 8 && mouseX <= sx + sw - 8 && mouseY >= setY && mouseY <= setY + 20;
                if (hovered) RenderUtil.roundedRect(context, sx + 8, setY, sw - 16, 20, R_BTN, new Color(42, 42, 58, 240).getRGB());
                context.drawTextWithShadow(mc.textRenderer, valText, sx + 14, setY + 6, TEXT_COLOR);

                if (set.isSlider()) {
                    float pct = (set.getFloat() - set.getMin()) / (set.getMax() - set.getMin());
                    int barY = setY + 19;
                    context.fill(sx + 14, barY, sx + sw - 14, barY + 2, new Color(60, 60, 70).getRGB());
                    context.fill(sx + 14, barY, sx + 14 + (int)((sw - 28) * pct), barY + 2, accent);
                }
                setY += 22;
            }

            if (isAutoSwap) {
                AutoSwap as = (AutoSwap) settingsModule;
                String bindText;
                if (bindSwapModule == as) bindText = "Клавиша свапа: [нажми...]";
                else if (as.swapKey != -1) bindText = "Клавиша свапа: " + GLFW.glfwGetKeyName(as.swapKey, 0);
                else bindText = "Клавиша свапа: нет";
                boolean hovered = mouseX >= sx + 8 && mouseX <= sx + sw - 8 && mouseY >= setY && mouseY <= setY + 20;
                if (hovered) RenderUtil.roundedRect(context, sx + 8, setY, sw - 16, 20, R_BTN, new Color(42, 42, 58, 240).getRGB());
                context.drawTextWithShadow(mc.textRenderer, bindText, sx + 14, setY + 6, TEXT_COLOR);
            }
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int x = gx(), y = gy();

        if (mouseX >= x + GUI_W - 24 && mouseX <= x + GUI_W - 8 && mouseY >= y + 8 && mouseY <= y + 24) {
            this.close();
            return true;
        }

        if (settingsModule != null) {
            int sw = 150;
            int sx = x - sw - 12;
            if (sx < 4) sx = 4;
            int setY = y + 32;
            for (Setting set : settingsModule.getSettings()) {
                if (mouseX >= sx + 8 && mouseX <= sx + sw - 8 && mouseY >= setY && mouseY <= setY + 20) {
                    if (button == 0) {
                        if (set.isSlider()) { draggingSlider = set; applySlider(set, mouseX, sx, sw); }
                        else if (set.isBoolean()) set.setValue(!set.getBool());
                        else set.nextOption();
                    }
                    return true;
                }
                setY += 22;
            }
            if (settingsModule instanceof AutoSwap) {
                if (mouseX >= sx + 8 && mouseX <= sx + sw - 8 && mouseY >= setY && mouseY <= setY + 20) {
                    if (button == 0) bindSwapModule = (AutoSwap) settingsModule;
                    return true;
                }
            }
        }

        int catY = y + 36;
        for (Category cat : Category.values()) {
            if (mouseX >= x + 8 && mouseX <= x + 98 && mouseY >= catY && mouseY <= catY + 20) {
                selectedCategory = cat;
                settingsModule = null;
                return true;
            }
            catY += 24;
        }

        int cx = x + 106;
        int cw = GUI_W - 116;

        if (selectedCategory == Category.Themes) {
            int ty = y + 36;
            for (String c : Theme.COLORS) {
                if (mouseX >= cx && mouseX <= cx + cw && mouseY >= ty && mouseY <= ty + 20) {
                    if (button == 0) { Theme.current = c; com.felest.util.ConfigManager.save(); }
                    return true;
                }
                ty += 24;
            }
        } else {
            int modY = y + 36;
            for (Module mod : visibleModules) {
                if (mouseX >= cx && mouseX <= cx + cw && mouseY >= modY && mouseY <= modY + 20) {
                    if (button == 0) mod.toggle();
                    else if (button == 1) settingsModule = (settingsModule == mod) ? null : mod;
                    else if (button == 2) bindModule = mod;
                    return true;
                }
                modY += 24;
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggingSlider != null && button == 0) {
            int x = gx();
            int sw = 150;
            int sx = x - sw - 12;
            if (sx < 4) sx = 4;
            applySlider(draggingSlider, mouseX, sx, sw);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (draggingSlider != null) { draggingSlider = null; return true; }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    private void applySlider(Setting set, double mouseX, int sx, int sw) {
        float pct = (float)(mouseX - (sx + 14)) / (float)(sw - 28);
        set.setFromPercent(Math.max(0f, Math.min(1f, pct)));
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (bindModule != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE) bindModule.setKeyBind(-1);
            else bindModule.setKeyBind(keyCode);
            bindModule = null;
            return true;
        }
        if (bindSwapModule != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE) bindSwapModule.swapKey = -1;
            else bindSwapModule.swapKey = keyCode;
            bindSwapModule = null;
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() { return false; }
}
