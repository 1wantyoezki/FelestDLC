package com.felest.gui;

import com.felest.FelestDLC;
import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.module.impl.AutoSwap;
import com.felest.setting.Setting;
import com.felest.util.RenderUtil;
import com.felest.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class ClickGUI extends Screen {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    private Category selectedCategory = Category.Combat;
    private Module settingsModule = null;
    private Module bindModule = null;
    private AutoSwap bindSwapModule = null;
    private Setting draggingSlider = null;
    private final List<Module> visibleModules = new ArrayList<>();

    private final int BG_COLOR = new Color(18, 18, 24, 235).getRGB();
    private final int CAT_BG = new Color(30, 30, 40, 220).getRGB();
    private final int TEXT_COLOR = new Color(220, 220, 230).getRGB();
    private final int SETTINGS_BG = new Color(15, 15, 22, 240).getRGB();

    // Радиусы — крупнее для гладкости
    private final int R_MAIN = 10;
    private final int R_BTN = 6;
    private final int R_CAT = 6;

    public ClickGUI() { super(Text.literal("FelestDLC")); }

    private int getAccent() { return Theme.getAccent(); }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        int accent = getAccent();
        context.getMatrices().push();
        context.getMatrices().scale(0.66f, 0.66f, 1.0f);

        int scaledMouseX = (int) (mouseX / 0.66f);
        int scaledMouseY = (int) (mouseY / 0.66f);

        int guiWidth = 420;
        int guiHeight = 260;
        int x = (int) ((mc.getWindow().getScaledWidth() / 0.66f - guiWidth) / 2);
        int y = (int) ((mc.getWindow().getScaledHeight() / 0.66f - guiHeight) / 2);

        // Тень под окном (мягкая)
        RenderUtil.roundedRect(context, x + 2, y + 2, guiWidth, guiHeight, R_MAIN, new Color(0, 0, 0, 90).getRGB());
        // Основное окно
        RenderUtil.roundedRect(context, x, y, guiWidth, guiHeight, R_MAIN, BG_COLOR);

        context.drawTextWithShadow(mc.textRenderer, "FelestDLC", x + 14, y + 12, accent);
        context.drawTextWithShadow(mc.textRenderer, "v0.0.1", x + 104, y + 12, new Color(150, 150, 160).getRGB());
        context.drawTextWithShadow(mc.textRenderer, "✕", x + guiWidth - 20, y + 12, new Color(200, 80, 80).getRGB());

        // Категории слева
        int catY = y + 38;
        for (Category cat : Category.values()) {
            boolean hovered = scaledMouseX >= x + 6 && scaledMouseX <= x + 102 && scaledMouseY >= catY && scaledMouseY <= catY + 20;
            boolean selected = (cat == selectedCategory);

            int color;
            if (selected) color = accent;
            else if (hovered) color = new Color(48, 48, 62, 230).getRGB();
            else color = CAT_BG;

            RenderUtil.roundedRect(context, x + 6, catY, 96, 20, R_CAT, color);
            context.drawTextWithShadow(mc.textRenderer, cat.name(), x + 14, catY + 6, TEXT_COLOR);
            catY += 24;
        }

        visibleModules.clear();

        // Темы
        if (selectedCategory == Category.Themes) {
            int ty = y + 38;
            for (String c : Theme.COLORS) {
                boolean isCurrent = Theme.current.equals(c);
                boolean hovered = scaledMouseX >= x + 112 && scaledMouseX <= x + guiWidth - 12 && scaledMouseY >= ty && scaledMouseY <= ty + 20;
                int color = isCurrent ? Theme.getColorByName(c) : CAT_BG;
                if (hovered) color = new Color(50, 50, 65, 230).getRGB();
                RenderUtil.roundedRect(context, x + 112, ty, guiWidth - 124, 20, R_BTN, color);
                context.drawTextWithShadow(mc.textRenderer, c, x + 120, ty + 6,
                        isCurrent ? Color.WHITE.getRGB() : TEXT_COLOR);
                ty += 24;
            }
        } else {
            // Модули
            int modY = y + 38;
            for (Module mod : FelestDLC.moduleManager.getModules(selectedCategory)) {
                visibleModules.add(mod);
                boolean hovered = scaledMouseX >= x + 112 && scaledMouseX <= x + guiWidth - 12 && scaledMouseY >= modY && scaledMouseY <= modY + 20;
                int color = mod.isEnabled() ? accent : CAT_BG;
                if (hovered) color = new Color(50, 50, 65, 230).getRGB();

                RenderUtil.roundedRect(context, x + 112, modY, guiWidth - 124, 20, R_BTN, color);
                String modName = mod.getName();
                if (bindModule == mod) modName = modName + " [нажми клавишу...]";
                else if (mod.getKeyBind() != -1) modName = modName + " [" + GLFW.glfwGetKeyName(mod.getKeyBind(), 0) + "]";
                context.drawTextWithShadow(mc.textRenderer, modName, x + 120, modY + 6,
                        mod.isEnabled() ? Color.WHITE.getRGB() : TEXT_COLOR);
                modY += 24;
            }
            if (visibleModules.isEmpty()) {
                context.drawTextWithShadow(mc.textRenderer, "Нет модулей", x + 124, y + 48, new Color(120, 120, 130).getRGB());
            }
        }

        // Панель настроек
        if (settingsModule != null) {
            int sx = x - 155;
            int sy = y;
            int sWidth = 145;
            boolean isAutoSwap = settingsModule instanceof AutoSwap;
            int extra = isAutoSwap ? 22 : 0;
            int sHeight = 44 + settingsModule.getSettings().size() * 22 + extra;

            RenderUtil.roundedRect(context, sx + 2, sy + 2, sWidth, sHeight, R_MAIN, new Color(0, 0, 0, 90).getRGB());
            RenderUtil.roundedRect(context, sx, sy, sWidth, sHeight, R_MAIN, SETTINGS_BG);
            context.drawTextWithShadow(mc.textRenderer, settingsModule.getName(), sx + 12, sy + 12, accent);

            int setY = sy + 34;
            for (Setting set : settingsModule.getSettings()) {
                String valText;
                if (set.isSlider()) valText = set.getName() + ": " + String.format("%.2f", set.getFloat());
                else if (set.isBoolean()) valText = set.getName() + ": " + (set.getBool() ? "ON" : "OFF");
                else valText = set.getName() + ": " + set.getString();

                boolean hovered = scaledMouseX >= sx + 6 && scaledMouseX <= sx + sWidth - 6 && scaledMouseY >= setY && scaledMouseY <= setY + 20;
                if (hovered) RenderUtil.roundedRect(context, sx + 6, setY, sWidth - 12, 20, R_BTN, new Color(42, 42, 58, 230).getRGB());
                context.drawTextWithShadow(mc.textRenderer, valText, sx + 12, setY + 6, TEXT_COLOR);

                if (set.isSlider()) {
                    float pct = (set.getFloat() - set.getMin()) / (set.getMax() - set.getMin());
                    int barY = setY + 19;
                    context.fill(sx + 12, barY, sx + sWidth - 12, barY + 2, new Color(60, 60, 70).getRGB());
                    context.fill(sx + 12, barY, sx + 12 + (int)((sWidth - 24) * pct), barY + 2, accent);
                }
                setY += 22;
            }

            if (isAutoSwap) {
                AutoSwap as = (AutoSwap) settingsModule;
                String bindText;
                if (bindSwapModule == as) bindText = "Клавиша свапа: [нажми...]";
                else if (as.swapKey != -1) bindText = "Клавиша свапа: " + GLFW.glfwGetKeyName(as.swapKey, 0);
                else bindText = "Клавиша свапа: нет";
                boolean hovered = scaledMouseX >= sx + 6 && scaledMouseX <= sx + sWidth - 6 && scaledMouseY >= setY && scaledMouseY <= setY + 20;
                if (hovered) RenderUtil.roundedRect(context, sx + 6, setY, sWidth - 12, 20, R_BTN, new Color(42, 42, 58, 230).getRGB());
                context.drawTextWithShadow(mc.textRenderer, bindText, sx + 12, setY + 6, TEXT_COLOR);
            }
        }

        context.getMatrices().pop();
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        double scaledMouseX = mouseX / 0.66;
        double scaledMouseY = mouseY / 0.66;

        int guiWidth = 420;
        int guiHeight = 260;
        int x = (int) ((mc.getWindow().getScaledWidth() / 0.66f - guiWidth) / 2);
        int y = (int) ((mc.getWindow().getScaledHeight() / 0.66f - guiHeight) / 2);

        if (scaledMouseX >= x + guiWidth - 22 && scaledMouseX <= x + guiWidth - 8 && scaledMouseY >= y + 8 && scaledMouseY <= y + 22) {
            this.close();
            return true;
        }

        if (settingsModule != null) {
            int sx = x - 155;
            int sy = y;
            int sWidth = 145;
            int setY = sy + 34;
            for (Setting set : settingsModule.getSettings()) {
                if (scaledMouseX >= sx + 6 && scaledMouseX <= sx + sWidth - 6 && scaledMouseY >= setY && scaledMouseY <= setY + 20) {
                    if (button == 0) {
                        if (set.isSlider()) {
                            draggingSlider = set;
                            applySlider(set, scaledMouseX, sx, sWidth);
                        } else if (set.isBoolean()) set.setValue(!set.getBool());
                        else set.nextOption();
                    }
                    return true;
                }
                setY += 22;
            }
            if (settingsModule instanceof AutoSwap) {
                if (scaledMouseX >= sx + 6 && scaledMouseX <= sx + sWidth - 6 && scaledMouseY >= setY && scaledMouseY <= setY + 20) {
                    if (button == 0) bindSwapModule = (AutoSwap) settingsModule;
                    return true;
                }
            }
        }

        int catY = y + 38;
        for (Category cat : Category.values()) {
            if (scaledMouseX >= x + 6 && scaledMouseX <= x + 102 && scaledMouseY >= catY && scaledMouseY <= catY + 20) {
                selectedCategory = cat;
                settingsModule = null;
                return true;
            }
            catY += 24;
        }

        if (selectedCategory == Category.Themes) {
            int ty = y + 38;
            for (String c : Theme.COLORS) {
                if (scaledMouseX >= x + 112 && scaledMouseX <= x + guiWidth - 12 && scaledMouseY >= ty && scaledMouseY <= ty + 20) {
                    if (button == 0) {
                        Theme.current = c;
                        com.felest.util.ConfigManager.save();
                    }
                    return true;
                }
                ty += 24;
            }
        } else {
            int modY = y + 38;
            for (Module mod : visibleModules) {
                if (scaledMouseX >= x + 112 && scaledMouseX <= x + guiWidth - 12 && scaledMouseY >= modY && scaledMouseY <= modY + 20) {
                    if (button == 0) mod.toggle();
                    else if (button == 1) settingsModule = (settingsModule == mod) ? null : mod;
                    else if (button == 2) bindModule = mod;
                    return true;
                }
                modY += 24;
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggingSlider != null && button == 0) {
            double scaledMouseX = mouseX / 0.66;
            int guiWidth = 420;
            int guiHeight = 260;
            int x = (int) ((mc.getWindow().getScaledWidth() / 0.66f - guiWidth) / 2);
            int sx = x - 155;
            int sWidth = 145;
            applySlider(draggingSlider, scaledMouseX, sx, sWidth);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (draggingSlider != null) {
            draggingSlider = null;
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    private void applySlider(Setting set, double mouseX, int sx, int sWidth) {
        float pct = (float)(mouseX - (sx + 12)) / (float)(sWidth - 24);
        set.setFromPercent(Math.max(0f, Math.min(1f, pct)));
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (bindModule != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE) bindModule.setKeyBind(-1);
            else bindModule.setKeyBind(keyCode);
            bindModule = null;
            return true;
        }
        if (bindSwapModule != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE) bindSwapModule.swapKey = -1;
            else bindSwapModule.swapKey = keyCode;
            bindSwapModule = null;
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() { return false; }
}
