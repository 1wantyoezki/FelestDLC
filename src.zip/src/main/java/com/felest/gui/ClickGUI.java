package com.felest.gui;

import com.felest.FelestDLC;
import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.module.impl.AutoSwap;
import com.felest.setting.Setting;
import com.felest.util.RenderUtil;
import com.felest.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class ClickGUI extends Screen {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    private static final float SCALE = 0.7f;

    private Module settingsModule = null;
    private Module bindModule = null;
    private AutoSwap bindSwapModule = null;
    private Setting draggingSlider = null;

    private boolean searchActive = false;
    private String searchBuffer = "";

    private float scrollY = 0;
    private float scrollTarget = 0;

    private final Category[] COLUMNS = {
            Category.Combat, Category.Movement, Category.Render, Category.Player, Category.Misc
    };

    private final int COL_W = 105;
    private final int GAP = 8;
    private final int HEADER_H = 20;
    private final int ROW_H = 18;
    private final int PAD = 10;
    private final int SEARCH_H = 20;
    private final int VISIBLE_H = 220;

    private final int BG = new Color(14, 14, 20, 240).getRGB();
    private final int ROW_BG = new Color(22, 22, 30, 220).getRGB();
    private final int ROW_HOVER = new Color(38, 38, 50, 240).getRGB();
    private final int TEXT = new Color(220, 220, 230).getRGB();
    private final int TEXT_DIM = new Color(130, 130, 145).getRGB();
    private final int SEARCH_BG = new Color(10, 10, 16, 230).getRGB();

    public ClickGUI() { super(Text.literal("FelestDLC")); }

    private int accent() { return Theme.getAccent(); }

    private String displayName(Category cat) {
        switch (cat) {
            case Render: return "Visuals";
            default: return cat.name();
        }
    }

    private int totalWidth() { return COLUMNS.length * COL_W + (COLUMNS.length - 1) * GAP; }

    private List<Module> filter(List<Module> in) {
        if (searchBuffer.isEmpty()) return in;
        String q = searchBuffer.toLowerCase();
        List<Module> out = new ArrayList<>();
        for (Module m : in) if (m.getName().toLowerCase().contains(q)) out.add(m);
        return out;
    }

    private int maxContentH() {
        int max = 0;
        for (Category cat : COLUMNS) {
            List<Module> mods = filter(FelestDLC.moduleManager.getModules(cat));
            int h = Math.max(1, mods.size()) * ROW_H;
            if (h > max) max = h;
        }
        return max;
    }

    private int gx() {
        int panelW = totalWidth() + PAD * 2;
        return (int)((width / SCALE - panelW) / 2);
    }
    private int gy() {
        int panelH = PAD * 2 + HEADER_H + VISIBLE_H + 8 + SEARCH_H;
        return (int)((height / SCALE - panelH) / 2);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        scrollY += (scrollTarget - scrollY) * 0.25f;

        int acc = accent();
        int acc2 = Theme.getColorByName(Theme.current) & 0x00FFFFFF;
        int accLighter = (0xFF << 24)
                | Math.min(255, ((acc2 >> 16) & 0xFF) + 60) << 16
                | Math.min(255, ((acc2 >> 8) & 0xFF) + 60) << 8
                | Math.min(255, (acc2 & 0xFF) + 60);

        ctx.getMatrices().push();
        ctx.getMatrices().scale(SCALE, SCALE, 1f);

        int smx = (int)(mouseX / SCALE);
        int smy = (int)(mouseY / SCALE);

        int panelX = gx();
        int panelY = gy();
        int panelW = totalWidth() + PAD * 2;
        int contentTop = panelY + PAD + HEADER_H;
        int contentBottom = contentTop + VISIBLE_H;

        // Кнопка темы сверху справа
        int themeBtnX = panelX + panelW - 22;
        int themeBtnY = panelY - 18;
        RenderUtil.circle(ctx, themeBtnX + 7, themeBtnY + 7, 6, Theme.getAccent());

        // ===== 5 ОТДЕЛЬНЫХ КОЛОНОК =====
        int colX = panelX + PAD;
        for (Category cat : COLUMNS) {
            List<Module> mods = filter(FelestDLC.moduleManager.getModules(cat));

            // Каждая колонка — своя панель с фоном
            int colH = PAD + HEADER_H + VISIBLE_H + 4;
            RenderUtil.shadow(ctx, colX, panelY, COL_W, colH, 8);
            RenderUtil.roundedRect(ctx, colX, panelY, COL_W, colH, 8, BG);

            // Header
            RenderUtil.roundedGradient(ctx, colX + 4, panelY + 4, COL_W - 8, HEADER_H, 5, accLighter, acc);
            int hw = mc.textRenderer.getWidth(displayName(cat));
            ctx.drawTextWithShadow(mc.textRenderer, displayName(cat),
                    colX + (COL_W - hw) / 2, panelY + 10, 0xFFFFFFFF);

            // Rows
            int rowY = contentTop + (int) scrollY;
            if (mods.isEmpty()) {
                if (rowY + ROW_H > contentTop && rowY < contentBottom) {
                    RenderUtil.roundedRect(ctx, colX + 4, rowY, COL_W - 8, ROW_H - 2, 4, ROW_BG);
                    ctx.drawTextWithShadow(mc.textRenderer, "—", colX + 10, rowY + 5, TEXT_DIM);
                }
            } else {
                for (Module mod : mods) {
                    if (rowY + ROW_H >= contentTop && rowY <= contentBottom) {
                        boolean hovered = smx >= colX + 4 && smx <= colX + COL_W - 4 && smy >= rowY && smy <= rowY + ROW_H - 2;
                        boolean enabled = mod.isEnabled();

                        if (enabled) {
                            RenderUtil.roundedRect(ctx, colX + 4, rowY, COL_W - 8, ROW_H - 2, 4, acc);
                            ctx.drawTextWithShadow(mc.textRenderer, mod.getName(), colX + 10, rowY + 4, 0xFFFFFFFF);
                        } else if (hovered) {
                            RenderUtil.roundedRect(ctx, colX + 4, rowY, COL_W - 8, ROW_H - 2, 4, ROW_HOVER);
                            ctx.drawTextWithShadow(mc.textRenderer, mod.getName(), colX + 10, rowY + 4, TEXT);
                        } else {
                            RenderUtil.roundedRect(ctx, colX + 4, rowY, COL_W - 8, ROW_H - 2, 4, ROW_BG);
                            ctx.drawTextWithShadow(mc.textRenderer, mod.getName(), colX + 10, rowY + 4, TEXT_DIM);
                        }

                        if (bindModule == mod) {
                            ctx.drawTextWithShadow(mc.textRenderer, "[..]", colX + COL_W - 24, rowY + 4, 0xFFEEDD55);
                        } else if (mod.getKeyBind() != -1) {
                            String key = GLFW.glfwGetKeyName(mod.getKeyBind(), 0);
                            if (key == null) key = "?";
                            key = key.toUpperCase();
                            if (key.length() > 3) key = key.substring(0, 3);
                            int kw = mc.textRenderer.getWidth(key);
                            ctx.drawTextWithShadow(mc.textRenderer, key, colX + COL_W - 8 - kw, rowY + 4,
                                    enabled ? 0xFFFFFFFF : TEXT_DIM);
                        }
                    }
                    rowY += ROW_H;
                }
            }

            colX += COL_W + GAP;
        }

        // Индикатор скролла — тонкая полоска справа
        int maxScroll = Math.max(0, maxContentH() - VISIBLE_H);
        if (maxScroll > 0) {
            int barX = panelX + panelW - 4;
            RenderUtil.roundedRect(ctx, barX, contentTop, 3, VISIBLE_H, 1, new Color(30, 30, 40, 200).getRGB());
            float pct = -scrollY / maxScroll;
            int barH = Math.max(20, VISIBLE_H * VISIBLE_H / maxContentH());
            int barY = contentTop + (int)((VISIBLE_H - barH) * pct);
            RenderUtil.roundedRect(ctx, barX, barY, 3, barH, 1, acc);
        }

        // Поиск
        int searchW = 200;
        int searchX = panelX + (panelW - searchW) / 2;
        int searchY = panelY + PAD + HEADER_H + VISIBLE_H + 8;

        RenderUtil.roundedRect(ctx, searchX, searchY, searchW, SEARCH_H, 5, SEARCH_BG);
        RenderUtil.roundedOutline(ctx, searchX, searchY, searchW, SEARCH_H, 5,
                RenderUtil.withAlpha(acc, searchActive ? 220 : 80), 1);

        String st = searchBuffer.isEmpty() && !searchActive ? "Поиск..." : searchBuffer;
        int stc = searchBuffer.isEmpty() && !searchActive ? TEXT_DIM : TEXT;
        ctx.drawTextWithShadow(mc.textRenderer, st, searchX + 8, searchY + 6, stc);

        if (searchActive && (System.currentTimeMillis() / 500) % 2 == 0) {
            int cx = searchX + 8 + mc.textRenderer.getWidth(searchBuffer);
            ctx.fill(cx, searchY + 4, cx + 1, searchY + SEARCH_H - 4, TEXT);
        }

        // Панель настроек
        if (settingsModule != null) {
            int sw = 130;
            int sx = panelX - sw - 10;
            if (sx < 4) sx = 4;
            int sy = panelY;
            boolean isAS = settingsModule instanceof AutoSwap;
            int extra = isAS ? 18 : 0;
            int sHeight = 30 + settingsModule.getSettings().size() * 18 + extra;

            RenderUtil.shadow(ctx, sx, sy, sw, sHeight, 10);
            RenderUtil.roundedRect(ctx, sx, sy, sw, sHeight, 10, new Color(10, 10, 14, 250).getRGB());
            RenderUtil.roundedGradient(ctx, sx + 1, sy + 1, sw - 2, 20, 9,
                    RenderUtil.withAlpha(acc, 80), RenderUtil.withAlpha(acc, 0));
            ctx.drawTextWithShadow(mc.textRenderer, settingsModule.getName(), sx + 10, sy + 7, acc);

            int setY = sy + 26;
            for (Setting set : settingsModule.getSettings()) {
                String val;
                if (set.isSlider()) val = set.getName() + ": " + String.format("%.2f", set.getFloat());
                else if (set.isBoolean()) val = set.getName() + ": " + (set.getBool() ? "§aON" : "§cOFF");
                else val = set.getName() + ": " + set.getString();

                boolean hovered = smx >= sx + 5 && smx <= sx + sw - 5 && smy >= setY && smy <= setY + 16;
                if (hovered) RenderUtil.roundedRect(ctx, sx + 5, setY, sw - 10, 16, 4, ROW_HOVER);
                ctx.drawTextWithShadow(mc.textRenderer, val, sx + 10, setY + 4, TEXT);

                if (set.isSlider()) {
                    float pct = (set.getFloat() - set.getMin()) / (set.getMax() - set.getMin());
                    int barY = setY + 14;
                    RenderUtil.roundedRect(ctx, sx + 10, barY, sw - 20, 2, 1, new Color(60, 60, 70).getRGB());
                    RenderUtil.roundedRect(ctx, sx + 10, barY, (int)((sw - 20) * pct), 2, 1, acc);
                }
                setY += 18;
            }

            if (isAS) {
                AutoSwap as = (AutoSwap) settingsModule;
                String txt;
                if (bindSwapModule == as) txt = "Клавиша: [...]";
                else if (as.swapKey != -1) txt = "Клавиша: " + GLFW.glfwGetKeyName(as.swapKey, 0);
                else txt = "Клавиша: нет";
                boolean hovered = smx >= sx + 5 && smx <= sx + sw - 5 && smy >= setY && smy <= setY + 16;
                if (hovered) RenderUtil.roundedRect(ctx, sx + 5, setY, sw - 10, 16, 4, ROW_HOVER);
                ctx.drawTextWithShadow(mc.textRenderer, txt, sx + 10, setY + 4, TEXT);
            }
        }

        ctx.getMatrices().pop();
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double hAmt, double vAmt) {
        int maxScroll = Math.max(0, maxContentH() - VISIBLE_H);
        scrollTarget -= (float)(vAmt * 20);
        if (scrollTarget > 0) scrollTarget = 0;
        if (scrollTarget < -maxScroll) scrollTarget = -maxScroll;
        return true;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        double smx = mouseX / SCALE;
        double smy = mouseY / SCALE;

        int panelX = gx(), panelY = gy();
        int panelW = totalWidth() + PAD * 2;
        int contentTop = panelY + PAD + HEADER_H;
        int contentBottom = contentTop + VISIBLE_H;

        // Theme
        int themeBtnX = panelX + panelW - 22;
        int themeBtnY = panelY - 18;
        if (smx >= themeBtnX && smx <= themeBtnX + 14 && smy >= themeBtnY && smy <= themeBtnY + 14) {
            if (button == 0) {
                int idx = 0;
                for (int i = 0; i < Theme.COLORS.length; i++) if (Theme.COLORS[i].equals(Theme.current)) { idx = i; break; }
                Theme.current = Theme.COLORS[(idx + 1) % Theme.COLORS.length];
                com.felest.util.ConfigManager.save();
            }
            return true;
        }

        // Search
        int searchW = 200;
        int searchX = panelX + (panelW - searchW) / 2;
        int searchY = panelY + PAD + HEADER_H + VISIBLE_H + 8;
        if (smx >= searchX && smx <= searchX + searchW && smy >= searchY && smy <= searchY + SEARCH_H) {
            if (button == 0) { searchActive = true; return true; }
        } else {
            searchActive = false;
        }

        // Settings
        if (settingsModule != null) {
            int sw = 130;
            int sx = panelX - sw - 10;
            if (sx < 4) sx = 4;
            int setY = panelY + 26;
            for (Setting set : settingsModule.getSettings()) {
                if (smx >= sx + 5 && smx <= sx + sw - 5 && smy >= setY && smy <= setY + 16) {
                    if (button == 0) {
                        if (set.isSlider()) { draggingSlider = set; applySlider(set, smx, sx, sw); }
                        else if (set.isBoolean()) set.setValue(!set.getBool());
                        else set.nextOption();
                    }
                    return true;
                }
                setY += 18;
            }
            if (settingsModule instanceof AutoSwap) {
                if (smx >= sx + 5 && smx <= sx + sw - 5 && smy >= setY && smy <= setY + 16) {
                    if (button == 0) bindSwapModule = (AutoSwap) settingsModule;
                    return true;
                }
            }
        }

        // Modules
        int colX = panelX + PAD;
        for (Category cat : COLUMNS) {
            List<Module> mods = filter(FelestDLC.moduleManager.getModules(cat));
            int rowY = contentTop + (int) scrollY;
            for (Module mod : mods) {
                if (rowY + ROW_H >= contentTop && rowY <= contentBottom) {
                    if (smx >= colX + 4 && smx <= colX + COL_W - 4 && smy >= rowY && smy <= rowY + ROW_H - 2) {
                        if (button == 0) mod.toggle();
                        else if (button == 1) settingsModule = (settingsModule == mod) ? null : mod;
                        else if (button == 2) bindModule = mod;
                        return true;
                    }
                }
                rowY += ROW_H;
            }
            colX += COL_W + GAP;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (draggingSlider != null && button == 0) {
            double smx = mouseX / SCALE;
            int sw = 130;
            int panelX = gx();
            int sx = panelX - sw - 10;
            if (sx < 4) sx = 4;
            applySlider(draggingSlider, smx, sx, sw);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (draggingSlider != null) { draggingSlider = null; return true; }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    private void applySlider(Setting set, double mouseX, int sx, int sw) {
        float pct = (float)(mouseX - (sx + 10)) / (float)(sw - 20);
        set.setFromPercent(Math.max(0f, Math.min(1f, pct)));
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searchActive) {
            if (chr >= 32 && chr < 127 && searchBuffer.length() < 20) searchBuffer += chr;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (searchActive) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!searchBuffer.isEmpty()) searchBuffer = searchBuffer.substring(0, searchBuffer.length() - 1);
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER) {
                searchActive = false;
                return true;
            }
            return true;
        }
        if (bindModule != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE) bindModule.setKeyBind(-1);
            else bindModule.setKeyBind(keyCode);
            bindModule = null;
            return true;
        }
        if (bindSwapModule != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE) bindSwapModule.swapKey = -1;
            else bindSwapModule.swapKey = keyCode;
            bindSwapModule = null;
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() { return false; }
}
