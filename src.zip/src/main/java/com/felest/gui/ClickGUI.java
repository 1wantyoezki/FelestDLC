package com.felest.gui;

import com.felest.FelestDLC;
import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.module.impl.AutoSwap;
import com.felest.setting.Setting;
import com.felest.util.RenderUtil;
import com.felest.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class ClickGUI extends Screen {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    private static final float SCALE = 0.75f;

    private Category selectedCategory = Category.Combat;
    private Module settingsModule = null;
    private Module bindModule = null;
    private AutoSwap bindSwapModule = null;
    private Setting draggingSlider = null;
    private final List<Module> visibleModules = new ArrayList<>();

    private final int BG_TOP = new Color(12, 12, 16, 245).getRGB();
    private final int BG_BOTTOM = new Color(18, 18, 24, 245).getRGB();
    private final int SIDEBAR = new Color(10, 10, 14, 200).getRGB();
    private final int ROW_BG = new Color(24, 24, 30, 200).getRGB();
    private final int ROW_HOVER = new Color(34, 34, 44, 230).getRGB();
    private final int TEXT = new Color(225, 225, 235).getRGB();
    private final int TEXT_DIM = new Color(130, 130, 145).getRGB();
    private final int SETTINGS_BG = new Color(10, 10, 14, 250).getRGB();

    private final int GUI_W = 300;
    private final int GUI_H = 220;
    private final int R_MAIN = 12;
    private final int R_ROW = 6;
    private final int HEADER_H = 28;
    private final int SIDEBAR_W = 84;
    private final int ROW_H = 24;

    public ClickGUI() { super(Text.literal("FelestDLC")); }

    private int accent() { return Theme.getAccent(); }
    private int accent2() {
        int c = accent();
        int r = Math.min(255, ((c >> 16) & 0xFF) + 60);
        int g = Math.min(255, ((c >> 8) & 0xFF) + 60);
        int b = Math.min(255, (c & 0xFF) + 60);
        return (0xFF << 24) | (r << 16) | (g << 8) | b;
    }

    // Реальные координаты — делим на SCALE
    private int gx() { return (int)((width / SCALE - GUI_W) / 2); }
    private int gy() { return (int)((height / SCALE - GUI_H) / 2); }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        int acc = accent();
        int acc2 = accent2();

        ctx.getMatrices().push();
        ctx.getMatrices().scale(SCALE, SCALE, 1f);

        int smx = (int)(mouseX / SCALE);
        int smy = (int)(mouseY / SCALE);

        int x = gx(), y = gy(), w = GUI_W, h = GUI_H;

        RenderUtil.shadow(ctx, x, y, w, h, R_MAIN);
        RenderUtil.roundedGradient(ctx, x, y, w, h, R_MAIN, BG_TOP, BG_BOTTOM);
        RenderUtil.roundedOutline(ctx, x, y, w, h, R_MAIN, RenderUtil.withAlpha(acc, 80), 1);

        // Шапка
        RenderUtil.roundedGradient(ctx, x + 1, y + 1, w - 2, HEADER_H, R_MAIN - 1,
                RenderUtil.withAlpha(acc, 60), RenderUtil.withAlpha(acc, 0));

        // Логотип
        int logo = 16;
        RenderUtil.roundedGradient(ctx, x + 10, y + 6, logo, logo, 4, acc2, acc);
        ctx.drawTextWithShadow(mc.textRenderer, "F", x + 16, y + 10, 0xFFFFFFFF);

        ctx.drawTextWithShadow(mc.textRenderer, "FelestDLC", x + 32, y + 7, acc);
        ctx.drawTextWithShadow(mc.textRenderer, "v1.0.0", x + 32, y + 17, TEXT_DIM);

        // Кнопка X
        boolean closeHover = smx >= x + w - 22 && smx <= x + w - 8 && smy >= y + 7 && smy <= y + 21;
        int closeColor = closeHover ? new Color(220, 60, 60, 220).getRGB() : new Color(80, 60, 60, 150).getRGB();
        RenderUtil.roundedRect(ctx, x + w - 22, y + 7, 14, 14, 4, closeColor);
        ctx.drawTextWithShadow(mc.textRenderer, "✕", x + w - 18, y + 9, 0xFFFFFFFF);

        int catY = y + HEADER_H + 6;
        for (Category cat : Category.values()) {
            boolean hovered = smx >= x + 8 && smx <= x + 8 + SIDEBAR_W && smy >= catY && smy <= catY + 20;
            boolean selected = (cat == selectedCategory);

            if (selected) {
                RenderUtil.roundedGradient(ctx, x + 8, catY, SIDEBAR_W, 20, 5, acc2, acc);
                RenderUtil.roundedRect(ctx, x + 8, catY + 3, 3, 14, 2, 0xFFFFFFFF);
            } else if (hovered) {
                RenderUtil.roundedRect(ctx, x + 8, catY, SIDEBAR_W, 20, 5, ROW_HOVER);
            } else {
                RenderUtil.roundedRect(ctx, x + 8, catY, SIDEBAR_W, 20, 5, SIDEBAR);
            }
            ctx.drawTextWithShadow(mc.textRenderer, cat.name(), x + 18, catY + 6,
                    selected ? 0xFFFFFFFF : (hovered ? TEXT : TEXT_DIM));
            catY += ROW_H;
        }

        visibleModules.clear();
        int contentX = x + SIDEBAR_W + 16;
        int contentW = w - SIDEBAR_W - 24;
        int contentY = y + HEADER_H + 6;

        if (selectedCategory == Category.Themes) {
            int ty = contentY;
            for (String c : Theme.COLORS) {
                boolean isCur = Theme.current.equals(c);
                boolean hovered = smx >= contentX && smx <= contentX + contentW && smy >= ty && smy <= ty + 20;
                int col = Theme.getColorByName(c);

                if (isCur) {
                    RenderUtil.roundedGradient(ctx, contentX, ty, contentW, 20, 5, RenderUtil.withAlpha(col, 200), col);
                    ctx.drawTextWithShadow(mc.textRenderer, c, contentX + 10, ty + 6, 0xFFFFFFFF);
                    ctx.drawTextWithShadow(mc.textRenderer, "✓", contentX + contentW - 14, ty + 6, 0xFFFFFFFF);
                } else if (hovered) {
                    RenderUtil.roundedRect(ctx, contentX, ty, contentW, 20, 5, ROW_HOVER);
                    ctx.drawTextWithShadow(mc.textRenderer, c, contentX + 10, ty + 6, TEXT);
                } else {
                    RenderUtil.roundedRect(ctx, contentX, ty, contentW, 20, 5, ROW_BG);
                    ctx.drawTextWithShadow(mc.textRenderer, c, contentX + 10, ty + 6, TEXT_DIM);
                }
                RenderUtil.roundedRect(ctx, contentX + contentW - 22, ty + 6, 8, 8, 2, col);
                ty += ROW_H;
            }
        } else {
            int modY = contentY;
            for (Module mod : FelestDLC.moduleManager.getModules(selectedCategory)) {
                visibleModules.add(mod);
                boolean hovered = smx >= contentX && smx <= contentX + contentW && smy >= modY && smy <= modY + 20;
                boolean enabled = mod.isEnabled();

                if (enabled) {
                    RenderUtil.roundedGradient(ctx, contentX, modY, contentW, 20, 5, acc2, acc);
                    ctx.drawTextWithShadow(mc.textRenderer, mod.getName(), contentX + 10, modY + 6, 0xFFFFFFFF);
                } else if (hovered) {
                    RenderUtil.roundedRect(ctx, contentX, modY, contentW, 20, 5, ROW_HOVER);
                    ctx.drawTextWithShadow(mc.textRenderer, mod.getName(), contentX + 10, modY + 6, TEXT);
                } else {
                    RenderUtil.roundedRect(ctx, contentX, modY, contentW, 20, 5, ROW_BG);
                    ctx.drawTextWithShadow(mc.textRenderer, mod.getName(), contentX + 10, modY + 6, TEXT_DIM);
                }

                if (bindModule == mod) {
                    ctx.drawTextWithShadow(mc.textRenderer, "[...]", contentX + contentW - 40, modY + 6, 0xFFEEDD55);
                } else if (mod.getKeyBind() != -1) {
                    String key = GLFW.glfwGetKeyName(mod.getKeyBind(), 0);
                    if (key == null) key = "?";
                    key = key.toUpperCase();
                    int kw = mc.textRenderer.getWidth(key);
                    ctx.drawTextWithShadow(mc.textRenderer, key, contentX + contentW - 14 - kw, modY + 6,
                            enabled ? 0xFFFFFFFF : TEXT_DIM);
                } else {
                    RenderUtil.circle(ctx, contentX + contentW - 12, modY + 10, 2.5f,
                            enabled ? 0xFFFFFFFF : RenderUtil.withAlpha(acc, 100));
                }

                modY += ROW_H;
            }
            if (visibleModules.isEmpty()) {
                ctx.drawTextWithShadow(mc.textRenderer, "Нет модулей", contentX + 10, contentY + 6, TEXT_DIM);
            }
        }

        if (settingsModule != null) {
            int sw = 140;
            int sx = x - sw - 12;
            if (sx < 6) sx = 6;
            int sy = y;
            boolean isAS = settingsModule instanceof AutoSwap;
            int extra = isAS ? 20 : 0;
            int sHeight = 40 + settingsModule.getSettings().size() * 20 + extra;

            RenderUtil.shadow(ctx, sx, sy, sw, sHeight, R_MAIN);
            RenderUtil.roundedGradient(ctx, sx, sy, sw, sHeight, R_MAIN, BG_TOP, SETTINGS_BG);
            RenderUtil.roundedOutline(ctx, sx, sy, sw, sHeight, R_MAIN, RenderUtil.withAlpha(acc, 80), 1);

            RenderUtil.roundedGradient(ctx, sx + 1, sy + 1, sw - 2, 22, R_MAIN - 1,
                    RenderUtil.withAlpha(acc, 60), RenderUtil.withAlpha(acc, 0));
            ctx.drawTextWithShadow(mc.textRenderer, settingsModule.getName(), sx + 12, sy + 8, acc);

            int setY = sy + 28;
            for (Setting set : settingsModule.getSettings()) {
                String val;
                if (set.isSlider()) val = set.getName() + ": " + String.format("%.2f", set.getFloat());
                else if (set.isBoolean()) val = set.getName() + ": " + (set.getBool() ? "§aON" : "§cOFF");
                else val = set.getName() + ": " + set.getString();

                boolean hovered = smx >= sx + 6 && smx <= sx + sw - 6 && smy >= setY && smy <= setY + 18;
                if (hovered) RenderUtil.roundedRect(ctx, sx + 6, setY, sw - 12, 18, 5, ROW_HOVER);
                ctx.drawTextWithShadow(mc.textRenderer, val, sx + 12, setY + 5, TEXT);

                if (set.isSlider()) {
                    float pct = (set.getFloat() - set.getMin()) / (set.getMax() - set.getMin());
                    int barY = setY + 16;
                    RenderUtil.roundedRect(ctx, sx + 12, barY, sw - 24, 2, 1, new Color(60, 60, 70).getRGB());
                    RenderUtil.roundedGradient(ctx, sx + 12, barY, (int)((sw - 24) * pct), 2, 1, acc2, acc);
                }
                setY += 20;
            }

            if (isAS) {
                AutoSwap as = (AutoSwap) settingsModule;
                String txt;
                if (bindSwapModule == as) txt = "Клавиша: [...]";
                else if (as.swapKey != -1) txt = "Клавиша: " + GLFW.glfwGetKeyName(as.swapKey, 0);
                else txt = "Клавиша: нет";
                boolean hovered = smx >= sx + 6 && smx <= sx + sw - 6 && smy >= setY && smy <= setY + 18;
                if (hovered) RenderUtil.roundedRect(ctx, sx + 6, setY, sw - 12, 18, 5, ROW_HOVER);
                ctx.drawTextWithShadow(mc.textRenderer, txt, sx + 12, setY + 5, TEXT);
            }
        }

        ctx.getMatrices().pop();
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        double smx = mouseX / SCALE;
        double smy = mouseY / SCALE;
        int x = gx(), y = gy(), w = GUI_W;

        if (smx >= x + w - 22 && smx <= x + w - 8 && smy >= y + 7 && smy <= y + 21) {
            close();
            return true;
        }

        if (settingsModule != null) {
            int sw = 140;
            int sx = x - sw - 12;
            if (sx < 6) sx = 6;
            int setY = y + 28;
            for (Setting set : settingsModule.getSettings()) {
                if (smx >= sx + 6 && smx <= sx + sw - 6 && smy >= setY && smy <= setY + 18) {
                    if (button == 0) {
                        if (set.isSlider()) { draggingSlider = set; applySlider(set, smx, sx, sw); }
                        else if (set.isBoolean()) set.setValue(!set.getBool());
                        else set.nextOption();
                    }
                    return true;
                }
                setY += 20;
            }
            if (settingsModule instanceof AutoSwap) {
                if (smx >= sx + 6 && smx <= sx + sw - 6 && smy >= setY && smy <= setY + 18) {
                    if (button == 0) bindSwapModule = (AutoSwap) settingsModule;
                    return true;
                }
            }
        }

        int catY = y + HEADER_H + 6;
        for (Category cat : Category.values()) {
            if (smx >= x + 8 && smx <= x + 8 + SIDEBAR_W && smy >= catY && smy <= catY + 20) {
                selectedCategory = cat;
                settingsModule = null;
                return true;
            }
            catY += ROW_H;
        }

        int contentX = x + SIDEBAR_W + 16;
        int contentW = w - SIDEBAR_W - 24;
        int contentY = y + HEADER_H + 6;

        if (selectedCategory == Category.Themes) {
            int ty = contentY;
            for (String c : Theme.COLORS) {
                if (smx >= contentX && smx <= contentX + contentW && smy >= ty && smy <= ty + 20) {
                    if (button == 0) { Theme.current = c; com.felest.util.ConfigManager.save(); }
                    return true;
                }
                ty += ROW_H;
            }
        } else {
            int modY = contentY;
            for (Module mod : visibleModules) {
                if (smx >= contentX && smx <= contentX + contentW && smy >= modY && smy <= modY + 20) {
                    if (button == 0) mod.toggle();
                    else if (button == 1) settingsModule = (settingsModule == mod) ? null : mod;
                    else if (button == 2) bindModule = mod;
                    return true;
                }
                modY += ROW_H;
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (draggingSlider != null && button == 0) {
            double smx = mouseX / SCALE;
            int sw = 140;
            int x = gx();
            int sx = x - sw - 12;
            if (sx < 6) sx = 6;
            applySlider(draggingSlider, smx, sx, sw);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (draggingSlider != null) { draggingSlider = null; return true; }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    private void applySlider(Setting set, double mouseX, int sx, int sw) {
        float pct = (float)(mouseX - (sx + 12)) / (float)(sw - 24);
        set.setFromPercent(Math.max(0f, Math.min(1f, pct)));
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (bindModule != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE) bindModule.setKeyBind(-1);
            else bindModule.setKeyBind(keyCode);
            bindModule = null;
            return true;
        }
        if (bindSwapModule != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE) bindSwapModule.swapKey = -1;
            else bindSwapModule.swapKey = keyCode;
            bindSwapModule = null;
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() { return false; }
}
