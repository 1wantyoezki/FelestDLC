package com.felest.gui;

import com.felest.FelestDLC;
import com.felest.module.Module;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

public class GuiHandler {
    public static KeyBinding openGuiKey;
    public static KeyBinding openHudEditorKey;
    private static final Map<Integer, Boolean> keyWasReleased = new HashMap<>();

    public static void register() {
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.felestdlc.opengui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.felestdlc"
        ));

        openHudEditorKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.felestdlc.hudeditor",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_INSERT,
                "category.felestdlc"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new ClickGUI());
            }
            while (openHudEditorKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new HudEditor());
            }

            if (client.currentScreen == null && FelestDLC.moduleManager != null) {
                for (Module m : FelestDLC.moduleManager.getModules()) {
                    int key = m.getKeyBind();
                    if (key == -1) continue;
                    boolean isPressed = InputUtil.isKeyPressed(client.getWindow().getHandle(), key);
                    boolean wasReleased = keyWasReleased.getOrDefault(key, true);
                    if (isPressed && wasReleased) {
                        m.toggle();
                        keyWasReleased.put(key, false);
                    } else if (!isPressed) {
                        keyWasReleased.put(key, true);
                    }
                }
            }
        });
    }
}
