package com.felest.gui;

import com.felest.FelestDLC;
import com.felest.module.impl.Hud;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class HudEditor extends Screen {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    private String dragging = null;
    private double dragOffX = 0, dragOffY = 0;

    private final int W_WM = 160, H_WM = 16;
    private final int W_CD = 140, H_CD = 16;
    private final int W_POT = 120, H_POT = 60;
    private final int W_TGT = 130, H_TGT = 36;
    private final int W_BPS = 100, H_BPS = 34;

    public HudEditor() { super(Text.literal("HUD Editor")); }

    private Hud getHud() {
        if (FelestDLC.moduleManager == null) return null;
        return (Hud) FelestDLC.moduleManager.getModuleByName("HUD");
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.width, this.height, 0x80000000);

        Hud hud = getHud();
        if (hud == null) return;

        hud.editorMode = true;
        hud.render(context);
        hud.editorMode = false;

        context.drawTextWithShadow(mc.textRenderer,
                "Тащи блоки ЛКМ | ESC — сохранить и выйти",
                10, this.height - 20, 0xFFFFFFFF);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);
        Hud hud = getHud();
        if (hud == null) return false;

        if (hud.watermark.getBool() && inBox(mx, my, hud.watermarkX, hud.watermarkY, W_WM, H_WM)) dragging = "watermark";
        else if (hud.cooldowns.getBool() && inBox(mx, my, hud.cooldownsX, hud.cooldownsY, W_CD, H_CD)) dragging = "cooldowns";
        else if (hud.potions.getBool() && inBox(mx, my, hud.potionsX, hud.potionsY, W_POT, H_POT)) dragging = "potions";
        else if (hud.targetHud.getBool() && inBox(mx, my, hud.targetX, hud.targetY, W_TGT, H_TGT)) dragging = "target";
        else if (hud.bpsTps.getBool() && inBox(mx, my, hud.bpsX, hud.bpsY, W_BPS, H_BPS)) dragging = "bps";
        else return false;

        dragOffX = mx;
        dragOffY = my;
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging == null || button != 0) return super.mouseDragged(mx, my, button, dx, dy);
        Hud hud = getHud();
        if (hud == null) return false;

        float moveX = (float)(mx - dragOffX);
        float moveY = (float)(my - dragOffY);
        dragOffX = mx;
        dragOffY = my;

        switch (dragging) {
            case "watermark": hud.watermarkX += moveX; hud.watermarkY += moveY; break;
            case "cooldowns": hud.cooldownsX += moveX; hud.cooldownsY += moveY; break;
            case "potions":   hud.potionsX   += moveX; hud.potionsY   += moveY; break;
            case "target":    hud.targetX    += moveX; hud.targetY    += moveY; break;
            case "bps":       hud.bpsX       += moveX; hud.bpsY       += moveY; break;
        }
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) {
            com.felest.util.ConfigManager.save();
            this.close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private boolean inBox(double mx, double my, float x, float y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    @Override
    public boolean shouldPause() { return false; }
}
