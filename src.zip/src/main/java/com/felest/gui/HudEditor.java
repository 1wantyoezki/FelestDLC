package com.felest.gui;

import com.felest.FelestDLC;
import com.felest.module.impl.Hud;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class HudEditor extends Screen {
    private final MinecraftClient mc = MinecraftClient.getInstance();
    private String dragging = null;
    private double dragOffX = 0, dragOffY = 0;

    public HudEditor() { super(Text.literal("HUD Editor")); }

    private Hud getHud() {
        if (FelestDLC.moduleManager == null) return null;
        return (Hud) FelestDLC.moduleManager.getModuleByName("HUD");
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.width, this.height, 0x80000000);
        Hud hud = getHud();
        if (hud == null) return;
        hud.editorMode = true;
        hud.render(context);
        hud.editorMode = false;
        context.drawTextWithShadow(mc.textRenderer,
                "Тащи блоки ЛКМ | Insert — открыть | ESC — сохранить и выйти",
                10, this.height - 20, 0xFFFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);
        Hud hud = getHud();
        if (hud == null) return false;
        float s = hud.scale.getFloat();
        double smx = mx / s, smy = my / s;

        // Порядок: watermark, keybinds, schedules, target, bps
        if (hud.watermark.getBool() && inBox(smx, smy, hud.watermarkX, hud.watermarkY, 300, 16)) dragging = "watermark";
        else if (hud.keybinds.getBool() && inBox(smx, smy, hud.keybindsX, hud.keybindsY, 130, 200)) dragging = "keybinds";
        else if (hud.schedules.getBool() && inBox(smx, smy, hud.schedulesX, hud.schedulesY, 150, 100)) dragging = "schedules";
        else if (hud.targetHud.getBool() && inBox(smx, smy, hud.targetX, hud.targetY, 140, 40)) dragging = "target";
        else if (hud.bpsTps.getBool() && inBox(smx, smy, hud.bpsX, hud.bpsY, 200, 16)) dragging = "bps";
        else return false;

        dragOffX = smx;
        dragOffY = smy;
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging == null || button != 0) return super.mouseDragged(mx, my, button, dx, dy);
        Hud hud = getHud();
        if (hud == null) return false;
        float s = hud.scale.getFloat();
        double smx = mx / s, smy = my / s;

        float moveX = (float)(smx - dragOffX);
        float moveY = (float)(smy - dragOffY);
        dragOffX = smx;
        dragOffY = smy;

        switch (dragging) {
            case "watermark": hud.watermarkX += moveX; hud.watermarkY += moveY; break;
            case "keybinds":  hud.keybindsX  += moveX; hud.keybindsY  += moveY; break;
            case "schedules": hud.schedulesX += moveX; hud.schedulesY += moveY; break;
            case "target":    hud.targetX    += moveX; hud.targetY    += moveY; break;
            case "bps":       hud.bpsX       += moveX; hud.bpsY       += moveY; break;
        }
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) {
            com.felest.util.ConfigManager.save();
            this.close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private boolean inBox(double mx, double my, float x, float y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    @Override
    public boolean shouldPause() { return false; }
}
