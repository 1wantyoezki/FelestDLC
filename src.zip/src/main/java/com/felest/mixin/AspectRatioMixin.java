package com.felest.mixin;

import com.felest.FelestDLC;
import com.felest.module.impl.AspectRatio;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.Window;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(GameRenderer.class)
public class AspectRatioMixin {

    @Redirect(method = "getBasicProjectionMatrix", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/util/Window;getFramebufferWidth()I"))
    private int redirectWidth(Window window) {
        int original = window.getFramebufferWidth();
        if (FelestDLC.moduleManager == null) return original;

        AspectRatio ar = (AspectRatio) FelestDLC.moduleManager.getModuleByName("AspectRatio");
        if (ar == null || !ar.isEnabled()) return original;

        float ratio = ar.ratio.getFloat();
        // ratio < 1.0 → экран "уже" → видно больше по горизонтали
        return (int)(original / ratio);
    }
}
