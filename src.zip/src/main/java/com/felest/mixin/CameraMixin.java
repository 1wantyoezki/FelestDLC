package com.felest.mixin;

import com.felest.FelestDLC;
import com.felest.module.impl.KillAura;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public class CameraMixin {
    @Shadow private Vec3d pos;
    @Shadow private float yaw;
    @Shadow private float pitch;

    @Inject(method = "update", at = @At("TAIL"))
    private void onUpdate(BlockView area, Entity focusedEntity, boolean thirdPerson, boolean inverseView, float tickDelta, CallbackInfo ci) {
        // FreeCam
        if (FelestDLC.freeCam != null && FelestDLC.freeCam.isEnabled()) {
            this.pos = FelestDLC.freeCam.getCameraPos();
            this.yaw = FelestDLC.freeCam.getCameraYaw();
            this.pitch = FelestDLC.freeCam.getCameraPitch();
            return;
        }

        // KillAura silent aim — в ТРЕТЬЕМ лице камера крутится вместе с наводкой
        if (thirdPerson && FelestDLC.moduleManager != null) {
            KillAura ka = (KillAura) FelestDLC.moduleManager.getModuleByName("KillAura");
            if (ka != null && ka.isEnabled() && ka.silentActive) {
                this.yaw = ka.silentYaw;
                this.pitch = ka.silentPitch;
            }
        }
    }
}
