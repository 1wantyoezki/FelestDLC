package com.felest.mixin;

import com.felest.FelestDLC;
import com.felest.module.impl.MiniChat;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.ChatHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChatHud.class)
public class ChatHudMixin {

    private static boolean scaled = false;

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void onRenderHead(DrawContext context, int currentTick, int mouseX, int mouseY, boolean focused, CallbackInfo ci) {
        scaled = false;
        if (FelestDLC.moduleManager == null) return;
        MiniChat mc = (MiniChat) FelestDLC.moduleManager.getModuleByName("MiniChat");
        if (mc == null || !mc.isEnabled()) return;

        // Скрываем чат если видимость = 0, но показываем когда T открыт
        if (mc.getOpacity() <= 0 && !focused) {
            ci.cancel();
            return;
        }

        float scale = mc.scale.getFloat();
        if (scale != 1.0f) {
            int h = MinecraftClient.getInstance().getWindow().getScaledHeight();
            context.getMatrices().push();
            // Скейлим от левого-нижнего угла
            context.getMatrices().translate(0, h, 0);
            context.getMatrices().scale(scale, scale, 1f);
            context.getMatrices().translate(0, -h, 0);
            scaled = true;
        }
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void onRenderReturn(DrawContext context, int currentTick, int mouseX, int mouseY, boolean focused, CallbackInfo ci) {
        if (scaled) {
            context.getMatrices().pop();
            scaled = false;
        }
    }
}
