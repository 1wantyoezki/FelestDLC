package com.felest.mixin;

import com.felest.FelestDLC;
import com.felest.module.impl.Hud;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ChatScreen.class)
public class ChatScreenMixin {

    private static String dragging = null;
    private static double dragOffX = 0, dragOffY = 0;

    private static final int W_WM = 160, H_WM = 16;
    private static final int W_CD = 140, H_CD = 16;
    private static final int W_POT = 120, H_POT = 60;
    private static final int W_TGT = 130, H_TGT = 36;
    private static final int W_BPS = 100, H_BPS = 34;

    private Hud getHud() {
        if (FelestDLC.moduleManager == null) return null;
        return (Hud) FelestDLC.moduleManager.getModuleByName("HUD");
    }

    // Рисуем HUD + рамки поверх чата
    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        Hud hud = getHud();
        if (hud == null || !hud.isEnabled()) return;
        hud.editorMode = true;
        hud.render(ctx);
        hud.editorMode = false;
    }

    // Клик
    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void onMouseClicked(double mx, double my, int button, CallbackInfoReturnable<Boolean> cir) {
        if (button != 0) return;
        Hud hud = getHud();
        if (hud == null || !hud.isEnabled()) return;

        if (hud.watermark.getBool() && inBox(mx, my, hud.watermarkX, hud.watermarkY, W_WM, H_WM)) dragging = "watermark";
        else if (hud.cooldowns.getBool() && inBox(mx, my, hud.cooldownsX, hud.cooldownsY, W_CD, H_CD)) dragging = "cooldowns";
        else if (hud.potions.getBool() && inBox(mx, my, hud.potionsX, hud.potionsY, W_POT, H_POT)) dragging = "potions";
        else if (hud.targetHud.getBool() && inBox(mx, my, hud.targetX, hud.targetY, W_TGT, H_TGT)) dragging = "target";
        else if (hud.bpsTps.getBool() && inBox(mx, my, hud.bpsX, hud.bpsY, W_BPS, H_BPS)) dragging = "bps";
        else { dragging = null; return; }

        dragOffX = mx;
        dragOffY = my;
        cir.setReturnValue(true);
    }

    // Драг
    @Inject(method = "mouseDragged", at = @At("HEAD"), cancellable = true)
    private void onMouseDragged(double mx, double my, int button, double dx, double dy, CallbackInfoReturnable<Boolean> cir) {
        if (dragging == null || button != 0) return;
        Hud hud = getHud();
        if (hud == null) return;

        float moveX = (float)(mx - dragOffX);
        float moveY = (float)(my - dragOffY);
        dragOffX = mx;
        dragOffY = my;

        switch (dragging) {
            case "watermark": hud.watermarkX += moveX; hud.watermarkY += moveY; break;
            case "cooldowns": hud.cooldownsX += moveX; hud.cooldownsY += moveY; break;
            case "potions":   hud.potionsX   += moveX; hud.potionsY   += moveY; break;
            case "target":    hud.targetX    += moveX; hud.targetY    += moveY; break;
            case "bps":       hud.bpsX       += moveX; hud.bpsY       += moveY; break;
        }
        cir.setReturnValue(true);
    }

    // Отпустил
    @Inject(method = "mouseReleased", at = @At("HEAD"), cancellable = true)
    private void onMouseReleased(double mx, double my, int button, CallbackInfoReturnable<Boolean> cir) {
        if (dragging != null) {
            dragging = null;
            cir.setReturnValue(true);
        }
    }

    // ESC — сохраняем
    @Inject(method = "keyPressed", at = @At("HEAD"))
    private void onKeyPressed(int keyCode, int scanCode, int modifiers, CallbackInfoReturnable<Boolean> cir) {
        if (keyCode == 256) { // ESC
            com.felest.util.ConfigManager.save();
        }
    }

    private boolean inBox(double mx, double my, float x, float y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }
}
