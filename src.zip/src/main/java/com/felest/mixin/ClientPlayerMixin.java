package com.felest.mixin;

import com.felest.FelestDLC;
import com.felest.module.impl.KillAura;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public class ClientPlayerMixin {

    @Shadow private float lastYaw;
    @Shadow private float lastPitch;

    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void onSendHead(CallbackInfo ci) {
        if (FelestDLC.moduleManager == null) return;
        KillAura ka = (KillAura) FelestDLC.moduleManager.getModuleByName("KillAura");
        if (ka == null || !ka.isEnabled() || !ka.silentActive) return;

        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
        ka.realYaw = self.getYaw();
        ka.realPitch = self.getPitch();

        // Поворот ограничен — не больше 30° за тик
        float deltaYaw = wrapDegrees(ka.silentYaw - ka.realYaw);
        if (deltaYaw > 30f) deltaYaw = 30f;
        if (deltaYaw < -30f) deltaYaw = -30f;

        float deltaPitch = ka.silentPitch - ka.realPitch;
        if (deltaPitch > 20f) deltaPitch = 20f;
        if (deltaPitch < -20f) deltaPitch = -20f;

        ka.serverYaw = ka.realYaw + deltaYaw;
        ka.serverPitch = ka.realPitch + deltaPitch;

        self.setYaw(ka.serverYaw);
        self.setPitch(ka.serverPitch);

        // Форсим отправку пакета — сбрасываем кэш
        this.lastYaw = ka.realYaw + 999f;
        this.lastPitch = ka.realPitch + 999f;
    }

    @Inject(method = "sendMovementPackets", at = @At("TAIL"))
    private void onSendTail(CallbackInfo ci) {
        if (FelestDLC.moduleManager == null) return;
        KillAura ka = (KillAura) FelestDLC.moduleManager.getModuleByName("KillAura");
        if (ka == null || !ka.silentActive) return;

        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
        self.setYaw(ka.realYaw);
        self.setPitch(ka.realPitch);
    }

    private float wrapDegrees(float deg) {
        deg = deg % 360f;
        if (deg >= 180f) deg -= 360f;
        if (deg < -180f) deg += 360f;
        return deg;
    }
}
