package com.felest.mixin;

import com.felest.FelestDLC;
import com.felest.module.impl.KillAura;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public class ClientPlayerMixin {

    @Shadow private float lastYaw;
    @Shadow private float lastPitch;

    // Перед отправкой пакетов — подменяем углы на silent, чтобы ушло на сервер
    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void onSendHead(CallbackInfo ci) {
        if (FelestDLC.moduleManager == null) return;
        KillAura ka = (KillAura) FelestDLC.moduleManager.getModuleByName("KillAura");
        if (ka == null || !ka.isEnabled() || !ka.silentActive) return;

        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
        ka.realYaw = self.getYaw();
        ka.realPitch = self.getPitch();
        self.setYaw(ka.silentYaw);
        self.setPitch(ka.silentPitch);

        // Сбрасываем lastYaw/lastPitch, чтобы пакет ТОЧНО отправился
        this.lastYaw = ka.realYaw + 0.001f;
        this.lastPitch = ka.realPitch + 0.001f;
    }

    // После отправки — возвращаем игроку его настоящие углы (камера не двигается)
    @Inject(method = "sendMovementPackets", at = @At("TAIL"))
    private void onSendTail(CallbackInfo ci) {
        if (FelestDLC.moduleManager == null) return;
        KillAura ka = (KillAura) FelestDLC.moduleManager.getModuleByName("KillAura");
        if (ka == null || !ka.silentActive) return;

        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
        self.setYaw(ka.realYaw);
        self.setPitch(ka.realPitch);
    }
}
