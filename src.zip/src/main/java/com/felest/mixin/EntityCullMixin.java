package com.felest.mixin;

import com.felest.FelestDLC;
import com.felest.module.impl.NoRender;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderDispatcher.class)
public class EntityCullMixin {

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void onRender(Entity entity, double x, double y, double z, float tickDelta,
                           MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                           int light, CallbackInfo ci) {
        if (entity == null) return;
        if (FelestDLC.moduleManager == null) return;

        NoRender nr = (NoRender) FelestDLC.moduleManager.getModuleByName("NoRender");
        if (nr == null || !nr.isEnabled() || !nr.entityCull.getBool()) return;

        PlayerEntity p = MinecraftClient.getInstance().player;
        if (p == null || entity == p) return;

        double dx = entity.getX() - p.getX();
        double dz = entity.getZ() - p.getZ();
        float angleToEntity = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        float delta = Math.abs(MathHelper.wrapDegrees(angleToEntity - p.getYaw()));
        if (delta > 90f) {
            ci.cancel();
        }
    }
}
