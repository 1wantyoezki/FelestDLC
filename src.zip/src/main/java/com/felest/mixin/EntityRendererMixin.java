package com.felest.mixin;

import com.felest.FelestDLC;
import com.felest.module.impl.KillAura;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntityRenderer.class)
public class EntityRendererMixin {

    @Inject(method = "updateRenderState", at = @At("TAIL"))
    private void onUpdateRenderState(LivingEntity entity, LivingEntityRenderState state, float tickDelta, CallbackInfo ci) {
        if (entity != MinecraftClient.getInstance().player) return;
        if (FelestDLC.moduleManager == null) return;
        KillAura ka = (KillAura) FelestDLC.moduleManager.getModuleByName("KillAura");
        if (ka == null || !ka.isEnabled() || !ka.silentActive) return;

        // В 1.21.4 доступны bodyYaw и pitch — этого хватит для рендера модели
        state.bodyYaw = ka.silentYaw;
        state.pitch = ka.silentPitch;
    }
}
