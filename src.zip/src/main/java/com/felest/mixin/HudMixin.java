package com.felest.mixin;

import com.felest.FelestDLC;
import com.felest.module.impl.Hud;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class HudMixin {

    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (FelestDLC.moduleManager == null) return;
        Hud hud = (Hud) FelestDLC.moduleManager.getModuleByName("HUD");
        if (hud != null && hud.isEnabled()) {
            hud.render(context);
        }
    }
}
