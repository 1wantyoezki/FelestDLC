package com.felest.mixin;

import com.felest.FelestDLC;
import com.felest.module.impl.NameTags;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderer.class)
public class NameTagsMixin {

    @Inject(method = "renderLabelIfPresent", at = @At("HEAD"))
    private void onRenderHead(Entity entity, Text text, MatrixStack matrices,
                               VertexConsumerProvider vertexConsumers, int light, float tickDelta,
                               CallbackInfo ci) {
        if (FelestDLC.moduleManager == null) return;
        NameTags nt = (NameTags) FelestDLC.moduleManager.getModuleByName("NameTags");
        if (nt == null || !nt.isEnabled()) return;

        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
    }

    @Inject(method = "renderLabelIfPresent", at = @At("TAIL"))
    private void onRenderTail(Entity entity, Text text, MatrixStack matrices,
                               VertexConsumerProvider vertexConsumers, int light, float tickDelta,
                               CallbackInfo ci) {
        if (FelestDLC.moduleManager == null) return;
        NameTags nt = (NameTags) FelestDLC.moduleManager.getModuleByName("NameTags");
        if (nt == null || !nt.isEnabled()) return;

        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
    }
}
