package com.felest.mixin;

import com.felest.FelestDLC;
import com.felest.module.impl.Optimization;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class OptimizationHudMixin {

    @Inject(method = "renderVignetteOverlay", at = @At("HEAD"), cancellable = true)
    private void onVignette(CallbackInfo ci) {
        if (optEnabled("noVignette")) ci.cancel();
    }

    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true)
    private void onFire(CallbackInfo ci) {
        if (optEnabled("noFireOverlay")) ci.cancel();
    }

    @Inject(method = "renderUnderwaterOverlay", at = @At("HEAD"), cancellable = true)
    private void onWater(CallbackInfo ci) {
        if (optEnabled("noWaterOverlay")) ci.cancel();
    }

    private boolean optEnabled(String setting) {
        if (FelestDLC.moduleManager == null) return false;
        Optimization o = (Optimization) FelestDLC.moduleManager.getModuleByName("Optimization");
        if (o == null || !o.isEnabled()) return false;
        switch (setting) {
            case "noVignette": return o.noVignette.getBool();
            case "noFireOverlay": return o.noFireOverlay.getBool();
            case "noWaterOverlay": return o.noWaterOverlay.getBool();
        }
        return false;
    }
}
