package com.felest.mixin;

import com.felest.FelestDLC;
import com.felest.module.impl.Optimization;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class OptimizationMixin {

    @Inject(method = "bobView", at = @At("HEAD"), cancellable = true)
    private void onBobView(CallbackInfo ci) {
        if (optEnabled("noHurtCam")) ci.cancel();
    }

    @Inject(method = "renderNausea", at = @At("HEAD"), cancellable = true)
    private void onNausea(CallbackInfo ci) {
        if (optEnabled("noNausea")) ci.cancel();
    }

    private boolean optEnabled(String setting) {
        if (FelestDLC.moduleManager == null) return false;
        Optimization o = (Optimization) FelestDLC.moduleManager.getModuleByName("Optimization");
        if (o == null || !o.isEnabled()) return false;
        switch (setting) {
            case "noHurtCam": return o.noHurtCam.getBool();
            case "noNausea": return o.noNausea.getBool();
        }
        return false;
    }
}
