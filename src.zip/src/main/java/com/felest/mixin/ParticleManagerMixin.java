package com.felest.mixin;

import com.felest.FelestDLC;
import com.felest.module.impl.Optimization;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ParticleManager.class)
public class ParticleManagerMixin {

    @Inject(method = "addParticle(Lnet/minecraft/client/particle/Particle;)V", at = @At("HEAD"), cancellable = true)
    private void onAddParticle(Particle particle, CallbackInfo ci) {
        if (FelestDLC.moduleManager == null) return;
        Optimization o = (Optimization) FelestDLC.moduleManager.getModuleByName("Optimization");
        if (o == null || !o.isEnabled()) return;

        String name = particle.getClass().getSimpleName().toLowerCase();
        if (o.noBlockBreakParticles.getBool() && name.contains("block")) ci.cancel();
        if (o.noPotionParticles.getBool() && (name.contains("spell") || name.contains("effect"))) ci.cancel();
    }
}
