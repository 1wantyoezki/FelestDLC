package com.felest.mixin;

import com.felest.FelestDLC;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public class PlayerMoveMixin {

    @Inject(method = "tickMovement", at = @At("HEAD"), cancellable = true)
    private void onTickMovement(CallbackInfo ci) {
        if (FelestDLC.freeCam != null && FelestDLC.freeCam.isEnabled()) {
            ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
            // Обнуляем горизонтальное движение, Y оставляем (чтобы падал)
            player.setVelocity(0, player.getVelocity().y, 0);
            ci.cancel();
        }
    }
}
