package com.felest.mixin;

import com.felest.FelestDLC;
import com.felest.module.impl.MiniBoard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class ScoreboardMixin {

    private static boolean scaled = false;

    @Inject(method = "renderScoreboardSidebar", at = @At("HEAD"), cancellable = true)
    private void onRenderHead(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        scaled = false;
        if (FelestDLC.moduleManager == null) return;
        MiniBoard mb = (MiniBoard) FelestDLC.moduleManager.getModuleByName("MiniBoard");
        if (mb == null || !mb.isEnabled()) return;

        // Если прозрачность 0 — полностью скрываем
        if (mb.opacity.getFloat() <= 0) {
            ci.cancel();
            return;
        }

        // Меняем прозрачность фона (vanilla options)
        // textBackgroundOpacity в options от 0.0 до 1.0
        float op = mb.opacity.getFloat() / 100f;
        MinecraftClient.getInstance().options.getTextBackgroundOpacity().setValue(op);

        // Скейл
        float s = mb.scale.getFloat();
        if (s != 1.0f) {
            int screenW = MinecraftClient.getInstance().getWindow().getScaledWidth();
            context.getMatrices().push();
            // Скейлим от верхнего-правого угла
            context.getMatrices().translate(screenW, 0, 0);
            context.getMatrices().scale(s, s, 1f);
            context.getMatrices().translate(-screenW, 0, 0);
            scaled = true;
        }
    }

    @Inject(method = "renderScoreboardSidebar", at = @At("RETURN"))
    private void onRenderReturn(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (scaled) {
            context.getMatrices().pop();
            scaled = false;
        }
    }
}
