package com.felest.mixin;

import com.felest.FelestDLC;
import com.felest.module.impl.MiniBoard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.scoreboard.ScoreboardObjective;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class ScoreboardMixin {

    private static boolean scaled = false;

    @Inject(method = "renderScoreboardSidebar", at = @At("HEAD"), cancellable = true)
    private void onRenderHead(DrawContext context, ScoreboardObjective objective, CallbackInfo ci) {
        scaled = false;
        if (FelestDLC.moduleManager == null) return;
        MiniBoard mb = (MiniBoard) FelestDLC.moduleManager.getModuleByName("MiniBoard");
        if (mb == null || !mb.isEnabled()) return;

        // Если прозрачность 0 — скрыть полностью
        if (mb.opacity.getFloat() <= 0) {
            ci.cancel();
            return;
        }

        float s = mb.scale.getFloat();
        if (s != 1.0f) {
            int h = MinecraftClient.getInstance().getWindow().getScaledHeight();
            context.getMatrices().push();
            context.getMatrices().translate(0, 0, 0);
            // Скейлим от правого-верхнего угла
            context.getMatrices().translate(
                    MinecraftClient.getInstance().getWindow().getScaledWidth(), 0, 0);
            context.getMatrices().scale(s, s, 1f);
            context.getMatrices().translate(
                    -MinecraftClient.getInstance().getWindow().getScaledWidth(), 0, 0);
            scaled = true;
        }
    }

    @Inject(method = "renderScoreboardSidebar", at = @At("RETURN"))
    private void onRenderReturn(DrawContext context, ScoreboardObjective objective, CallbackInfo ci) {
        if (scaled) {
            context.getMatrices().pop();
            scaled = false;
        }
    }
}
