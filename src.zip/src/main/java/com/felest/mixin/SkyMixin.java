package com.felest.mixin;

import com.felest.FelestDLC;
import com.felest.module.impl.Fullbright;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(World.class)
public class SkyMixin {

    @Inject(method = "getSkyBrightness", at = @At("HEAD"), cancellable = true)
    private void onGetSkyBrightness(CallbackInfoReturnable<Float> cir) {
        if (FelestDLC.moduleManager == null) return;
        Fullbright fb = (Fullbright) FelestDLC.moduleManager.getModuleByName("Fullbright");
        if (fb != null && fb.isEnabled()) {
            cir.setReturnValue(1.0f);
        }
    }
}
