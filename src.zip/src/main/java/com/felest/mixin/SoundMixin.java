package com.felest.mixin;

import com.felest.FelestDLC;
import com.felest.module.impl.NoRender;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.sound.SoundSystem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SoundSystem.class)
public class SoundMixin {

    @Inject(method = "play", at = @At("HEAD"), cancellable = true)
    private void onPlay(SoundInstance sound, CallbackInfo ci) {
        if (FelestDLC.moduleManager == null) return;
        NoRender noRender = (NoRender) FelestDLC.moduleManager.getModuleByName("NoRender");
        if (noRender == null || !noRender.isEnabled() || !noRender.sound.getBool()) return;

        String id = sound.getId().getPath();
        if (id.contains("rain") || id.contains("thunder") || id.contains("weather")) {
            ci.cancel();
        }
    }
}
