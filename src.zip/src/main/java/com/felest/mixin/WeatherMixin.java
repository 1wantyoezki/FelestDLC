package com.felest.mixin;

import com.felest.FelestDLC;
import com.felest.module.impl.NoRender;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
public class WeatherMixin {

    @Inject(method = "renderWeather", at = @At("HEAD"), cancellable = true)
    private void onRenderWeather(CallbackInfo ci) {
        if (FelestDLC.moduleManager == null) return;
        NoRender noRender = (NoRender) FelestDLC.moduleManager.getModuleByName("NoRender");
        if (noRender != null && noRender.isEnabled()) {
            if (noRender.rain.getBool() || noRender.thunder.getBool() || noRender.snow.getBool()) {
                ci.cancel();
            }
        }
    }
}
