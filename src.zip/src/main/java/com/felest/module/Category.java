package com.felest.module;

public enum Category {
    Combat,
    Movement,
    Render,
    Player,
    Misc,
    Configs,
    Themes
}
