package com.felest.module;

import com.felest.setting.Setting;
import java.util.ArrayList;
import java.util.List;

public class Module {
    private final String name;
    private final Category category;
    private boolean enabled;
    private int keyBind = -1;
    private final List<Setting> settings = new ArrayList<>();

    public Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    public String getName() { return name; }
    public Category getCategory() { return category; }
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public void toggle() {
        this.enabled = !this.enabled;
        if (this.enabled) onEnable(); else onDisable();
    }

    public int getKeyBind() { return keyBind; }
    public void setKeyBind(int keyBind) { this.keyBind = keyBind; }

    public List<Setting> getSettings() { return settings; }
    protected void addSetting(Setting setting) { settings.add(setting); }

    public void onEnable() {}
    public void onDisable() {}
    public void onUpdate() {}
}
