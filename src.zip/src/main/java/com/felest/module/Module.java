package com.felest.module;

import com.felest.setting.Setting;
import java.util.ArrayList;
import java.util.List;

public class Module {
    private final String name;
    private final String description;
    private final Category category;
    private boolean enabled;
    private int keybind;
    private final List<Setting> settings = new ArrayList<>();

    public Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.enabled = false;
        this.keybind = 0;
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public boolean isEnabled() { return enabled; }
    public int getKeybind() { return keybind; }
    public List<Setting> getSettings() { return settings; }

    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public void setKeybind(int keybind) { this.keybind = keybind; }

    public void addSetting(Setting setting) { settings.add(setting); }

    public void toggle() {
        this.enabled = !this.enabled;
        if (enabled) onEnable();
        else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onUpdate() {}
}
