package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Aimbot extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting range = new Setting("Дистанция", 5.0f, 2.0f, 10.0f, 0.5f);
    public final Setting smoothness = new Setting("Плавность", 0.15f, 0.03f, 0.8f, 0.01f);
    public final Setting target = new Setting("Цель", "Игроки", "Игроки", "Мобы", "Все");
    public final Setting onlyWeapon = new Setting("Только с оружием", false);

    // Промежуточные углы (плавная цель)
    private float smoothYaw = 0f;
    private float smoothPitch = 0f;
    private boolean started = false;

    public Aimbot() {
        super("Aimbot", Category.Combat);
        addSetting(range);
        addSetting(smoothness);
        addSetting(target);
        addSetting(onlyWeapon);
    }

    @Override
    public void onEnable() {
        if (mc.player != null) {
            smoothYaw = mc.player.getYaw();
            smoothPitch = mc.player.getPitch();
            started = true;
        }
    }

    @Override
    public void onDisable() {
        started = false;
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) return;

        if (onlyWeapon.getBool()) {
            net.minecraft.item.ItemStack main = mc.player.getMainHandStack();
            boolean isWeapon = main.getItem() instanceof net.minecraft.item.SwordItem
                    || main.getItem() instanceof net.minecraft.item.AxeItem;
            if (!isWeapon) return;
        }

        LivingEntity t = findTarget();
        if (t == null) {
            started = false;
            return;
        }

        // Целевые углы
        double dx = t.getX() - mc.player.getX();
        double dy = (t.getY() + t.getHeight() / 2) - mc.player.getEyeY();
        double dz = t.getZ() - mc.player.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);

        float targetYaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        float targetPitch = (float)-Math.toDegrees(Math.atan2(dy, dist));

        if (!started) {
            smoothYaw = mc.player.getYaw();
            smoothPitch = mc.player.getPitch();
            started = true;
        }

        float speed = smoothness.getFloat();

        // 1. Сглаживаем внутреннюю "цель" — она двигается за настоящей целью медленно
        smoothYaw = lerpAngle(smoothYaw, targetYaw, speed * 0.7f);
        smoothPitch = lerpAngle(smoothPitch, targetPitch, speed * 0.7f);

        // 2. Игрока двигаем к сглаженной цели — тоже медленно
        float newYaw = lerpAngle(mc.player.getYaw(), smoothYaw, speed * 0.7f);
        float newPitch = lerpAngle(mc.player.getPitch(), smoothPitch, speed * 0.7f);

        // Мёртвая зона — если разница меньше 0.3°, не двигаем
        float yawDiff = Math.abs(wrap(mc.player.getYaw() - newYaw));
        float pitchDiff = Math.abs(mc.player.getPitch() - newPitch);
        if (yawDiff > 0.3f) mc.player.setYaw(newYaw);
        if (pitchDiff > 0.3f) mc.player.setPitch(MathHelper.clamp(newPitch, -90f, 90f));
    }

    private float wrap(float deg) {
        deg = deg % 360f;
        if (deg >= 180f) deg -= 360f;
        if (deg < -180f) deg += 360f;
        return deg;
    }

    private float lerpAngle(float current, float target, float speed) {
        float delta = ((target - current + 540) % 360) - 180;
        return current + delta * speed;
    }

    private LivingEntity findTarget() {
        List<Entity> entities = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) entities.add(e);

        String t = target.getString();
        float r = range.getFloat();

        return entities.stream()
                .filter(e -> e instanceof LivingEntity)
                .map(e -> (LivingEntity) e)
                .filter(e -> e != mc.player)
                .filter(LivingEntity::isAlive)
                .filter(e -> mc.player.distanceTo(e) <= r)
                .filter(e -> {
                    if (t.equals("Игроки")) return e instanceof PlayerEntity;
                    if (t.equals("Мобы")) return e instanceof MobEntity;
                    return e instanceof PlayerEntity || e instanceof MobEntity;
                })
                .min(Comparator.comparingDouble(e -> mc.player.distanceTo(e)))
                .orElse(null);
    }
}
