package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Aimbot extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting range = new Setting("Дистанция", 5.0f, 2.0f, 10.0f, 0.5f);
    public final Setting smoothness = new Setting("Скорость наводки", 0.35f, 0.05f, 2.5f, 0.05f);
    public final Setting target = new Setting("Цель", "Игроки", "Игроки", "Мобы", "Все");
    public final Setting onlyWeapon = new Setting("Только с оружием", false);

    private boolean justEnabled = false;
    private long lastUpdateNs = 0L;
    // 50 обновлений в секунду = 20_000_000 ns
    private static final long INTERVAL_NS = 20_000_000L;

    public Aimbot() {
        super("Aimbot", Category.Combat);
        addSetting(range);
        addSetting(smoothness);
        addSetting(target);
        addSetting(onlyWeapon);
    }

    @Override
    public void onEnable() {
        justEnabled = true;
        lastUpdateNs = 0L;
    }

    @Override
    public void onDisable() { justEnabled = false; }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) return;
        if (!justEnabled) return;

        if (onlyWeapon.getBool()) {
            net.minecraft.item.ItemStack main = mc.player.getMainHandStack();
            boolean isWeapon = main.getItem() instanceof net.minecraft.item.SwordItem
                    || main.getItem() instanceof net.minecraft.item.AxeItem;
            if (!isWeapon) return;
        }

        LivingEntity t = findTarget();
        if (t == null) return;

        double dx = t.getX() - mc.player.getX();
        double dy = (t.getY() + t.getHeight() / 2) - mc.player.getEyeY();
        double dz = t.getZ() - mc.player.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);

        float ty = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        float tp = (float)-Math.toDegrees(Math.atan2(dy, dist));

        mc.player.setYaw(ty);
        mc.player.setPitch(MathHelper.clamp(tp, -90f, 90f));
        justEnabled = false;
    }

    public void renderUpdate(float tickDelta) {
        if (mc.player == null || mc.world == null) return;

        // Лимит 50 обновлений в секунду
        long now = System.nanoTime();
        if (now - lastUpdateNs < INTERVAL_NS) return;
        lastUpdateNs = now;

        if (onlyWeapon.getBool()) {
            net.minecraft.item.ItemStack main = mc.player.getMainHandStack();
            boolean isWeapon = main.getItem() instanceof net.minecraft.item.SwordItem
                    || main.getItem() instanceof net.minecraft.item.AxeItem;
            if (!isWeapon) return;
        }

        LivingEntity t = findTarget();
        if (t == null) return;

        double dx = t.getX() - mc.player.getX();
        double dy = (t.getY() + t.getHeight() / 2) - mc.player.getEyeY();
        double dz = t.getZ() - mc.player.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);

        float targetYaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        float targetPitch = (float)-Math.toDegrees(Math.atan2(dy, dist));

        // 2.5 * 0.075 = 0.1875 — быстро, но не мгновенно
        float baseSpeed = smoothness.getFloat() * 0.075f;
        if (baseSpeed > 1.0f) baseSpeed = 1.0f;

        float newYaw = lerpAngle(mc.player.getYaw(), targetYaw, baseSpeed);
        float newPitch = lerpAngle(mc.player.getPitch(), targetPitch, baseSpeed);

        mc.player.setYaw(newYaw);
        mc.player.setPitch(MathHelper.clamp(newPitch, -90f, 90f));
    }

    private float lerpAngle(float current, float target, float speed) {
        float delta = ((target - current + 540) % 360) - 180;
        return current + delta * speed;
    }

    private LivingEntity findTarget() {
        List<Entity> entities = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) entities.add(e);

        String t = target.getString();
        float r = range.getFloat();

        return entities.stream()
                .filter(e -> e instanceof LivingEntity)
                .map(e -> (LivingEntity) e)
                .filter(e -> e != mc.player)
                .filter(LivingEntity::isAlive)
                .filter(e -> mc.player.distanceTo(e) <= r)
                .filter(e -> {
                    if (t.equals("Игроки")) return e instanceof PlayerEntity;
                    if (t.equals("Мобы")) return e instanceof MobEntity;
                    return e instanceof PlayerEntity || e instanceof MobEntity;
                })
                .min(Comparator.comparingDouble(e -> mc.player.distanceTo(e)))
                .orElse(null);
    }
}
