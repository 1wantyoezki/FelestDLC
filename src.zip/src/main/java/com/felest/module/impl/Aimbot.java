package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Aimbot extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting range = new Setting("Дистанция", 5.0f, 2.0f, 10.0f, 0.5f);
    public final Setting smoothness = new Setting("Плавность", 0.06f, 0.02f, 0.5f, 0.01f);
    public final Setting target = new Setting("Цель", "Игроки", "Игроки", "Мобы", "Все");
    public final Setting onlyWeapon = new Setting("Только с оружием", false);

    // Сглаженная позиция цели
    private double tgtX, tgtY, tgtZ;
    private boolean hasTarget = false;

    // Сглаженные углы
    private float smoothYaw = 0f;
    private float smoothPitch = 0f;
    private float velocityYaw = 0f;
    private float velocityPitch = 0f;

    public Aimbot() {
        super("Aimbot", Category.Combat);
        addSetting(range);
        addSetting(smoothness);
        addSetting(target);
        addSetting(onlyWeapon);
    }

    @Override
    public void onEnable() {
        if (mc.player != null) {
            smoothYaw = mc.player.getYaw();
            smoothPitch = mc.player.getPitch();
        }
        velocityYaw = 0f;
        velocityPitch = 0f;
        hasTarget = false;
    }

    @Override
    public void onDisable() {
        hasTarget = false;
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) return;

        if (onlyWeapon.getBool()) {
            net.minecraft.item.ItemStack main = mc.player.getMainHandStack();
            boolean isWeapon = main.getItem() instanceof net.minecraft.item.SwordItem
                    || main.getItem() instanceof net.minecraft.item.AxeItem;
            if (!isWeapon) return;
        }

        LivingEntity t = findTarget();
        if (t == null) {
            hasTarget = false;
            // Затухание инерции
            velocityYaw *= 0.7f;
            velocityPitch *= 0.7f;
            return;
        }

        // Сглаживаем ПОЗИЦИЮ цели — она медленно едет к настоящей цели
        double realX = t.getX();
        double realY = t.getY() + t.getHeight() / 2;
        double realZ = t.getZ();

        if (!hasTarget) {
            tgtX = realX;
            tgtY = realY;
            tgtZ = realZ;
            hasTarget = true;
        } else {
            // Позиция цели тоже плавно движется
            double posSmooth = 0.4;
            tgtX += (realX - tgtX) * posSmooth;
            tgtY += (realY - tgtY) * posSmooth;
            tgtZ += (realZ - tgtZ) * posSmooth;
        }

        // Целевые углы по сглаженной позиции
        double dx = tgtX - mc.player.getX();
        double dy = tgtY - mc.player.getEyeY();
        double dz = tgtZ - mc.player.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);

        float targetYaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        float targetPitch = (float)-Math.toDegrees(Math.atan2(dy, dist));

        float speed = smoothness.getFloat();

        // Сглаженные углы идут к цели медленно
        smoothYaw = lerpAngle(smoothYaw, targetYaw, speed);
        smoothPitch = lerpAngle(smoothPitch, targetPitch, speed);

        // Игрок идёт к сглаженным углам — тоже медленно, с инерцией
        float playerYaw = mc.player.getYaw();
        float playerPitch = mc.player.getPitch();

        float dy1 = wrap(smoothYaw - playerYaw);
        float dp1 = smoothPitch - playerPitch;

        // Инерция — маленькое ускорение
        float accel = 0.4f;
        velocityYaw += (dy1 * speed * 0.5f - velocityYaw) * accel;
        velocityPitch += (dp1 * speed * 0.5f - velocityPitch) * accel;

        float newYaw = playerYaw + velocityYaw;
        float newPitch = playerPitch + velocityPitch;

        // Мёртвая зона — если движение меньше 0.2° не дёргаем
        if (Math.abs(velocityYaw) > 0.2f) mc.player.setYaw(newYaw);
        if (Math.abs(velocityPitch) > 0.2f) mc.player.setPitch(MathHelper.clamp(newPitch, -90f, 90f));
    }

    private float wrap(float deg) {
        deg = deg % 360f;
        if (deg >= 180f) deg -= 360f;
        if (deg < -180f) deg += 360f;
        return deg;
    }

    private float lerpAngle(float current, float target, float speed) {
        float delta = ((target - current + 540) % 360) - 180;
        return current + delta * speed;
    }

    private LivingEntity findTarget() {
        List<Entity> entities = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) entities.add(e);

        String t = target.getString();
        float r = range.getFloat();

        return entities.stream()
                .filter(e -> e instanceof LivingEntity)
                .map(e -> (LivingEntity) e)
                .filter(e -> e != mc.player)
                .filter(LivingEntity::isAlive)
                .filter(e -> mc.player.distanceTo(e) <= r)
                .filter(e -> {
                    if (t.equals("Игроки")) return e instanceof PlayerEntity;
                    if (t.equals("Мобы")) return e instanceof MobEntity;
                    return e instanceof PlayerEntity || e instanceof MobEntity;
                })
                .min(Comparator.comparingDouble(e -> mc.player.distanceTo(e)))
                .orElse(null);
    }
}
