package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Aimbot extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting range = new Setting("Дистанция", 5.0f, 2.0f, 10.0f, 0.5f);
    public final Setting smoothness = new Setting("Плавность", 0.10f, 0.02f, 1.0f, 0.01f);
    public final Setting target = new Setting("Цель", "Игроки", "Игроки", "Мобы", "Все");
    public final Setting onlyWeapon = new Setting("Только с оружием", false);

    private double tgtX, tgtY, tgtZ;
    private boolean hasTarget = false;

    public Aimbot() {
        super("Aimbot", Category.Combat);
        addSetting(range);
        addSetting(smoothness);
        addSetting(target);
        addSetting(onlyWeapon);
    }

    @Override
    public void onEnable() { hasTarget = false; }
    @Override
    public void onDisable() { hasTarget = false; }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) return;

        if (onlyWeapon.getBool()) {
            net.minecraft.item.ItemStack main = mc.player.getMainHandStack();
            boolean isWeapon = main.getItem() instanceof net.minecraft.item.SwordItem
                    || main.getItem() instanceof net.minecraft.item.AxeItem;
            if (!isWeapon) return;
        }

        LivingEntity t = findTarget();
        if (t == null) { hasTarget = false; return; }

        // Сглаживаем позицию цели
        double rx = t.getX();
        double ry = t.getY() + t.getHeight() / 2;
        double rz = t.getZ();

        if (!hasTarget) {
            tgtX = rx; tgtY = ry; tgtZ = rz;
            hasTarget = true;
        } else {
            double ps = 0.5;
            tgtX += (rx - tgtX) * ps;
            tgtY += (ry - tgtY) * ps;
            tgtZ += (rz - tgtZ) * ps;
        }

        // Целевые углы
        double dx = tgtX - mc.player.getX();
        double dy = tgtY - mc.player.getEyeY();
        double dz = tgtZ - mc.player.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);

        float targetYaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        float targetPitch = (float)-Math.toDegrees(Math.atan2(dy, dist));

        // Простое плавное сглаживание без мёртвой зоны и без инерции
        float speed = smoothness.getFloat() * 0.12f; // чтобы 1.0 было очень плавно

        float newYaw = lerpAngle(mc.player.getYaw(), targetYaw, speed);
        float newPitch = lerpAngle(mc.player.getPitch(), targetPitch, speed);

        mc.player.setYaw(newYaw);
        mc.player.setPitch(MathHelper.clamp(newPitch, -90f, 90f));
    }

    private float lerpAngle(float current, float target, float speed) {
        float delta = ((target - current + 540) % 360) - 180;
        return current + delta * speed;
    }

    private LivingEntity findTarget() {
        List<Entity> entities = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) entities.add(e);

        String t = target.getString();
        float r = range.getFloat();

        return entities.stream()
                .filter(e -> e instanceof LivingEntity)
                .map(e -> (LivingEntity) e)
                .filter(e -> e != mc.player)
                .filter(LivingEntity::isAlive)
                .filter(e -> mc.player.distanceTo(e) <= r)
                .filter(e -> {
                    if (t.equals("Игроки")) return e instanceof PlayerEntity;
                    if (t.equals("Мобы")) return e instanceof MobEntity;
                    return e instanceof PlayerEntity || e instanceof MobEntity;
                })
                .min(Comparator.comparingDouble(e -> mc.player.distanceTo(e)))
                .orElse(null);
    }
}
