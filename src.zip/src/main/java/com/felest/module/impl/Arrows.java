package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;

import java.awt.Color;

public class Arrows extends Module {

    public final Setting radius = new Setting("Радиус", 80f, 40f, 250f, 5f);
    public final Setting size = new Setting("Размер", 1.5f, 0.8f, 3.0f, 0.1f);
    public final Setting style = new Setting("Стиль", "Стрела", "Стрела", "Указатель", "Точка");
    public final Setting color = new Setting("Цвет", "Фиолетовый",
            "Фиолетовый", "Синий", "Зелёный", "Красный", "Серый", "Жёлтый", "Оранжевый", "Белый");
    public final Setting showDistance = new Setting("Показывать дистанцию", true);

    public Arrows() {
        super("Arrows", Category.Misc);
        addSetting(radius);
        addSetting(size);
        addSetting(style);
        addSetting(color);
        addSetting(showDistance);
    }

    public int getColor() {
        switch (color.getString()) {
            case "Фиолетовый": return new Color(160, 60, 220, 255).getRGB();
            case "Синий":      return new Color(60, 120, 220, 255).getRGB();
            case "Зелёный":    return new Color(60, 200, 100, 255).getRGB();
            case "Красный":    return new Color(220, 60, 60, 255).getRGB();
            case "Серый":      return new Color(150, 150, 160, 255).getRGB();
            case "Жёлтый":     return new Color(230, 210, 60, 255).getRGB();
            case "Оранжевый":  return new Color(240, 140, 40, 255).getRGB();
            case "Белый":      return new Color(240, 240, 240, 255).getRGB();
            default:           return new Color(160, 60, 220, 255).getRGB();
        }
    }

    @Override
    public void onUpdate() {}
}
