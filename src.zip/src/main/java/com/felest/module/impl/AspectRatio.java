package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;

public class AspectRatio extends Module {

    // 1.0 = ванильный, < 1.0 = сжимает по горизонтали (видно больше),
    // > 1.0 = растягивает (видно больше по вертикали)
    public final Setting ratio = new Setting("Соотношение", 1.0f, 0.5f, 2.0f, 0.05f);

    public AspectRatio() {
        super("AspectRatio", Category.Render);
        addSetting(ratio);
    }

    @Override
    public void onUpdate() {}
}
