package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoSwap extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting item1 = new Setting("Предмет 1", "Сфера", "Сфера", "Талисман");
    public final Setting item2 = new Setting("Предмет 2", "Талисман", "Сфера", "Талисман");

    public int swapKey = -1;

    public AutoSwap() {
        super("AutoSwap", Category.Combat);
        addSetting(item1);
        addSetting(item2);
    }

    @Override
    public void onUpdate() {}

    public void doSwap() {
        if (mc.player == null || mc.interactionManager == null) return;

        PlayerInventory inv = mc.player.getInventory();
        ItemStack offHand = inv.getStack(40);

        String type1 = item1.getString();
        String type2 = item2.getString();

        String targetType;
        if (matches(offHand, type1)) {
            targetType = type2;
        } else if (matches(offHand, type2)) {
            targetType = type1;
        } else {
            targetType = type1;
        }

        int foundSlot = findItem(inv, targetType);
        if (foundSlot == -1) return;

        int containerSlot;
        if (foundSlot < 9) containerSlot = foundSlot + 36;
        else containerSlot = foundSlot;

        mc.interactionManager.clickSlot(
                mc.player.playerScreenHandler.syncId,
                45,
                containerSlot,
                SlotActionType.SWAP,
                mc.player
        );
    }

    private int findItem(PlayerInventory inv, String type) {
        if (type.equals("Сфера")) {
            for (int i = 0; i < 36; i++) {
                if (inv.getStack(i).getItem() == Items.PLAYER_HEAD) return i;
            }
        } else if (type.equals("Талисман")) {
            // Сначала зачарованный тотем
            for (int i = 0; i < 36; i++) {
                ItemStack s = inv.getStack(i);
                if (s.getItem() == Items.TOTEM_OF_UNDYING && s.hasEnchantments()) return i;
            }
            // Потом обычный
            for (int i = 0; i < 36; i++) {
                if (inv.getStack(i).getItem() == Items.TOTEM_OF_UNDYING) return i;
            }
        }
        return -1;
    }

    private boolean matches(ItemStack stack, String type) {
        if (stack == null || stack.isEmpty()) return false;
        if (type.equals("Сфера")) return stack.getItem() == Items.PLAYER_HEAD;
        if (type.equals("Талисман")) return stack.getItem() == Items.TOTEM_OF_UNDYING;
        return false;
    }
}
