package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.screen.slot.SlotActionType;

import java.util.LinkedList;
import java.util.Queue;

public class AutoSwap extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting item1 = new Setting("Предмет 1", "Сфера", "Сфера", "Талисман");
    public final Setting item2 = new Setting("Предмет 2", "Талисман", "Сфера", "Талисман");

    public int swapKey = -1;
    private int freezeTicks = 0;
    private boolean wasSprinting = false;
    private final Queue<Runnable> swapQueue = new LinkedList<>();
    private int stepCooldown = 0;

    public AutoSwap() {
        super("AutoSwap", Category.Combat);
        addSetting(item1);
        addSetting(item2);
    }

    @Override
    public void onUpdate() {
        if (freezeTicks > 0) {
            if (mc.player != null) mc.player.setVelocity(0, mc.player.getVelocity().y, 0);
            freezeTicks--;
            if (freezeTicks == 0 && wasSprinting && mc.player != null) {
                mc.player.setSprinting(true);
                mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(
                        mc.player, ClientCommandC2SPacket.Mode.START_SPRINTING));
                wasSprinting = false;
            }
        }

        if (!swapQueue.isEmpty()) {
            if (stepCooldown > 0) { stepCooldown--; return; }
            swapQueue.poll().run();
            stepCooldown = 2; // 2 тика между шагами
        }
    }

    public void doSwap() {
        if (mc.player == null || mc.interactionManager == null) return;
        if (!swapQueue.isEmpty()) return;

        PlayerInventory inv = mc.player.getInventory();
        ItemStack offHand = inv.getStack(40);

        String type1 = item1.getString();
        String type2 = item2.getString();

        String targetType;
        if (matches(offHand, type1)) targetType = type2;
        else if (matches(offHand, type2)) targetType = type1;
        else targetType = type1;

        // Ищем target в хотбаре (0-8)
        int hotbarSlot = -1;
        for (int i = 0; i < 9; i++) {
            if (matches(inv.getStack(i), targetType)) { hotbarSlot = i; break; }
        }

        // Если нет в хотбаре — ищем в инвентаре (9-35)
        int invSlot = -1;
        if (hotbarSlot == -1) {
            for (int i = 9; i < 36; i++) {
                if (matches(inv.getStack(i), targetType)) { invSlot = i; break; }
            }
        }

        if (hotbarSlot == -1 && invSlot == -1) return;

        // Заморозка
        if (mc.player.isSprinting()) {
            wasSprinting = true;
            mc.player.setSprinting(false);
            mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(
                    mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
        }
        mc.player.setVelocity(0, mc.player.getVelocity().y, 0);
        freezeTicks = 4;

        int syncId = mc.player.playerScreenHandler.syncId;
        int offHandSlotId = 45;

        swapQueue.clear();

        if (hotbarSlot != -1) {
            // Свопаем через SWAP: оффхенд (45) ↔ хотбар (button = hotbarSlot)
            swapQueue.add(() -> mc.interactionManager.clickSlot(
                    syncId, offHandSlotId, hotbarSlot, SlotActionType.SWAP, mc.player));
        } else {
            // Через инвентарь: 3 шага PICKUP
            final int targetSlotId = invSlot;
            swapQueue.add(() -> mc.interactionManager.clickSlot(
                    syncId, targetSlotId, 0, SlotActionType.PICKUP, mc.player));
            swapQueue.add(() -> mc.interactionManager.clickSlot(
                    syncId, offHandSlotId, 0, SlotActionType.PICKUP, mc.player));
            swapQueue.add(() -> mc.interactionManager.clickSlot(
                    syncId, targetSlotId, 0, SlotActionType.PICKUP, mc.player));
        }
    }

    private boolean matches(ItemStack stack, String type) {
        if (stack == null || stack.isEmpty()) return false;
        if (type.equals("Сфера")) return stack.getItem() == Items.PLAYER_HEAD;
        if (type.equals("Талисман")) return stack.getItem() == Items.TOTEM_OF_UNDYING;
        return false;
    }
}
