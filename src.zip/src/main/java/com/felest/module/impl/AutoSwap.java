package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.screen.slot.SlotActionType;

import java.util.LinkedList;
import java.util.Queue;

public class AutoSwap extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting item1 = new Setting("Предмет 1", "Сфера", "Сфера", "Талисман");
    public final Setting item2 = new Setting("Предмет 2", "Талисман", "Сфера", "Талисман");

    public int swapKey = -1;
    private int freezeTicks = 0;
    private boolean wasSprinting = false;

    // Очередь шагов свапа: каждый элемент — [slotId, mode] (0 = pickup, 1 = quickmove)
    private final Queue<int[]> swapQueue = new LinkedList<>();
    private int stepCooldown = 0;

    public AutoSwap() {
        super("AutoSwap", Category.Combat);
        addSetting(item1);
        addSetting(item2);
    }

    @Override
    public void onUpdate() {
        if (freezeTicks > 0) {
            if (mc.player != null) mc.player.setVelocity(0, mc.player.getVelocity().y, 0);
            freezeTicks--;
            if (freezeTicks == 0 && wasSprinting && mc.player != null) {
                mc.player.setSprinting(true);
                mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(
                        mc.player, ClientCommandC2SPacket.Mode.START_SPRINTING));
                wasSprinting = false;
            }
        }

        // Обрабатываем очередь свапа по одному шагу за раз, с задержкой
        if (!swapQueue.isEmpty()) {
            if (stepCooldown > 0) {
                stepCooldown--;
                return;
            }
            int[] step = swapQueue.poll();
            int slotId = step[0];
            int syncId = mc.player.playerScreenHandler.syncId;
            mc.interactionManager.clickSlot(syncId, slotId, 0, SlotActionType.PICKUP, mc.player);
            stepCooldown = 1; // 1 тик между шагами
        }
    }

    public void doSwap() {
        if (mc.player == null || mc.interactionManager == null) return;
        if (!swapQueue.isEmpty()) return; // уже свапаем

        PlayerInventory inv = mc.player.getInventory();
        ItemStack offHand = inv.getStack(40);

        String type1 = item1.getString();
        String type2 = item2.getString();

        String targetType;
        if (matches(offHand, type1)) targetType = type2;
        else if (matches(offHand, type2)) targetType = type1;
        else targetType = type1;

        int foundSlot = findItem(inv, targetType);
        if (foundSlot == -1) return;

        // Заморозка + спринт
        if (mc.player.isSprinting()) {
            wasSprinting = true;
            mc.player.setSprinting(false);
            mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(
                    mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
        }
        mc.player.setVelocity(0, mc.player.getVelocity().y, 0);
        freezeTicks = 3;

        int targetSlotId = foundSlot < 9 ? foundSlot + 36 : foundSlot;
        int offHandSlotId = 45;

        // Очередь: 3 шага через тики
        swapQueue.clear();
        swapQueue.add(new int[]{targetSlotId});  // 1. взять Сферу в курсор
        swapQueue.add(new int[]{offHandSlotId}); // 2. положить в оффхенд, Талисман → курсор
        swapQueue.add(new int[]{targetSlotId});  // 3. вернуть Талисман обратно в слот
        stepCooldown = 0;
    }

    private int findItem(PlayerInventory inv, String type) {
        if (type.equals("Сфера")) {
            for (int i = 0; i < 36; i++) {
                if (inv.getStack(i).getItem() == Items.PLAYER_HEAD) return i;
            }
        } else if (type.equals("Талисман")) {
            for (int i = 0; i < 36; i++) {
                ItemStack s = inv.getStack(i);
                if (s.getItem() == Items.TOTEM_OF_UNDYING && s.hasEnchantments()) return i;
            }
            for (int i = 0; i < 36; i++) {
                if (inv.getStack(i).getItem() == Items.TOTEM_OF_UNDYING) return i;
            }
        }
        return -1;
    }

    private boolean matches(ItemStack stack, String type) {
        if (stack == null || stack.isEmpty()) return false;
        if (type.equals("Сфера")) return stack.getItem() == Items.PLAYER_HEAD;
        if (type.equals("Талисман")) return stack.getItem() == Items.TOTEM_OF_UNDYING;
        return false;
    }
}
