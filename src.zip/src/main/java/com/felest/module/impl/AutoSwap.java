package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoSwap extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting slot1 = new Setting("Слот 1", "Талисман", "Сфера", "Талисман");
    public final Setting slot2 = new Setting("Слот 2", "Сфера", "Сфера", "Талисман");

    public int swapKey = -1;

    public AutoSwap() {
        super("AutoSwap", Category.Combat);
        addSetting(slot1);
        addSetting(slot2);
    }

    @Override
    public void onUpdate() {}

    public void doSwap() {
        if (mc.player == null || mc.interactionManager == null) return;

        PlayerInventory inv = mc.player.getInventory();

        // Проверяем Слот 1 в левой руке
        ItemStack offHand = inv.getStack(40);
        if (!matches(offHand, slot1.getString())) return;

        // Ищем Слот 2 в инвентаре
        int foundSlot = -1;
        String type2 = slot2.getString();

        if (type2.equals("Сфера")) {
            for (int i = 0; i < 36; i++) {
                if (inv.getStack(i).getItem() == Items.PLAYER_HEAD) {
                    foundSlot = i;
                    break;
                }
            }
        } else if (type2.equals("Талисман")) {
            // Сначала зачарованный тотем
            for (int i = 0; i < 36; i++) {
                ItemStack s = inv.getStack(i);
                if (s.getItem() == Items.TOTEM_OF_UNDYING && s.hasEnchantments()) {
                    foundSlot = i;
                    break;
                }
            }
            // Если нет — обычный тотем
            if (foundSlot == -1) {
                for (int i = 0; i < 36; i++) {
                    if (inv.getStack(i).getItem() == Items.TOTEM_OF_UNDYING) {
                        foundSlot = i;
                        break;
                    }
                }
            }
        }

        if (foundSlot == -1) return;

        // Слот 40 (оффхенд) в playerScreenHandler = 45
        // Слоты 0-8 инвентаря = 36-44, слоты 9-35 = 9-35
        int containerSlot;
        if (foundSlot < 9) containerSlot = foundSlot + 36;
        else containerSlot = foundSlot;

        // SWAP: меняем местами оффхенд (45) и найденный слот
        mc.interactionManager.clickSlot(
                mc.player.playerScreenHandler.syncId,
                45,
                containerSlot,
                SlotActionType.SWAP,
                mc.player
        );
    }

    private boolean matches(ItemStack stack, String type) {
        if (stack == null || stack.isEmpty()) return false;
        if (type.equals("Сфера")) return stack.getItem() == Items.PLAYER_HEAD;
        if (type.equals("Талисман")) {
            return stack.getItem() == Items.TOTEM_OF_UNDYING;
        }
        return false;
    }
}
