package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.screen.slot.SlotActionType;

public class AutoSwap extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting item1 = new Setting("Предмет 1", "Сфера", "Сфера", "Талисман");
    public final Setting item2 = new Setting("Предмет 2", "Талисман", "Сфера", "Талисман");

    public int swapKey = -1;
    private int freezeTicks = 0;
    private boolean wasSprinting = false;

    public AutoSwap() {
        super("AutoSwap", Category.Combat);
        addSetting(item1);
        addSetting(item2);
    }

    @Override
    public void onUpdate() {
        // Заморозка игрока после свапа
        if (freezeTicks > 0) {
            if (mc.player != null) {
                mc.player.setVelocity(0, mc.player.getVelocity().y, 0);
            }
            freezeTicks--;
            if (freezeTicks == 0 && wasSprinting && mc.player != null) {
                mc.player.setSprinting(true);
                mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(
                        mc.player, ClientCommandC2SPacket.Mode.START_SPRINTING));
                wasSprinting = false;
            }
        }
    }

    public void doSwap() {
        if (mc.player == null || mc.interactionManager == null) return;

        PlayerInventory inv = mc.player.getInventory();
        ItemStack offHand = inv.getStack(40);

        String type1 = item1.getString();
        String type2 = item2.getString();

        String targetType;
        if (matches(offHand, type1)) targetType = type2;
        else if (matches(offHand, type2)) targetType = type1;
        else targetType = type1;

        int foundSlot = findItem(inv, targetType);
        if (foundSlot == -1) return;

        // ===== ЗАМОРОЗКА =====
        if (mc.player.isSprinting()) {
            wasSprinting = true;
            mc.player.setSprinting(false);
            mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(
                    mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
        }
        mc.player.setVelocity(0, mc.player.getVelocity().y, 0);
        freezeTicks = 2;

        // ===== СВАП =====
        int syncId = mc.player.playerScreenHandler.syncId;

        // Слот оффхенда в screenHandler = 45
        int offHandSlotId = 45;

        // Конвертация инвентарного слота в slotId screenHandler:
        // 0-8 (хотбар) → 36-44
        // 9-35 (инвентарь) → 9-35
        int targetSlotId;
        if (foundSlot < 9) targetSlotId = foundSlot + 36;
        else targetSlotId = foundSlot;

        // 1. Берём предмет из целевого слота в курсор
        mc.interactionManager.clickSlot(syncId, targetSlotId, 0, SlotActionType.PICKUP, mc.player);
        // 2. Кладём в оффхенд (курсор → оффхенд), старый предмет уходит в курсор
        mc.interactionManager.clickSlot(syncId, offHandSlotId, 0, SlotActionType.PICKUP, mc.player);
        // 3. Возвращаем старый предмет из курсора в целевой слот
        mc.interactionManager.clickSlot(syncId, targetSlotId, 0, SlotActionType.PICKUP, mc.player);

        // Если что-то осталось в курсоре — кидаем в пустой слот
        if (!mc.player.currentScreenHandler.getCursorStack().isEmpty()) {
            mc.interactionManager.clickSlot(syncId, -999, 0, SlotActionType.PICKUP, mc.player);
        }
    }

    private int findItem(PlayerInventory inv, String type) {
        if (type.equals("Сфера")) {
            for (int i = 0; i < 36; i++) {
                if (inv.getStack(i).getItem() == Items.PLAYER_HEAD) return i;
            }
        } else if (type.equals("Талисман")) {
            for (int i = 0; i < 36; i++) {
                ItemStack s = inv.getStack(i);
                if (s.getItem() == Items.TOTEM_OF_UNDYING && s.hasEnchantments()) return i;
            }
            for (int i = 0; i < 36; i++) {
                if (inv.getStack(i).getItem() == Items.TOTEM_OF_UNDYING) return i;
            }
        }
        return -1;
    }

    private boolean matches(ItemStack stack, String type) {
        if (stack == null || stack.isEmpty()) return false;
        if (type.equals("Сфера")) return stack.getItem() == Items.PLAYER_HEAD;
        if (type.equals("Талисман")) return stack.getItem() == Items.TOTEM_OF_UNDYING;
        return false;
    }
}
