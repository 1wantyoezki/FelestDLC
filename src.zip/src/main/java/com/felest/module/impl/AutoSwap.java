package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoSwap extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting item1 = new Setting("Предмет 1", "Сфера", "Сфера", "Талисман");
    public final Setting item2 = new Setting("Предмет 2", "Талисман", "Сфера", "Талисман");

    public int swapKey = -1;
    private int returnSlot = -1;

    public AutoSwap() {
        super("AutoSwap", Category.Combat);
        addSetting(item1);
        addSetting(item2);
    }

    @Override
    public void onUpdate() {}

    public void doSwap() {
        if (mc.player == null || mc.interactionManager == null) return;

        PlayerInventory inv = mc.player.getInventory();
        ItemStack off = inv.getStack(40);

        String type1 = item1.getString();
        String type2 = item2.getString();

        int screenSlot;

        if (matches(off, type1)) {
            int slot = findItem(inv, type2);
            if (slot == -1) return;
            screenSlot = toScreenSlot(slot);
            swap(screenSlot);
            returnSlot = screenSlot;
        } else if (matches(off, type2)) {
            if (returnSlot != -1 && matchesStackAtScreen(inv, returnSlot, type1)) {
                swap(returnSlot);
                returnSlot = -1;
            } else {
                int slot = findItem(inv, type1);
                if (slot == -1) return;
                screenSlot = toScreenSlot(slot);
                swap(screenSlot);
                returnSlot = -1;
            }
        } else {
            int slot = findItem(inv, type1);
            if (slot == -1) return;
            screenSlot = toScreenSlot(slot);
            swap(screenSlot);
            returnSlot = -1;
        }
    }

    private void swap(int screenSlot) {
        mc.interactionManager.clickSlot(
                mc.player.playerScreenHandler.syncId,
                screenSlot,
                40,
                SlotActionType.SWAP,
                mc.player
        );
    }

    private int toScreenSlot(int playerInvSlot) {
        if (playerInvSlot < 9) return playerInvSlot + 36;
        return playerInvSlot;
    }

    private boolean matchesStackAtScreen(PlayerInventory inv, int screenSlot, String type) {
        int playerSlot = screenSlot >= 36 ? screenSlot - 36 : screenSlot;
        if (playerSlot < 0 || playerSlot >= 36) return false;
        return matches(inv.getStack(playerSlot), type);
    }

    private int findItem(PlayerInventory inv, String type) {
        for (int i = 0; i < 36; i++) {
            if (matches(inv.getStack(i), type)) return i;
        }
        return -1;
    }

    private boolean matches(ItemStack stack, String type) {
        if (stack == null || stack.isEmpty()) return false;
        if (type.equals("Сфера")) return stack.getItem() == Items.PLAYER_HEAD;
        if (type.equals("Талисман")) return stack.getItem() == Items.TOTEM_OF_UNDYING;
        return false;
    }
}
