package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoSwap extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting item1 = new Setting("Предмет 1", "Сфера", "Сфера", "Талисман");
    public final Setting item2 = new Setting("Предмет 2", "Талисман", "Сфера", "Талисман");

    public int swapKey = -1;

    // Запоминаем предмет, который был в руке (для возврата)
    private ItemStack returnStack = ItemStack.EMPTY;
    private int returnSlot = -1;

    public AutoSwap() {
        super("AutoSwap", Category.Combat);
        addSetting(item1);
        addSetting(item2);
    }

    @Override
    public void onUpdate() {}

    public void doSwap() {
        if (mc.player == null || mc.interactionManager == null) return;

        PlayerInventory inv = mc.player.getInventory();
        ItemStack off = inv.getStack(40);

        String type1 = item1.getString();
        String type2 = item2.getString();

        if (matches(off, type1)) {
            // В руке Предмет 1 → свапаем на Предмет 2
            int slot = findClosest(inv, type2);
            if (slot == -1) return;

            // Запоминаем ТОЧНЫЙ предмет, который сейчас в руке
            returnStack = off.copy();

            int screenSlot = toScreenSlot(slot);
            swap(screenSlot);
            returnSlot = screenSlot; // сюда прилетел Предмет 1

        } else if (matches(off, type2)) {
            // В руке Предмет 2 → возвращаем Предмет 1
            // Сначала проверяем сохранённый слот — там должен лежать ТОТ ЖЕ предмет
            if (returnSlot != -1 && !returnStack.isEmpty()) {
                int playerSlot = screenToPlayer(returnSlot);
                if (playerSlot >= 0 && playerSlot < 36) {
                    ItemStack s = inv.getStack(playerSlot);
                    if (!s.isEmpty() && ItemStack.areEqual(s, returnStack)) {
                        swap(returnSlot);
                        returnSlot = -1;
                        returnStack = ItemStack.EMPTY;
                        return;
                    }
                }
            }
            // Если того предмета нет — берём любой ближайший Предмет 1
            int slot = findClosest(inv, type1);
            if (slot == -1) return;
            swap(toScreenSlot(slot));
            returnSlot = -1;
            returnStack = ItemStack.EMPTY;

        } else {
            // В руке пусто / не наш предмет → берём Предмет 1
            int slot = findClosest(inv, type1);
            if (slot == -1) return;
            swap(toScreenSlot(slot));
            returnSlot = -1;
            returnStack = ItemStack.EMPTY;
        }
    }

    // F-механика: SWAP с button = 40 = поменять слот с оффхендом
    private void swap(int screenSlot) {
        mc.interactionManager.clickSlot(
                mc.player.playerScreenHandler.syncId,
                screenSlot,
                40,
                SlotActionType.SWAP,
                mc.player
        );
    }

    private int toScreenSlot(int playerInvSlot) {
        if (playerInvSlot < 9) return playerInvSlot + 36;
        return playerInvSlot;
    }

    private int screenToPlayer(int screenSlot) {
        if (screenSlot >= 36 && screenSlot <= 44) return screenSlot - 36;
        if (screenSlot >= 9 && screenSlot <= 35) return screenSlot;
        return -1;
    }

    // Ищем ближайший: сначала хотбар (0-8), потом инвентарь (9-35)
    private int findClosest(PlayerInventory inv, String type) {
        for (int i = 0; i < 9; i++) {
            if (matches(inv.getStack(i), type)) return i;
        }
        for (int i = 9; i < 36; i++) {
            if (matches(inv.getStack(i), type)) return i;
        }
        return -1;
    }

    private boolean matches(ItemStack stack, String type) {
        if (stack == null || stack.isEmpty()) return false;
        if (type.equals("Сфера")) return stack.getItem() == Items.PLAYER_HEAD;
        if (type.equals("Талисман")) return stack.getItem() == Items.TOTEM_OF_UNDYING;
        return false;
    }
}
