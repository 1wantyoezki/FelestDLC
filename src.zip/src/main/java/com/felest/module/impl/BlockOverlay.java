package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;

import java.awt.Color;

public class BlockOverlay extends Module {

    public final Setting mode = new Setting("Режим", "Канон", "Канон", "Шейдер");
    public final Setting color = new Setting("Цвет", "Фиолетовый",
            "Фиолетовый", "Синий", "Зелёный", "Красный", "Серый", "Жёлтый", "Оранжевый", "Белый");
    public final Setting fill = new Setting("Заливка сквозь блоки", false);
    public final Setting thickness = new Setting("Толщина", 2f, 1f, 5f, 0.5f);

    public BlockOverlay() {
        super("BlockOverlay", Category.Render);
        addSetting(mode);
        addSetting(color);
        addSetting(fill);
        addSetting(thickness);
    }

    public int getColor() {
        switch (color.getString()) {
            case "Фиолетовый": return new Color(160, 60, 220, 255).getRGB();
            case "Синий":      return new Color(60, 120, 220, 255).getRGB();
            case "Зелёный":    return new Color(60, 200, 100, 255).getRGB();
            case "Красный":    return new Color(220, 60, 60, 255).getRGB();
            case "Серый":      return new Color(150, 150, 160, 255).getRGB();
            case "Жёлтый":     return new Color(230, 210, 60, 255).getRGB();
            case "Оранжевый":  return new Color(240, 140, 40, 255).getRGB();
            case "Белый":      return new Color(240, 240, 240, 255).getRGB();
            default:           return new Color(160, 60, 220, 255).getRGB();
        }
    }

    @Override
    public void onUpdate() {}
}
