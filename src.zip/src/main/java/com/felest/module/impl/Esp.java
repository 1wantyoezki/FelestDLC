package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.awt.Color;

public class Esp extends Module {

    public final Setting target = new Setting("Цель", "Игроки", "Игроки", "Мобы", "Все");
    public final Setting color = new Setting("Цвет", "Фиолетовый",
            "Фиолетовый", "Синий", "Зелёный", "Красный", "Серый", "Жёлтый", "Оранжевый", "Белый");

    public Esp() {
        super("ESP", Category.Render);
        addSetting(target);
        addSetting(color);
    }

    public boolean shouldRender(Entity e) {
        if (!(e instanceof LivingEntity)) return false;
        if (!e.isAlive()) return false;
        String t = target.getString();
        if (t.equals("Игроки")) return e instanceof PlayerEntity;
        if (t.equals("Мобы")) return e instanceof MobEntity;
        return e instanceof PlayerEntity || e instanceof MobEntity;
    }

    public int getColor() {
        switch (color.getString()) {
            case "Фиолетовый": return new Color(160, 60, 220, 255).getRGB();
            case "Синий":      return new Color(60, 120, 220, 255).getRGB();
            case "Зелёный":    return new Color(60, 200, 100, 255).getRGB();
            case "Красный":    return new Color(220, 60, 60, 255).getRGB();
            case "Серый":      return new Color(150, 150, 160, 255).getRGB();
            case "Жёлтый":     return new Color(230, 210, 60, 255).getRGB();
            case "Оранжевый":  return new Color(240, 140, 40, 255).getRGB();
            case "Белый":      return new Color(240, 240, 240, 255).getRGB();
            default:           return new Color(160, 60, 220, 255).getRGB();
        }
    }

    @Override
    public void onUpdate() {}
}
