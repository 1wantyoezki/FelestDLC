package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.util.math.Vec3d;

public class FreeCam extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting speed = new Setting("Скорость", 1.0f, 0.2f, 5.0f, 0.1f);

    private Vec3d cameraPos = Vec3d.ZERO;
    private float cameraYaw = 0f;
    private float cameraPitch = 0f;

    public FreeCam() {
        super("FreeCam", Category.Render);
        addSetting(speed);
    }

    @Override
    public void onEnable() {
        if (mc.player == null) return;
        cameraPos = mc.player.getPos().add(0, mc.player.getStandingEyeHeight(), 0);
        cameraYaw = mc.player.getYaw();
        cameraPitch = mc.player.getPitch();
    }

    @Override
    public void onDisable() {
        cameraPos = Vec3d.ZERO;
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) return;

        // Управление камерой через WASD
        GameOptions opt = mc.options;
        float yawRad = (float) Math.toRadians(cameraYaw);
        float pitchRad = (float) Math.toRadians(cameraPitch);

        double forward = 0;
        double strafe = 0;
        double up = 0;

        if (opt.forwardKey.isPressed()) forward += 1;
        if (opt.backKey.isPressed()) forward -= 1;
        if (opt.leftKey.isPressed()) strafe -= 1;
        if (opt.rightKey.isPressed()) strafe += 1;
        if (opt.jumpKey.isPressed()) up += 1;
        if (opt.sneakKey.isPressed()) up -= 1;

        double sp = speed.getFloat() * 0.5;

        // Движение по направлению взгляда камеры
        double dx = (-Math.sin(yawRad) * Math.cos(pitchRad)) * forward + (Math.cos(yawRad)) * strafe;
        double dy = (-Math.sin(pitchRad)) * forward + up;
        double dz = (Math.cos(yawRad) * Math.cos(pitchRad)) * forward + (Math.sin(yawRad)) * strafe;

        cameraPos = cameraPos.add(dx * sp, dy * sp, dz * sp);
    }

    public Vec3d getCameraPos() { return cameraPos; }
    public float getCameraYaw() { return cameraYaw; }
    public float getCameraPitch() { return cameraPitch; }
}
