package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

public class Fullbright extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public Fullbright() {
        super("Fullbright", Category.Render);
    }

    @Override
    public void onEnable() {
        applyEffect();
    }

    @Override
    public void onUpdate() {
        if (mc.player == null) return;
        // Обновляем эффект каждый тик, чтобы он не пропадал
        StatusEffectInstance current = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (current == null || current.getDuration() < 400) {
            applyEffect();
        }
    }

    @Override
    public void onDisable() {
        if (mc.player != null) {
            mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }

    private void applyEffect() {
        if (mc.player == null) return;
        // 999999 секунд = ~11 дней, хватит на всё
        mc.player.addStatusEffect(new StatusEffectInstance(
                StatusEffects.NIGHT_VISION,
                999999,
                0,
                false,
                false,
                false
        ));
    }
}
