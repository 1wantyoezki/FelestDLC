package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;

public class Fullbright extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting brightness = new Setting("Яркость", 10.0f, 1.0f, 10.0f, 0.5f);

    private double oldGamma = 1.0;

    public Fullbright() {
        super("Fullbright", Category.Render);
        addSetting(brightness);
    }

    @Override
    public void onEnable() {
        if (mc.options != null) {
            oldGamma = mc.options.getGamma().getValue();
        }
    }

    @Override
    public void onUpdate() {
        if (mc.options == null) return;
        mc.options.getGamma().setValue((double) brightness.getFloat());
    }

    @Override
    public void onDisable() {
        if (mc.options != null) {
            mc.options.getGamma().setValue(oldGamma);
        }
    }
}
