package com.felest.module.impl;

import com.felest.FelestDLC;
import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import com.felest.util.RenderUtil;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ProfileComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;

import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Hud extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting color = new Setting("Цвет", "Фиолетовый",
            "Фиолетовый", "Синий", "Зелёный", "Красный", "Серый", "Жёлтый", "Оранжевый", "Белый");
    public final Setting scale = new Setting("Размер", 1.0f, 0.6f, 1.6f, 0.05f);

    public final Setting watermark = new Setting("Info", true);
    public final Setting keybinds = new Setting("Hotkeys", true);
    public final Setting potions = new Setting("Potions", true);
    public final Setting cooldowns = new Setting("Cooldowns", true);
    public final Setting targetHud = new Setting("TargetHUD", true);

    public float watermarkX = 10, watermarkY = 10;
    public float keybindsX = 10, keybindsY = 60;
    public float potionsX = 10, potionsY = 160;
    public float cooldownsX = 10, cooldownsY = 250;
    public float targetX = 400, targetY = 280;

    private float watermarkAnim = 0f, keybindsAnim = 0f, potionsAnim = 0f, cooldownsAnim = 0f, targetAnim = 0f;

    private LivingEntity lastTarget = null;
    private long lastTargetTime = 0L;
    private final long TARGET_HIDE_MS = 4000L;

    public boolean editorMode = false;

    public Hud() {
        super("HUD", Category.Render);
        addSetting(color);
        addSetting(scale);
        addSetting(watermark);
        addSetting(keybinds);
        addSetting(potions);
        addSetting(cooldowns);
        addSetting(targetHud);
    }

    public int getAccentColor() {
        switch (color.getString()) {
            case "Фиолетовый": return new Color(160, 60, 220).getRGB();
            case "Синий":      return new Color(60, 120, 220).getRGB();
            case "Зелёный":    return new Color(60, 200, 100).getRGB();
            case "Красный":    return new Color(220, 60, 60).getRGB();
            case "Серый":      return new Color(150, 150, 160).getRGB();
            case "Жёлтый":     return new Color(230, 210, 60).getRGB();
            case "Оранжевый":  return new Color(240, 140, 40).getRGB();
            case "Белый":      return new Color(240, 240, 240).getRGB();
            default:           return new Color(160, 60, 220).getRGB();
        }
    }

    @Override
    public void onUpdate() {
        watermarkAnim = anim(watermarkAnim, watermark.getBool() ? 1f : 0f);
        keybindsAnim  = anim(keybindsAnim,  keybinds.getBool()  ? 1f : 0f);
        potionsAnim   = anim(potionsAnim,   potions.getBool()   ? 1f : 0f);
        cooldownsAnim = anim(cooldownsAnim, cooldowns.getBool() ? 1f : 0f);
        targetAnim    = anim(targetAnim,    targetHud.getBool() ? 1f : 0f);
    }

    private float anim(float current, float target) {
        if (current < target) return Math.min(target, current + 0.1f);
        if (current > target) return Math.max(target, current - 0.1f);
        return current;
    }

    // Тёмный фон как в Nursultan
    private int bgColor() { return new Color(12, 12, 18, 200).getRGB(); }
    private int textColor() { return 0xFFFFFFFF; }
    private int textDim() { return new Color(150, 150, 165).getRGB(); }

    public void render(DrawContext context) {
        if (mc.player == null) return;

        int accent = getAccentColor();

        float sc = scale.getFloat();
        context.getMatrices().push();
        context.getMatrices().scale(sc, sc, 1f);

        if (watermarkAnim > 0.01f) renderInfo(context, accent, watermarkAnim);
        if (keybindsAnim > 0.01f)  renderHotkeys(context, accent, keybindsAnim);
        if (potionsAnim > 0.01f)   renderPotions(context, accent, potionsAnim);
        if (cooldownsAnim > 0.01f) renderCooldowns(context, accent, cooldownsAnim);
        if (targetAnim > 0.01f)    renderTarget(context, accent, targetAnim);

        context.getMatrices().pop();
    }

    // ==================== INFO PANEL ====================
    private void renderInfo(DrawContext context, int accent, float a) {
        int x = (int) watermarkX;
        int y = (int) (watermarkY - (1f - a) * 15);

        String time = new SimpleDateFormat("HH:mm:ss").format(new Date());
        int fps = mc.getCurrentFps();
        int ping = 0;
        try {
            if (mc.getNetworkHandler() != null && mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()) != null) {
                ping = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()).getLatency();
            }
        } catch (Exception ignored) {}

        // Line 1: [F] FelestDLC | time | FPS
        String l1r = time + "  §f" + fps + " FPS";
        int w1 = 24 + mc.textRenderer.getWidth("FelestDLC") + 10 + mc.textRenderer.getWidth(l1r) + 16;

        RenderUtil.roundedRect(context, x, y, w1, 16, 5, bgColor());
        // Логотип F
        RenderUtil.roundedRect(context, x + 4, y + 3, 10, 10, 2, accent);
        context.drawTextWithShadow(mc.textRenderer, "F", x + 7, y + 4, 0xFFFFFFFF);
        context.drawTextWithShadow(mc.textRenderer, "FelestDLC", x + 18, y + 4, textColor());
        int r1w = mc.textRenderer.getWidth(l1r);
        context.drawTextWithShadow(mc.textRenderer, l1r, x + w1 - r1w - 8, y + 4, textDim());

        // Line 2: coords | ping | TPS | BPS
        String coords = (int)mc.player.getX() + " " + (int)mc.player.getY() + " " + (int)mc.player.getZ();
        double bps = 0;
        double dx = mc.player.getX() - mc.player.prevX;
        double dz = mc.player.getZ() - mc.player.prevZ;
        bps = Math.sqrt(dx * dx + dz * dz) * 20;

        String l2 = coords + "  §7|  §f" + ping + "ms  §7|  §f" + String.format("%.1f", 20.0) + " TPS  §7|  §f" + String.format("%.1f", bps) + " BPS";
        int w2 = mc.textRenderer.getWidth(l2) + 16;
        int w = Math.max(w1, w2);

        // Расширяем верхнюю если вторая шире
        if (w2 > w1) {
            // Стираем и перерисовываем
            RenderUtil.roundedRect(context, x, y, w, 16, 5, bgColor());
            RenderUtil.roundedRect(context, x + 4, y + 3, 10, 10, 2, accent);
            context.drawTextWithShadow(mc.textRenderer, "F", x + 7, y + 4, 0xFFFFFFFF);
            context.drawTextWithShadow(mc.textRenderer, "FelestDLC", x + 18, y + 4, textColor());
            context.drawTextWithShadow(mc.textRenderer, l1r, x + w - r1w - 8, y + 4, textDim());
        }

        RenderUtil.roundedRect(context, x, y + 18, w, 16, 5, bgColor());
        context.drawTextWithShadow(mc.textRenderer, l2, x + 8, y + 22, textColor());

        if (editorMode) context.drawBorder(x - 2, y - 2, w + 4, 36 + 4, 0xFF8800FF);
    }

    // ==================== HOTKEYS ====================
    private void renderHotkeys(DrawContext context, int accent, float a) {
        int x = (int) keybindsX;
        int y = (int) (keybindsY - (1f - a) * 15);

        List<Module> enabled = new ArrayList<>();
        for (Module m : FelestDLC.moduleManager.getModules()) {
            if (m.isEnabled() && !m.getName().equals("HUD")) enabled.add(m);
        }

        int rowH = 14;
        int h = 22 + Math.max(1, enabled.size()) * rowH;
        int w = 120;

        RenderUtil.roundedRect(context, x, y, w, h, 6, bgColor());
        // Заголовок
        context.drawTextWithShadow(mc.textRenderer, "Hotkeys", x + 8, y + 6, accent);
        // Разделитель
        context.fill(x + 8, y + 20, x + w - 8, y + 21, RenderUtil.withAlpha(accent, 100));

        int ry = y + 24;
        if (enabled.isEmpty()) {
            context.drawTextWithShadow(mc.textRenderer, "—", x + 8, ry, textDim());
        } else {
            for (Module m : enabled) {
                context.drawTextWithShadow(mc.textRenderer, m.getName(), x + 8, ry, textColor());
                if (m.getKeyBind() != -1) {
                    String key = org.lwjgl.glfw.GLFW.glfwGetKeyName(m.getKeyBind(), 0);
                    if (key == null) key = "?";
                    key = key.toUpperCase();
                    int kw = mc.textRenderer.getWidth(key);
                    context.drawTextWithShadow(mc.textRenderer, key, x + w - 8 - kw, ry, accent);
                }
                ry += rowH;
            }
        }

        if (editorMode) context.drawBorder(x - 2, y - 2, w + 4, h + 4, 0xFF8800FF);
    }

    // ==================== POTIONS ====================
    private void renderPotions(DrawContext context, int accent, float a) {
        if (mc.player.getStatusEffects().isEmpty()) return;

        int x = (int) potionsX;
        int y = (int) (potionsY - (1f - a) * 15);

        int rowH = 14;
        int h = 22 + mc.player.getStatusEffects().size() * rowH;
        int w = 130;

        RenderUtil.roundedRect(context, x, y, w, h, 6, bgColor());
        context.drawTextWithShadow(mc.textRenderer, "Active potions", x + 8, y + 6, accent);
        context.fill(x + 8, y + 20, x + w - 8, y + 21, RenderUtil.withAlpha(accent, 100));

        int ry = y + 24;
        for (StatusEffectInstance e : mc.player.getStatusEffects()) {
            String name = e.getEffectType().value().getName().getString();
            int sec = e.getDuration() / 20;
            String time = (sec / 60) + ":" + String.format("%02d", sec % 60);

            // Убираем лишнее из name (например "Зелье скорости" -> "Скорость")
            if (name.contains(" ")) {
                String[] parts = name.split(" ");
                if (parts.length > 1) name = parts[parts.length - 1];
            }

            context.drawTextWithShadow(mc.textRenderer, name, x + 8, ry, textColor());
            int tw = mc.textRenderer.getWidth(time);
            context.drawTextWithShadow(mc.textRenderer, time, x + w - 8 - tw, ry, accent);
            ry += rowH;
        }

        if (editorMode) context.drawBorder(x - 2, y - 2, w + 4, h + 4, 0xFF8800FF);
    }

    // ==================== COOLDOWNS ====================
    private void renderCooldowns(DrawContext context, int accent, float a) {
        int x = (int) cooldownsX;
        int y = (int) (cooldownsY - (1f - a) * 15);

        List<String[]> lines = new ArrayList<>();
        for (int i = 0; i < 36; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (s.isEmpty()) continue;
            if (mc.player.getItemCooldownManager().isCoolingDown(s)) {
                float prog = mc.player.getItemCooldownManager().getCooldownProgress(s, 0f);
                float rem = (1f - prog) * 10f;
                lines.add(new String[]{ s.getName().getString(), String.format("%.1fs", rem) });
            }
        }
        if (lines.isEmpty()) return;

        int rowH = 14;
        int h = 22 + lines.size() * rowH;
        int w = 130;

        RenderUtil.roundedRect(context, x, y, w, h, 6, bgColor());
        context.drawTextWithShadow(mc.textRenderer, "Cooldowns", x + 8, y + 6, accent);
        context.fill(x + 8, y + 20, x + w - 8, y + 21, RenderUtil.withAlpha(accent, 100));

        int ry = y + 24;
        for (String[] it : lines) {
            context.drawTextWithShadow(mc.textRenderer, it[0], x + 8, ry, textColor());
            int tw = mc.textRenderer.getWidth(it[1]);
            context.drawTextWithShadow(mc.textRenderer, it[1], x + w - 8 - tw, ry, accent);
            ry += rowH;
        }

        if (editorMode) context.drawBorder(x - 2, y - 2, w + 4, h + 4, 0xFF8800FF);
    }

    // ==================== TARGET HUD ====================
    private void renderTarget(DrawContext context, int accent, float a) {
        LivingEntity target = null;
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            Entity e = ((EntityHitResult) mc.crosshairTarget).getEntity();
            if (e instanceof LivingEntity && e != mc.player) target = (LivingEntity) e;
        }
        if (target == null) {
            if (lastTarget != null && System.currentTimeMillis() - lastTargetTime < TARGET_HIDE_MS) target = lastTarget;
            else { lastTarget = null; return; }
        } else {
            lastTarget = target;
            lastTargetTime = System.currentTimeMillis();
        }

        int tx = (int) targetX;
        int ty = (int) (targetY + (1f - a) * 15);

        String name = target.getName().getString();
        float hp = target.getHealth();
        float maxHp = target.getMaxHealth();
        float absorb = target.getAbsorptionAmount();
        float pct = MathHelper.clamp(hp / maxHp, 0f, 1f);
        float absorbPct = MathHelper.clamp(absorb / maxHp, 0f, 1f);

        int w = 150;
        int h = 40;

        RenderUtil.roundedRect(context, tx, ty, w, h, 6, bgColor());

        // Голова
        ItemStack head = getHeadStack(target);
        if (!head.isEmpty()) {
            context.drawItem(head, tx + 6, ty + 12);
        }

        // Ник
        context.drawTextWithShadow(mc.textRenderer, name, tx + 30, ty + 6, textColor());

        // HP-бар
        int barX = tx + 30;
        int barY = ty + 22;
        int barW = w - 40;
        int barH = 5;

        RenderUtil.roundedRect(context, barX, barY, barW, barH, 2, new Color(40, 40, 50).getRGB());

        int filled = (int)(barW * pct);
        int hpColor = pct > 0.5f ? new Color(60, 200, 60).getRGB()
                : pct > 0.25f ? new Color(230, 200, 60).getRGB()
                : new Color(220, 60, 60).getRGB();
        if (filled > 0) RenderUtil.roundedRect(context, barX, barY, filled, barH, 2, hpColor);

        // Absorption — жёлтая
        if (absorb > 0) {
            int af = (int)(barW * absorbPct);
            RenderUtil.roundedRect(context, barX, barY, af, barH, 2, new Color(240, 210, 60).getRGB());
        }

        // Цифры HP
        String hpText = (int)hp + (absorb > 0 ? " (+" + (int)absorb + ")" : "") + " / " + (int)maxHp;
        context.drawTextWithShadow(mc.textRenderer, hpText, barX, barY + 8, textDim());

        if (editorMode) context.drawBorder(tx - 2, ty - 2, w + 4, h + 4, 0xFF8800FF);
    }

    private ItemStack getHeadStack(LivingEntity target) {
        if (target instanceof PlayerEntity) {
            ItemStack head = new ItemStack(Items.PLAYER_HEAD);
            GameProfile profile = ((PlayerEntity) target).getGameProfile();
            head.set(DataComponentTypes.PROFILE, new ProfileComponent(profile));
            return head;
        }
        try {
            var egg = net.minecraft.item.SpawnEggItem.forEntity(target.getType());
            if (egg != null) return new ItemStack(egg);
        } catch (Exception ignored) {}
        return ItemStack.EMPTY;
    }
}
