package com.felest.module.impl;

import com.felest.FelestDLC;
import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;

import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Hud extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting color = new Setting("Цвет", "Фиолетовый",
            "Фиолетовый", "Синий", "Зелёный", "Красный", "Серый", "Жёлтый", "Оранжевый");
    public final Setting scale = new Setting("Размер", 1.0f, 0.5f, 2.0f, 0.05f);

    public final Setting watermark = new Setting("Watermark", true);
    public final Setting keybinds = new Setting("Keybinds", true);
    public final Setting schedules = new Setting("Schedules", true);
    public final Setting potions = new Setting("Potions", true);
    public final Setting targetHud = new Setting("TargetHUD", true);
    public final Setting bpsTps = new Setting("BPS/TPS", false);

    // Позиции
    public float watermarkX = 10, watermarkY = 10;
    public float keybindsX = 400, keybindsY = 10;
    public float schedulesX = 10, schedulesY = 40;
    public float targetX = 400, targetY = 250;
    public float bpsX = 10, bpsY = 400;

    // Анимация появления (per-element)
    private float watermarkAnim = 0f;
    private float keybindsAnim = 0f;
    private float schedulesAnim = 0f;
    private float targetAnim = 0f;

    private LivingEntity lastTarget = null;
    private long lastTargetTime = 0L;
    private final long TARGET_HIDE_MS = 4000L;

    public boolean editorMode = false;

    public Hud() {
        super("HUD", Category.Render);
        addSetting(color);
        addSetting(scale);
        addSetting(watermark);
        addSetting(keybinds);
        addSetting(schedules);
        addSetting(potions);
        addSetting(targetHud);
        addSetting(bpsTps);
    }

    public int getAccentColor() {
        switch (color.getString()) {
            case "Фиолетовый": return new Color(160, 60, 220).getRGB();
            case "Синий":      return new Color(60, 120, 220).getRGB();
            case "Зелёный":    return new Color(60, 200, 100).getRGB();
            case "Красный":    return new Color(220, 60, 60).getRGB();
            case "Серый":      return new Color(150, 150, 160).getRGB();
            case "Жёлтый":     return new Color(230, 210, 60).getRGB();
            case "Оранжевый":  return new Color(240, 140, 40).getRGB();
            default:           return new Color(160, 60, 220).getRGB();
        }
    }

    @Override
    public void onUpdate() {
        // Анимации появления
        watermarkAnim = anim(watermarkAnim, watermark.getBool() ? 1f : 0f);
        keybindsAnim  = anim(keybindsAnim,  keybinds.getBool()  ? 1f : 0f);
        schedulesAnim = anim(schedulesAnim, schedules.getBool() ? 1f : 0f);
        targetAnim    = anim(targetAnim,    targetHud.getBool() ? 1f : 0f);
    }

    private float anim(float current, float target) {
        if (current < target) return Math.min(target, current + 0.08f);
        if (current > target) return Math.max(target, current - 0.08f);
        return current;
    }

    public void render(DrawContext context) {
        if (mc.player == null) return;

        int accent = getAccentColor();
        int bg = new Color(15, 15, 20, 190).getRGB();
        int text = Color.WHITE.getRGB();

        float sc = scale.getFloat();
        context.getMatrices().push();
        context.getMatrices().scale(sc, sc, 1f);

        // ===== WATERMARK =====
        if (watermarkAnim > 0.01f) {
            int x = (int) watermarkX;
            int y = (int) (watermarkY - (1f - watermarkAnim) * 20);
            String s = "FELESTDLC | UID: " + mc.player.getUuidAsString().substring(0, 4) + " | " + new SimpleDateFormat("HH:mm:ss").format(new Date());
            int w = mc.textRenderer.getWidth(s) + 12;
            glowRect(context, x, y, w, 16, 4, bg, accent);
            context.fill(x, y, x + 3, y + 16, accent);
            context.drawTextWithShadow(mc.textRenderer, s, x + 7, y + 4, text);
            if (editorMode) context.drawBorder(x - 1, y - 1, w + 2, 18, 0xFF8800FF);
        }

        // ===== KEYBINDS =====
        if (keybindsAnim > 0.01f) {
            int x = (int) keybindsX;
            int y = (int) (keybindsY - (1f - keybindsAnim) * 20);
            String title = "Keybinds";
            int titleW = mc.textRenderer.getWidth(title) + 12;
            int rowH = 14;

            List<Module> enabled = new ArrayList<>();
            for (Module m : FelestDLC.moduleManager.getModules()) {
                if (m.isEnabled() && m.getKeyBind() != -1 && !m.getName().equals("HUD")) {
                    enabled.add(m);
                }
            }

            int h = 18 + enabled.size() * rowH;
            glowRect(context, x, y, 130, h, 4, bg, accent);
            context.fill(x, y, x + 3, y + h, accent);
            context.drawTextWithShadow(mc.textRenderer, title, x + 7, y + 4, text);

            int ry = y + 18;
            for (Module m : enabled) {
                String keyName = org.lwjgl.glfw.GLFW.glfwGetKeyName(m.getKeyBind(), 0);
                if (keyName == null) keyName = "?";
                keyName = keyName.toUpperCase();
                context.drawTextWithShadow(mc.textRenderer, m.getName(), x + 7, ry, text);
                int kw = mc.textRenderer.getWidth(m.getName());
                context.drawTextWithShadow(mc.textRenderer, "[" + keyName + "]", x + 7 + kw + 4, ry, accent);
                ry += rowH;
            }
            if (editorMode) context.drawBorder(x - 1, y - 1, 132, h + 2, 0xFF8800FF);
        }

        // ===== SCHEDULES =====
        if (schedulesAnim > 0.01f) {
            int x = (int) schedulesX;
            int y = (int) (schedulesY - (1f - schedulesAnim) * 20);
            String title = "Schedules";
            String[][] items = {
                    {"Тайный торговец", "5м 14с"},
                    {"Состояние", "3м 14с"},
                    {"Аир дроп", "3м 14с"},
                    {"Талисман", "3м 21с"},
                    {"Скруж", "23ч 21м"}
            };
            int h = 18 + items.length * 14;
            glowRect(context, x, y, 150, h, 4, bg, accent);
            context.fill(x, y, x + 3, y + h, accent);
            context.drawTextWithShadow(mc.textRenderer, title, x + 7, y + 4, text);

            int ry = y + 18;
            for (String[] it : items) {
                context.drawTextWithShadow(mc.textRenderer, it[0], x + 7, ry, text);
                int w1 = mc.textRenderer.getWidth(it[0]);
                context.drawTextWithShadow(mc.textRenderer, it[1], x + 7 + w1 + 6, ry, accent);
                ry += 14;
            }
            if (editorMode) context.drawBorder(x - 1, y - 1, 152, h + 2, 0xFF8800FF);
        }

        // ===== POTIONS (не двигается) =====
        if (potions.getBool() && !mc.player.getStatusEffects().isEmpty()) {
            int x = 10;
            int y = mc.getWindow().getScaledHeight() / 2;
            for (StatusEffectInstance e : mc.player.getStatusEffects()) {
                String name = e.getEffectType().value().getName().getString();
                int sec = e.getDuration() / 20;
                String txt = name + " " + (sec / 60) + ":" + String.format("%02d", sec % 60);
                int w = mc.textRenderer.getWidth(txt) + 24;
                glowRect(context, x, y, w, 16, 4, bg, accent);
                context.fill(x, y, x + 3, y + 16, accent);
                // Иконка эффекта
                context.drawTextWithShadow(mc.textRenderer, txt, x + 20, y + 4, text);
                y += 20;
            }
        }

        // ===== BPS/TPS =====
        if (bpsTps.getBool()) {
            int x = (int) bpsX;
            int y = (int) bpsY;
            double dx = mc.player.getX() - mc.player.prevX;
            double dz = mc.player.getZ() - mc.player.prevZ;
            double bps = Math.sqrt(dx * dx + dz * dz) * 20;
            String txt = String.format("BPS: %.2f | TPS: 20.0", bps);
            int w = mc.textRenderer.getWidth(txt) + 12;
            glowRect(context, x, y, w, 16, 4, bg, accent);
            context.fill(x, y, x + 3, y + 16, accent);
            context.drawTextWithShadow(mc.textRenderer, txt, x + 7, y + 4, text);
        }

        // ===== TARGET HUD =====
        if (targetAnim > 0.01f) {
            renderTarget(context, bg, accent, targetAnim);
        }

        context.getMatrices().pop();
    }

    private void renderTarget(DrawContext context, int bg, int accent, float anim) {
        LivingEntity target = null;
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            Entity e = ((EntityHitResult) mc.crosshairTarget).getEntity();
            if (e instanceof LivingEntity && e != mc.player) target = (LivingEntity) e;
        }
        if (target == null) {
            if (lastTarget != null && System.currentTimeMillis() - lastTargetTime < TARGET_HIDE_MS) target = lastTarget;
            else { lastTarget = null; return; }
        } else {
            lastTarget = target;
            lastTargetTime = System.currentTimeMillis();
        }

        int tx = (int) targetX;
        int ty = (int) (targetY + (1f - anim) * 20);

        String name = target.getName().getString();
        float hp = target.getHealth();
        float maxHp = target.getMaxHealth();
        float pct = MathHelper.clamp(hp / maxHp, 0f, 1f);

        int w = 140, h = 40;
        glowRect(context, tx, ty, w, h, 5, bg, accent);
        context.fill(tx, ty, tx + 3, ty + h, accent);

        context.drawTextWithShadow(mc.textRenderer, name, tx + 8, ty + 6, Color.WHITE.getRGB());

        // HP бар
        int barX = tx + 8, barY = ty + 22, barW = w - 16, barH = 8;
        context.fill(barX, barY, barX + barW, barY + barH, new Color(40, 40, 50).getRGB());
        int filled = (int)(barW * pct);
        int hpColor = pct > 0.5f ? new Color(60, 200, 60).getRGB()
                : pct > 0.25f ? new Color(230, 200, 60).getRGB()
                : new Color(220, 60, 60).getRGB();
        context.fill(barX, barY, barX + filled, barY + barH, hpColor);
        context.drawTextWithShadow(mc.textRenderer, (int)hp + " / " + (int)maxHp, barX, barY + 10, Color.WHITE.getRGB());

        if (editorMode) context.drawBorder(tx - 1, ty - 1, w + 2, h + 2, 0xFF8800FF);
    }

    // Закруглённый прямоугольник с glow-обводкой
    private void glowRect(DrawContext context, int x, int y, int w, int h, int r, int bg, int accent) {
        // Glow — тонкий слой по краям (чуть прозрачный accent)
        int glow = (accent & 0x00FFFFFF) | 0x40000000;
        roundedRect(context, x - 1, y - 1, w + 2, h + 2, r + 1, glow);
        // Основной фон
        roundedRect(context, x, y, w, h, r, bg);
    }

    private void roundedRect(DrawContext context, int x, int y, int w, int h, int r, int color) {
        context.fill(x + r, y, x + w - r, y + h, color);
        context.fill(x, y + r, x + r, y + h - r, color);
        context.fill(x + w - r, y + r, x + w, y + h - r, color);
        context.fill(x + r, y + h - r, x + w - r, y + h, color);
        for (int i = 0; i < r; i++) {
            int dx = (int) Math.sqrt(r * r - (r - i) * (r - i));
            int xStart = x + r - dx;
            int xEnd = x + w - r + dx;
            context.fill(xStart, y + i, x + r, y + i + 1, color);
            context.fill(x + w - r, y + i, xEnd, y + i + 1, color);
            context.fill(xStart, y + h - i - 1, x + r, y + h - i, color);
            context.fill(x + w - r, y + h - i - 1, xEnd, y + h - i, color);
        }
    }
}
