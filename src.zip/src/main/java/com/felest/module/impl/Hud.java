package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;

import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Hud extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting color = new Setting("Цвет", "Фиолетовый",
            "Фиолетовый", "Синий", "Зелёный", "Красный", "Серый", "Жёлтый", "Оранжевый");
    public final Setting watermark = new Setting("Watermark", true);
    public final Setting cooldowns = new Setting("Cooldowns", true);
    public final Setting potions = new Setting("Potions", true);
    public final Setting targetHud = new Setting("TargetHUD", true);
    public final Setting bpsTps = new Setting("BPS/TPS", true);
    public final Setting schedules = new Setting("Schedules", true);

    public final Setting hudX = new Setting("HUD X", 10f, 0f, 1000f, 1f);
    public final Setting hudY = new Setting("HUD Y", 10f, 0f, 1000f, 1f);
    public final Setting targetX = new Setting("Target X", 400f, 0f, 1000f, 1f);
    public final Setting targetY = new Setting("Target Y", 200f, 0f, 1000f, 1f);

    private LivingEntity lastTarget = null;
    private long lastTargetTime = 0L;
    private final long TARGET_HIDE_MS = 4000L;

    public Hud() {
        super("HUD", Category.Render);
        addSetting(color);
        addSetting(watermark);
        addSetting(cooldowns);
        addSetting(potions);
        addSetting(targetHud);
        addSetting(bpsTps);
        addSetting(schedules);
        addSetting(hudX);
        addSetting(hudY);
        addSetting(targetX);
        addSetting(targetY);
    }

    public int getAccentColor() {
        switch (color.getString()) {
            case "Фиолетовый": return new Color(160, 60, 220).getRGB();
            case "Синий":      return new Color(60, 120, 220).getRGB();
            case "Зелёный":    return new Color(60, 200, 100).getRGB();
            case "Красный":    return new Color(220, 60, 60).getRGB();
            case "Серый":      return new Color(150, 150, 160).getRGB();
            case "Жёлтый":     return new Color(230, 210, 60).getRGB();
            case "Оранжевый":  return new Color(240, 140, 40).getRGB();
            default:           return new Color(160, 60, 220).getRGB();
        }
    }

    @Override
    public void onUpdate() {}

    public void render(DrawContext context) {
        if (mc.player == null) return;

        int accent = getAccentColor();
        int bg = new Color(15, 15, 20, 180).getRGB();
        int text = Color.WHITE.getRGB();

        int x = (int) hudX.getFloat();
        int y = (int) hudY.getFloat();

        if (watermark.getBool()) {
            String s = "FelestDLC | " + new SimpleDateFormat("HH:mm:ss").format(new Date());
            int w = mc.textRenderer.getWidth(s) + 12;
            roundedRect(context, x, y, w, 16, 4, bg);
            context.fill(x, y, x + 3, y + 16, accent);
            context.drawTextWithShadow(mc.textRenderer, s, x + 7, y + 4, text);
            y += 20;
        }

        if (cooldowns.getBool()) {
            int w = 140;
            int h = 16;
            roundedRect(context, x, y, w, h, 4, bg);
            context.fill(x, y, x + 3, y + h, accent);
            context.drawTextWithShadow(mc.textRenderer, "Cooldowns", x + 7, y + 4, text);
            ItemStack main = mc.player.getMainHandStack();
            ItemStack off = mc.player.getOffHandStack();
            if (mc.player.getItemCooldownManager().isCoolingDown(main)) {
                float cd = mc.player.getItemCooldownManager().getCooldownProgress(main, 0f);
                context.drawTextWithShadow(mc.textRenderer, "  " + main.getName().getString() + ": " + (int)(cd * 100) + "%", x + 7, y + 14, text);
                y += 12;
            }
            if (mc.player.getItemCooldownManager().isCoolingDown(off)) {
                float cd = mc.player.getItemCooldownManager().getCooldownProgress(off, 0f);
                context.drawTextWithShadow(mc.textRenderer, "  " + off.getName().getString() + ": " + (int)(cd * 100) + "%", x + 7, y + 14, text);
                y += 12;
            }
            y += 20;
        }

        if (potions.getBool() && !mc.player.getStatusEffects().isEmpty()) {
            for (StatusEffectInstance e : mc.player.getStatusEffects()) {
                String name = e.getEffectType().value().getName().getString();
                int sec = e.getDuration() / 20;
                String txt = name + " " + (sec / 60) + ":" + String.format("%02d", sec % 60);
                int w = mc.textRenderer.getWidth(txt) + 12;
                roundedRect(context, x, y, w, 14, 4, bg);
                context.fill(x, y, x + 3, y + 14, accent);
                context.drawTextWithShadow(mc.textRenderer, txt, x + 7, y + 3, text);
                y += 18;
            }
        }

        if (bpsTps.getBool()) {
            int bpsY = mc.getWindow().getScaledHeight() - 60;
            double dx = mc.player.getX() - mc.player.prevX;
            double dz = mc.player.getZ() - mc.player.prevZ;
            double bps = Math.sqrt(dx * dx + dz * dz) * 20;
            String txt = String.format("BPS: %.2f", bps);
            int w = mc.textRenderer.getWidth(txt) + 12;
            roundedRect(context, x, bpsY, w, 14, 4, bg);
            context.fill(x, bpsY, x + 3, bpsY + 14, accent);
            context.drawTextWithShadow(mc.textRenderer, txt, x + 7, bpsY + 3, text);

            String tps = "TPS: 20.0";
            int w2 = mc.textRenderer.getWidth(tps) + 12;
            roundedRect(context, x, bpsY + 18, w2, 14, 4, bg);
            context.fill(x, bpsY + 18, x + 3, bpsY + 32, accent);
            context.drawTextWithShadow(mc.textRenderer, tps, x + 7, bpsY + 21, text);
        }

        if (targetHud.getBool()) {
            renderTargetHud(context, accent, bg);
        }
    }

    private void renderTargetHud(DrawContext context, int accent, int bg) {
        LivingEntity target = null;
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            Entity e = ((EntityHitResult) mc.crosshairTarget).getEntity();
            if (e instanceof LivingEntity && e != mc.player) target = (LivingEntity) e;
        }
        if (target == null) {
            if (lastTarget != null && System.currentTimeMillis() - lastTargetTime < TARGET_HIDE_MS) {
                target = lastTarget;
            } else {
                lastTarget = null;
                return;
            }
        } else {
            lastTarget = target;
            lastTargetTime = System.currentTimeMillis();
        }

        int tx = (int) targetX.getFloat();
        int ty = (int) targetY.getFloat();
        String name = target.getName().getString();
        float hp = target.getHealth();
        float maxHp = target.getMaxHealth();
        float pct = MathHelper.clamp(hp / maxHp, 0f, 1f);

        int w = 130;
        int h = 36;
        roundedRect(context, tx, ty, w, h, 6, bg);
        context.fill(tx, ty, tx + 3, ty + h, accent);
        context.drawTextWithShadow(mc.textRenderer, name, tx + 8, ty + 6, Color.WHITE.getRGB());

        int barX = tx + 8;
        int barY = ty + 22;
        int barW = w - 16;
        int barH = 8;
        context.fill(barX, barY, barX + barW, barY + barH, new Color(40, 40, 50).getRGB());
        int filled = (int)(barW * pct);
        int hpColor = pct > 0.5f ? new Color(60, 200, 60).getRGB() : pct > 0.25f ? new Color(230, 200, 60).getRGB() : new Color(220, 60, 60).getRGB();
        context.fill(barX, barY, barX + filled, barY + barH, hpColor);
        context.drawTextWithShadow(mc.textRenderer, (int)hp + " / " + (int)maxHp, tx + 8, ty + 22 + barH + 1, Color.WHITE.getRGB());
    }

    private void roundedRect(DrawContext context, int x, int y, int w, int h, int r, int color) {
        context.fill(x + r, y, x + w - r, y + h, color);
        context.fill(x, y + r, x + r, y + h - r, color);
        context.fill(x + w - r, y + r, x + w, y + h - r, color);
        context.fill(x + 1, y + 1, x + r, y + r, color);
        context.fill(x + w - r, y + 1, x + w - 1, y + r, color);
        context.fill(x + 1, y + h - r, x + r, y + h - 1, color);
        context.fill(x + w - r, y + h - r, x + w - 1, y + h - 1, color);
    }
}
