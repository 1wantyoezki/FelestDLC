package com.felest.module.impl;

import com.felest.FelestDLC;
import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ProfileComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;

import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Hud extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting color = new Setting("Цвет", "Фиолетовый",
            "Фиолетовый", "Синий", "Зелёный", "Красный", "Серый", "Жёлтый", "Оранжевый");
    public final Setting scale = new Setting("Размер", 1.0f, 0.5f, 2.0f, 0.05f);

    public final Setting watermark = new Setting("Watermark", true);
    public final Setting keybinds = new Setting("Keybinds", true);
    public final Setting cooldowns = new Setting("Cooldowns", true);
    public final Setting potions = new Setting("Potions", true);
    public final Setting targetHud = new Setting("TargetHUD", true);
    public final Setting bpsTps = new Setting("BPS/TPS", false);

    public float watermarkX = 10, watermarkY = 10;
    public float keybindsX = 500, keybindsY = 10;
    public float cooldownsX = 10, cooldownsY = 40;
    public float targetX = 450, targetY = 280;
    public float bpsX = 10, bpsY = 400;

    private float watermarkAnim = 0f;
    private float keybindsAnim = 0f;
    private float cooldownsAnim = 0f;
    private float targetAnim = 0f;

    private LivingEntity lastTarget = null;
    private long lastTargetTime = 0L;
    private final long TARGET_HIDE_MS = 4000L;

    public boolean editorMode = false;

    public Hud() {
        super("HUD", Category.Render);
        addSetting(color);
        addSetting(scale);
        addSetting(watermark);
        addSetting(keybinds);
        addSetting(cooldowns);
        addSetting(potions);
        addSetting(targetHud);
        addSetting(bpsTps);
    }

    public int getAccentColor() {
        switch (color.getString()) {
            case "Фиолетовый": return new Color(160, 60, 220).getRGB();
            case "Синий":      return new Color(60, 120, 220).getRGB();
            case "Зелёный":    return new Color(60, 200, 100).getRGB();
            case "Красный":    return new Color(220, 60, 60).getRGB();
            case "Серый":      return new Color(150, 150, 160).getRGB();
            case "Жёлтый":     return new Color(230, 210, 60).getRGB();
            case "Оранжевый":  return new Color(240, 140, 40).getRGB();
            default:           return new Color(160, 60, 220).getRGB();
        }
    }

    @Override
    public void onUpdate() {
        watermarkAnim = anim(watermarkAnim, watermark.getBool() ? 1f : 0f);
        keybindsAnim  = anim(keybindsAnim,  keybinds.getBool()  ? 1f : 0f);
        cooldownsAnim = anim(cooldownsAnim, cooldowns.getBool() ? 1f : 0f);
        targetAnim    = anim(targetAnim,    targetHud.getBool() ? 1f : 0f);
    }

    private float anim(float current, float target) {
        if (current < target) return Math.min(target, current + 0.08f);
        if (current > target) return Math.max(target, current - 0.08f);
        return current;
    }

    public void render(DrawContext context) {
        if (mc.player == null) return;

        int accent = getAccentColor();
        int bg = new Color(15, 15, 20, 190).getRGB();
        int text = Color.WHITE.getRGB();

        float sc = scale.getFloat();
        context.getMatrices().push();
        context.getMatrices().scale(sc, sc, 1f);

        // ===== WATERMARK =====
        if (watermarkAnim > 0.01f) {
            int x = (int) watermarkX;
            int y = (int) (watermarkY - (1f - watermarkAnim) * 20);
            String s = "FELESTDLC | UID: " + mc.player.getUuidAsString().substring(0, 4) + " | " + new SimpleDateFormat("HH:mm:ss").format(new Date());
            int w = mc.textRenderer.getWidth(s) + 16;
            glowRect(context, x, y, w, 18, 5, bg, accent);
            context.drawTextWithShadow(mc.textRenderer, s, x + 8, y + 5, text);
            if (editorMode) context.drawBorder(x - 2, y - 2, w + 4, 22, 0xFF8800FF);
        }

        // ===== KEYBINDS =====
        if (keybindsAnim > 0.01f) {
            int x = (int) keybindsX;
            int y = (int) (keybindsY - (1f - keybindsAnim) * 20);
            String title = "Keybinds";
            int rowH = 14;

            List<Module> enabled = new ArrayList<>();
            for (Module m : FelestDLC.moduleManager.getModules()) {
                if (m.isEnabled() && m.getKeyBind() != -1 && !m.getName().equals("HUD")) {
                    enabled.add(m);
                }
            }

            int h = 22 + Math.max(1, enabled.size()) * rowH;
            glowRect(context, x, y, 140, h, 5, bg, accent);
            context.drawTextWithShadow(mc.textRenderer, title, x + 8, y + 6, text);

            int ry = y + 22;
            if (enabled.isEmpty()) {
                context.drawTextWithShadow(mc.textRenderer, "Нет активных", x + 8, ry, new Color(140, 140, 150).getRGB());
            } else {
                for (Module m : enabled) {
                    String keyName = org.lwjgl.glfw.GLFW.glfwGetKeyName(m.getKeyBind(), 0);
                    if (keyName == null) keyName = "?";
                    keyName = keyName.toUpperCase();
                    context.drawTextWithShadow(mc.textRenderer, m.getName(), x + 8, ry, text);
                    int kw = mc.textRenderer.getWidth(m.getName());
                    context.drawTextWithShadow(mc.textRenderer, "[" + keyName + "]", x + 8 + kw + 4, ry, accent);
                    ry += rowH;
                }
            }
            if (editorMode) context.drawBorder(x - 2, y - 2, 144, h + 4, 0xFF8800FF);
        }

        // ===== COOLDOWNS =====
        if (cooldownsAnim > 0.01f) {
            int x = (int) cooldownsX;
            int y = (int) (cooldownsY - (1f - cooldownsAnim) * 20);
            String title = "Cooldowns";

            List<String[]> lines = new ArrayList<>();
            // Проходимся по всему инвентарю
            for (int i = 0; i < 36; i++) {
                ItemStack s = mc.player.getInventory().getStack(i);
                if (s.isEmpty()) continue;
                if (mc.player.getItemCooldownManager().isCoolingDown(s)) {
                    float prog = mc.player.getItemCooldownManager().getCooldownProgress(s, 0f);
                    float remainSec = (1f - prog) * 10f;
                    lines.add(new String[]{ s.getName().getString(), String.format("%.1fs", remainSec) });
                }
            }

            if (lines.isEmpty()) lines.add(new String[]{ "Нет активных", "—" });

            int h = 22 + lines.size() * 14;
            glowRect(context, x, y, 160, h, 5, bg, accent);
            context.drawTextWithShadow(mc.textRenderer, title, x + 8, y + 6, text);

            int ry = y + 22;
            for (String[] it : lines) {
                context.drawTextWithShadow(mc.textRenderer, it[0], x + 8, ry, text);
                int w1 = mc.textRenderer.getWidth(it[0]);
                context.drawTextWithShadow(mc.textRenderer, it[1], x + 8 + w1 + 6, ry, accent);
                ry += 14;
            }
            if (editorMode) context.drawBorder(x - 2, y - 2, 164, h + 4, 0xFF8800FF);
        }

        // ===== POTIONS (не двигается) =====
        if (potions.getBool() && !mc.player.getStatusEffects().isEmpty()) {
            int x = 10;
            int y = mc.getWindow().getScaledHeight() / 2;
            for (StatusEffectInstance e : mc.player.getStatusEffects()) {
                String name = e.getEffectType().value().getName().getString();
                int sec = e.getDuration() / 20;
                String txt = name + " " + (sec / 60) + ":" + String.format("%02d", sec % 60);
                int w = mc.textRenderer.getWidth(txt) + 24;
                glowRect(context, x, y, w, 16, 4, bg, accent);
                context.drawTextWithShadow(mc.textRenderer, txt, x + 20, y + 4, text);
                y += 20;
            }
        }

        // ===== BPS/TPS =====
        if (bpsTps.getBool()) {
            int x = (int) bpsX;
            int y = (int) bpsY;
            double dx = mc.player.getX() - mc.player.prevX;
            double dz = mc.player.getZ() - mc.player.prevZ;
            double bps = Math.sqrt(dx * dx + dz * dz) * 20;
            String txt = String.format("BPS: %.2f | TPS: 20.0", bps);
            int w = mc.textRenderer.getWidth(txt) + 16;
            glowRect(context, x, y, w, 18, 5, bg, accent);
            context.drawTextWithShadow(mc.textRenderer, txt, x + 8, y + 5, text);
        }

        // ===== TARGET HUD =====
        if (targetAnim > 0.01f) {
            renderTarget(context, bg, accent, targetAnim);
        }

        context.getMatrices().pop();
    }

    private void renderTarget(DrawContext context, int bg, int accent, float anim) {
        LivingEntity target = null;
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            Entity e = ((EntityHitResult) mc.crosshairTarget).getEntity();
            if (e instanceof LivingEntity && e != mc.player) target = (LivingEntity) e;
        }
        if (target == null) {
            if (lastTarget != null && System.currentTimeMillis() - lastTargetTime < TARGET_HIDE_MS) target = lastTarget;
            else { lastTarget = null; return; }
        } else {
            lastTarget = target;
            lastTargetTime = System.currentTimeMillis();
        }

        int tx = (int) targetX;
        int ty = (int) (targetY + (1f - anim) * 20);

        String name = target.getName().getString();
        float hp = target.getHealth();
        float maxHp = target.getMaxHealth();
        float absorb = target.getAbsorptionAmount();
        float pct = MathHelper.clamp(hp / maxHp, 0f, 1f);
        float absorbPct = MathHelper.clamp(absorb / maxHp, 0f, 1f);

        int w = 160;
        int h = 46;

        // glow вместо полосы слева
        glowRect(context, tx, ty, w, h, 6, bg, accent);

        // Голова игрока/моба
        ItemStack headStack = getHeadStack(target);
        if (!headStack.isEmpty()) {
            context.drawItem(headStack, tx + 6, ty + 14);
        }

        // Ник
        context.drawTextWithShadow(mc.textRenderer, name, tx + 30, ty + 8, Color.WHITE.getRGB());

        // HP-полоса (тонкая)
        int barX = tx + 30;
        int barY = ty + 25;
        int barW = w - 40;
        int barH = 6;

        context.fill(barX, barY, barX + barW, barY + barH, new Color(40, 40, 50).getRGB());

        // Красная (HP)
        int filled = (int)(barW * pct);
        int hpColor = pct > 0.5f ? new Color(60, 200, 60).getRGB()
                : pct > 0.25f ? new Color(230, 200, 60).getRGB()
                : new Color(220, 60, 60).getRGB();
        context.fill(barX, barY, barX + filled, barY + barH, hpColor);

        // Жёлтая (absorption) поверх
        if (absorb > 0) {
            int absorbFilled = (int)(barW * absorbPct);
            context.fill(barX, barY, barX + absorbFilled, barY + barH, new Color(240, 210, 60).getRGB());
        }

        // Цифры HP
        String hpText = (int)hp + (absorb > 0 ? " (+" + (int)absorb + ")" : "") + " / " + (int)maxHp;
        context.drawTextWithShadow(mc.textRenderer, hpText, barX, barY + barH + 2, Color.WHITE.getRGB());

        if (editorMode) context.drawBorder(tx - 2, ty - 2, w + 4, h + 4, 0xFF8800FF);
    }

    private ItemStack getHeadStack(LivingEntity target) {
        if (target instanceof PlayerEntity) {
            ItemStack head = new ItemStack(Items.PLAYER_HEAD);
            GameProfile profile = ((PlayerEntity) target).getGameProfile();
            head.set(DataComponentTypes.PROFILE, new ProfileComponent(profile));
            return head;
        }
        // Для мобов — попробуем спавн-эгг, если доступен
        try {
            var egg = net.minecraft.item.SpawnEggItem.forEntity(target.getType());
            if (egg != null) return new ItemStack(egg);
        } catch (Exception ignored) {}
        return ItemStack.EMPTY;
    }

    private void glowRect(DrawContext context, int x, int y, int w, int h, int r, int bg, int accent) {
        int glow = (accent & 0x00FFFFFF) | 0x40000000;
        roundedRect(context, x - 1, y - 1, w + 2, h + 2, r + 1, glow);
        roundedRect(context, x, y, w, h, r, bg);
    }

    private void roundedRect(DrawContext context, int x, int y, int w, int h, int r, int color) {
        context.fill(x + r, y, x + w - r, y + h, color);
        context.fill(x, y + r, x + r, y + h - r, color);
        context.fill(x + w - r, y + r, x + w, y + h - r, color);
        context.fill(x + r, y + h - r, x + w - r, y + h, color);
        for (int i = 0; i < r; i++) {
            int dx = (int) Math.sqrt(r * r - (r - i) * (r - i));
            int xStart = x + r - dx;
            int xEnd = x + w - r + dx;
            context.fill(xStart, y + i, x + r, y + i + 1, color);
            context.fill(x + w - r, y + i, xEnd, y + i + 1, color);
            context.fill(xStart, y + h - i - 1, x + r, y + h - i, color);
            context.fill(x + w - r, y + h - i - 1, xEnd, y + h - i, color);
        }
    }
}
