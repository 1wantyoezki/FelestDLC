package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;

import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Hud extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting color = new Setting("Цвет", "Фиолетовый",
            "Фиолетовый", "Синий", "Зелёный", "Красный", "Серый", "Жёлтый", "Оранжевый");
    public final Setting watermark = new Setting("Watermark", true);
    public final Setting cooldowns = new Setting("Cooldowns", true);
    public final Setting potions = new Setting("Potions", true);
    public final Setting targetHud = new Setting("TargetHUD", true);
    public final Setting bpsTps = new Setting("BPS/TPS", true);
    public final Setting schedules = new Setting("Schedules", true);

    // Позиции каждого элемента
    public float watermarkX = 10, watermarkY = 10;
    public float cooldownsX = 10, cooldownsY = 30;
    public float potionsX = 10, potionsY = 50;
    public float targetX = 400, targetY = 200;
    public float bpsX = 10, bpsY = 400;
    public float schedulesX = 10, schedulesY = 100;

    private LivingEntity lastTarget = null;
    private long lastTargetTime = 0L;
    private final long TARGET_HIDE_MS = 4000L;

    public boolean editorMode = false;

    public Hud() {
        super("HUD", Category.Render);
        addSetting(color);
        addSetting(watermark);
        addSetting(cooldowns);
        addSetting(potions);
        addSetting(targetHud);
        addSetting(bpsTps);
        addSetting(schedules);
    }

    public int getAccentColor() {
        switch (color.getString()) {
            case "Фиолетовый": return new Color(160, 60, 220).getRGB();
            case "Синий":      return new Color(60, 120, 220).getRGB();
            case "Зелёный":    return new Color(60, 200, 100).getRGB();
            case "Красный":    return new Color(220, 60, 60).getRGB();
            case "Серый":      return new Color(150, 150, 160).getRGB();
            case "Жёлтый":     return new Color(230, 210, 60).getRGB();
            case "Оранжевый":  return new Color(240, 140, 40).getRGB();
            default:           return new Color(160, 60, 220).getRGB();
        }
    }

    @Override
    public void onUpdate() {}

    public void render(DrawContext context) {
        if (mc.player == null) return;

        int accent = getAccentColor();
        int bg = new Color(15, 15, 20, 180).getRGB();
        int text = Color.WHITE.getRGB();

        // WATERMARK
        if (watermark.getBool()) {
            int x = (int) watermarkX, y = (int) watermarkY;
            String s = "FelestDLC | " + new SimpleDateFormat("HH:mm:ss").format(new Date());
            int w = mc.textRenderer.getWidth(s) + 12;
            roundedRect(context, x, y, w, 16, 4, bg);
            context.fill(x, y, x + 3, y + 16, accent);
            context.drawTextWithShadow(mc.textRenderer, s, x + 7, y + 4, text);
            if (editorMode) context.drawBorder(x - 1, y - 1, w + 2, 18, 0xFF8800FF);
        }

        // COOLDOWNS
        if (cooldowns.getBool()) {
            int x = (int) cooldownsX, y = (int) cooldownsY;
            int w = 140, h = 16;
            roundedRect(context, x, y, w, h, 4, bg);
            context.fill(x, y, x + 3, y + h, accent);
            context.drawTextWithShadow(mc.textRenderer, "Cooldowns", x + 7, y + 4, text);
            if (editorMode) context.drawBorder(x - 1, y - 1, w + 2, h + 2, 0xFF8800FF);
        }

        // POTIONS
        if (potions.getBool() && !mc.player.getStatusEffects().isEmpty()) {
            int x = (int) potionsX, y = (int) potionsY;
            int totalH = 0;
            for (StatusEffectInstance e : mc.player.getStatusEffects()) {
                String name = e.getEffectType().value().getName().getString();
                int sec = e.getDuration() / 20;
                String txt = name + " " + (sec / 60) + ":" + String.format("%02d", sec % 60);
                int w = mc.textRenderer.getWidth(txt) + 12;
                roundedRect(context, x, y + totalH, w, 14, 4, bg);
                context.fill(x, y + totalH, x + 3, y + totalH + 14, accent);
                context.drawTextWithShadow(mc.textRenderer, txt, x + 7, y + totalH + 3, text);
                totalH += 18;
            }
            if (editorMode) context.drawBorder(x - 1, y - 1, 120, totalH + 2, 0xFF8800FF);
        }

        // BPS/TPS
        if (bpsTps.getBool()) {
            int x = (int) bpsX, y = (int) bpsY;
            double dx = mc.player.getX() - mc.player.prevX;
            double dz = mc.player.getZ() - mc.player.prevZ;
            double bps = Math.sqrt(dx * dx + dz * dz) * 20;
            String txt = String.format("BPS: %.2f", bps);
            int w = mc.textRenderer.getWidth(txt) + 12;
            roundedRect(context, x, y, w, 14, 4, bg);
            context.fill(x, y, x + 3, y + 14, accent);
            context.drawTextWithShadow(mc.textRenderer, txt, x + 7, y + 3, text);

            String tps = "TPS: 20.0";
            int w2 = mc.textRenderer.getWidth(tps) + 12;
            roundedRect(context, x, y + 18, w2, 14, 4, bg);
            context.fill(x, y + 18, x + 3, y + 32, accent);
            context.drawTextWithShadow(mc.textRenderer, tps, x + 7, y + 21, text);

            if (editorMode) context.drawBorder(x - 1, y - 1, Math.max(w, w2) + 2, 34, 0xFF8800FF);
        }

        // TARGET HUD
        if (targetHud.getBool()) {
            renderTargetHud(context, accent, bg);
        }
    }

    private void renderTargetHud(DrawContext context, int accent, int bg) {
        LivingEntity target = null;
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            Entity e = ((EntityHitResult) mc.crosshairTarget).getEntity();
            if (e instanceof LivingEntity && e != mc.player) target = (LivingEntity) e;
        }
        if (target == null) {
            if (lastTarget != null && System.currentTimeMillis() - lastTargetTime < TARGET_HIDE_MS) {
                target = lastTarget;
            } else {
                lastTarget = null;
                return;
            }
        } else {
            lastTarget = target;
            lastTargetTime = System.currentTimeMillis();
        }

        int tx = (int) targetX, ty = (int) targetY;
        String name = target.getName().getString();
        float hp = target.getHealth();
        float maxHp = target.getMaxHealth();
        float pct = MathHelper.clamp(hp / maxHp, 0f, 1f);

        int w = 130, h = 36;
        roundedRect(context, tx, ty, w, h, 6, bg);
        context.fill(tx, ty, tx + 3, ty + h, accent);
        context.drawTextWithShadow(mc.textRenderer, name, tx + 8, ty + 6, Color.WHITE.getRGB());

        int barX = tx + 8, barY = ty + 22, barW = w - 16, barH = 8;
        context.fill(barX, barY, barX + barW, barY + barH, new Color(40, 40, 50).getRGB());
        int filled = (int)(barW * pct);
        int hpColor = pct > 0.5f ? new Color(60, 200, 60).getRGB() : pct > 0.25f ? new Color(230, 200, 60).getRGB() : new Color(220, 60, 60).getRGB();
        context.fill(barX, barY, barX + filled, barY + barH, hpColor);
        context.drawTextWithShadow(mc.textRenderer, (int)hp + " / " + (int)maxHp, tx + 8, ty + 22 + barH + 1, Color.WHITE.getRGB());

        if (editorMode) context.drawBorder(tx - 1, ty - 1, w + 2, h + 2, 0xFF8800FF);
    }

    private void roundedRect(DrawContext context, int x, int y, int w, int h, int r, int color) {
        context.fill(x + r, y, x + w - r, y + h, color);
        context.fill(x, y + r, x + r, y + h - r, color);
        context.fill(x + w - r, y + r, x + w, y + h - r, color);
        context.fill(x + r, y + h - r, x + w - r, y + h, color);
        for (int i = 0; i < r; i++) {
            int dx = (int) Math.sqrt(r * r - (r - i) * (r - i));
            int xStart = x + r - dx;
            int xEnd = x + w - r + dx;
            context.fill(xStart, y + i, x + r, y + i + 1, color);
            context.fill(x + w - r, y + i, xEnd, y + i + 1, color);
            context.fill(xStart, y + h - i - 1, x + r, y + h - i, color);
            context.fill(x + w - r, y + h - i - 1, xEnd, y + h - i, color);
        }
    }
}
