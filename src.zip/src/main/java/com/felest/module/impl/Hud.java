package com.felest.module.impl;

import com.felest.FelestDLC;
import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import com.felest.util.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Hud extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting scale = new Setting("Размер", 1.0f, 0.6f, 1.6f, 0.05f);
    public final Setting colorTheme = new Setting("Цвет", "Фиолетовый",
            "Фиолетовый", "Синий", "Голубой", "Зелёный", "Красный", "Розовый", "Оранжевый", "Жёлтый", "Белый");
    public final Setting info = new Setting("Info", true);
    public final Setting keybinds = new Setting("Hotkeys", true);
    public final Setting potions = new Setting("Potions", true);
    public final Setting cooldowns = new Setting("Cooldowns", true);
    public final Setting targetHud = new Setting("TargetHUD", true);
    public final Setting armorHud = new Setting("Armor", true);

    public float infoX = 8, infoY = 8;
    public float keybindsX = 8, keybindsY = 70;
    public float potionsX = 8, potionsY = 130;
    public float cooldownsX = 8, cooldownsY = 200;
    public float targetX = 380, targetY = 250;
    public float armorX = 8, armorY = 280;

    private float infoAnim = 0f, kbAnim = 0f, potAnim = 0f, cdAnim = 0f, targetAnim = 0f, armorAnim = 0f;

    private LivingEntity lastTarget = null;
    private long lastTargetTime = 0L;
    private final long TARGET_HIDE_MS = 4000L;

    public boolean editorMode = false;

    private final int TEXT = 0xFFFFFFFF;
    private final int TEXT_DIM = 0xFFE0E0F0;

    public Hud() {
        super("HUD", Category.Render);
        addSetting(scale);
        addSetting(colorTheme);
        addSetting(info);
        addSetting(keybinds);
        addSetting(potions);
        addSetting(cooldowns);
        addSetting(targetHud);
        addSetting(armorHud);
    }

    @Override
    public void onUpdate() {
        infoAnim   = anim(infoAnim, info.getBool() ? 1f : 0f);
        kbAnim     = anim(kbAnim, keybinds.getBool() ? 1f : 0f);
        potAnim    = anim(potAnim, potions.getBool() ? 1f : 0f);
        cdAnim     = anim(cdAnim, cooldowns.getBool() ? 1f : 0f);
        targetAnim = anim(targetAnim, targetHud.getBool() ? 1f : 0f);
        armorAnim  = anim(armorAnim, armorHud.getBool() ? 1f : 0f);
    }

    private float anim(float current, float target) {
        if (current < target) return Math.min(target, current + 0.1f);
        if (current > target) return Math.max(target, current - 0.1f);
        return current;
    }

    private int[] getThemeColors() {
        switch (colorTheme.getString()) {
            case "Синий":      return new int[]{0xB04090E0, 0xD02060A0, 0xA03878C0, 0xB0285090, 0x4080B0FF};
            case "Голубой":    return new int[]{0xB040C0E0, 0xD02090A0, 0xA038A8C0, 0xB0288090, 0x4080E0FF};
            case "Зелёный":    return new int[]{0xB040E080, 0xD020A050, 0xA038C070, 0xB0288040, 0x4080FFA0};
            case "Красный":    return new int[]{0xB0E05050, 0xD0A03030, 0xA0C04040, 0xB0802020, 0x40FF8080};
            case "Розовый":    return new int[]{0xB0E070C0, 0xD0A04090, 0xA0C060B0, 0xB0803080, 0x40FF90D0};
            case "Оранжевый":  return new int[]{0xB0E09040, 0xD0A06020, 0xA0C08030, 0xB0805010, 0x40FFB060};
            case "Жёлтый":     return new int[]{0xB0E0D040, 0xD0A09020, 0xA0C0B030, 0xB0807010, 0x40FFE060};
            case "Белый":      return new int[]{0xB0E0E0F0, 0xD0A0A0B0, 0xA0C0C0D0, 0xB0808090, 0x40FFFFFF};
            default:           return new int[]{0xB07060E0, 0xD0403090, 0xA0554499, 0xB0332270, 0x40BB99FF};
        }
    }

    private int capTop()   { return getThemeColors()[0]; }
    private int capBot()   { return getThemeColors()[1]; }
    private int bgTop()    { return getThemeColors()[2]; }
    private int bgBot()    { return getThemeColors()[3]; }
    private int glowColor(){ return getThemeColors()[4]; }

    private void capsule(DrawContext ctx, int x, int y, int w, int h, int r, int top, int bot) {
        int glow = glowColor();
        RenderUtil.roundedOutline(ctx, x - 2, y - 2, w + 4, h + 4, r + 2, (glow & 0x00FFFFFF) | 0x20000000, 1);
        RenderUtil.roundedOutline(ctx, x - 1, y - 1, w + 2, h + 2, r + 1, (glow & 0x00FFFFFF) | 0x40000000, 1);
        RenderUtil.roundedGradient(ctx, x, y, w, h, r, top, bot);
    }

    public void render(DrawContext context) {
        if (mc.player == null) return;

        float sc = scale.getFloat();
        context.getMatrices().push();
        context.getMatrices().scale(sc, sc, 1f);

        if (infoAnim > 0.01f)      renderInfo(context, infoAnim);
        if (kbAnim > 0.01f)        renderHotkeys(context, kbAnim);
        if (potAnim > 0.01f)       renderPotions(context, potAnim);
        if (cdAnim > 0.01f)        renderCooldowns(context, cdAnim);
        if (targetAnim > 0.01f)    renderTarget(context, targetAnim);
        if (armorAnim > 0.01f)     renderArmor(context, armorAnim);

        context.getMatrices().pop();
    }

    private void renderInfo(DrawContext context, float a) {
        int x = (int) infoX;
        int y = (int) (infoY - (1f - a) * 12);

        String time = new SimpleDateFormat("HH:mm:ss").format(new Date());
        int fps = mc.getCurrentFps();
        String user = mc.getSession().getUsername();
        String coords = (int)mc.player.getX() + " " + (int)mc.player.getY() + " " + (int)mc.player.getZ();
        int ping = 0;
        try {
            if (mc.getNetworkHandler() != null && mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()) != null) {
                ping = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()).getLatency();
            }
        } catch (Exception ignored) {}

        int rowH = 20;

        int r1w = 32 + mc.textRenderer.getWidth("beta") + 12
                + mc.textRenderer.getWidth("●" + user) + 14
                + mc.textRenderer.getWidth("●" + fps + " FPS") + 14
                + mc.textRenderer.getWidth("●" + time) + 12;

        capsule(context, x, y, r1w, rowH, 6, bgTop(), bgBot());

        RenderUtil.roundedGradient(context, x + 4, y + 3, 22, 14, 4, capTop(), capBot());
        context.drawTextWithShadow(mc.textRenderer, "F", x + 11, y + 6, 0xFFFFFFFF);
        context.drawTextWithShadow(mc.textRenderer, "beta", x + 30, y + 6, TEXT);

        int cx = x + 30 + mc.textRenderer.getWidth("beta") + 14;
        cx = drawChip(context, cx, y + 1, user, 0xFFFFFFFF);
        cx = drawChip(context, cx, y + 1, fps + " FPS", 0xFFFFFFFF);
        cx = drawChip(context, cx, y + 1, time, 0xFFFFFFFF);

        int y2 = y + rowH + 3;
        int r2w = 10 + mc.textRenderer.getWidth("◈" + coords) + 14
                + mc.textRenderer.getWidth("◈" + ping + " Ping") + 12;

        capsule(context, x, y2, r2w, rowH, 6, bgTop(), bgBot());

        int cx2 = x + 8;
        context.drawTextWithShadow(mc.textRenderer, "◈", cx2 + 2, y2 + 6, 0xFFBBAAFF);
        context.drawTextWithShadow(mc.textRenderer, coords, cx2 + 14, y2 + 6, TEXT);
        cx2 += 10 + mc.textRenderer.getWidth("◈" + coords) + 6;
        context.drawTextWithShadow(mc.textRenderer, "◈", cx2 + 2, y2 + 6, 0xFFBBAAFF);
        context.drawTextWithShadow(mc.textRenderer, ping + " Ping", cx2 + 14, y2 + 6, TEXT);

        if (editorMode) context.drawBorder(x - 3, y - 3, Math.max(r1w, r2w) + 6, rowH * 2 + 9, 0xFF8800FF);
    }

    private int drawChip(DrawContext context, int x, int y, String text, int dotColor) {
        context.drawTextWithShadow(mc.textRenderer, "●", x + 2, y + 6, dotColor);
        context.drawTextWithShadow(mc.textRenderer, text, x + 12, y + 6, TEXT);
        return x + 12 + mc.textRenderer.getWidth(text) + 10;
    }

    private void renderHotkeys(DrawContext context, float a) {
        int x = (int) keybindsX;
        int y = (int) (keybindsY - (1f - a) * 12);

        List<Module> enabled = new ArrayList<>();
        for (Module m : FelestDLC.moduleManager.getModules()) {
            if (m.isEnabled() && m.getKeyBind() != -1 && !m.getName().equals("HUD")) {
                enabled.add(m);
            }
        }
        if (enabled.isEmpty() && !editorMode) return;

        int rowH = 18;
        int w = 130;
        int h = 24 + Math.max(1, enabled.size()) * rowH;

        capsule(context, x, y, w, 24, 6, bgTop(), bgBot());
        RenderUtil.roundedGradient(context, x + 4, y + 3, 18, 18, 4, capTop(), capBot());
        context.drawTextWithShadow(mc.textRenderer, "⌨", x + 7, y + 6, 0xFFFFFFFF);
        context.drawTextWithShadow(mc.textRenderer, "Hotkeys", x + 26, y + 7, TEXT);

        int ry = y + 28;
        if (enabled.isEmpty()) {
            capsule(context, x, ry - 2, w, 16, 4, bgTop(), bgBot());
            context.drawTextWithShadow(mc.textRenderer, "—", x + 8, ry + 2, TEXT_DIM);
        } else {
            for (Module m : enabled) {
                capsule(context, x, ry - 2, w, 16, 4, bgTop(), bgBot());
                context.drawTextWithShadow(mc.textRenderer, m.getName(), x + 8, ry + 2, TEXT);

                String key = org.lwjgl.glfw.GLFW.glfwGetKeyName(m.getKeyBind(), 0);
                if (key == null) key = "?";
                key = key.toUpperCase();
                int kw = mc.textRenderer.getWidth(key);
                RenderUtil.roundedGradient(context, x + w - 10 - kw - 6, ry, kw + 10, 13, 3, capTop(), capBot());
                context.drawTextWithShadow(mc.textRenderer, key, x + w - 10 - kw - 1, ry + 3, TEXT);
                ry += rowH;
            }
        }

        if (editorMode) context.drawBorder(x - 3, y - 3, w + 6, h + 6, 0xFF8800FF);
    }

    private void renderPotions(DrawContext context, float a) {
        if (mc.player.getStatusEffects().isEmpty() && !editorMode) return;

        int x = (int) potionsX;
        int y = (int) (potionsY - (1f - a) * 12);

        List<StatusEffectInstance> effects = new ArrayList<>(mc.player.getStatusEffects());
        int rowH = 18;
        int w = 160;
        int h = 24 + Math.max(1, effects.size()) * rowH;

        capsule(context, x, y, w, 24, 6, bgTop(), bgBot());
        RenderUtil.roundedGradient(context, x + 4, y + 3, 18, 18, 4, capTop(), capBot());
        context.drawTextWithShadow(mc.textRenderer, "⚗", x + 7, y + 6, 0xFFFFFFFF);
        context.drawTextWithShadow(mc.textRenderer, "Active Potions", x + 26, y + 7, TEXT);

        int ry = y + 28;
        if (effects.isEmpty()) {
            capsule(context, x, ry - 2, w, 16, 4, bgTop(), bgBot());
            context.drawTextWithShadow(mc.textRenderer, "—", x + 8, ry + 2, TEXT_DIM);
        } else {
            for (StatusEffectInstance e : effects) {
                String name = e.getEffectType().value().getName().getString();
                int sec = e.getDuration() / 20;
                String time = (sec / 60) + ":" + String.format("%02d", sec % 60);

                if (name.contains(" ")) {
                    String[] parts = name.split(" ");
                    if (parts.length > 1) name = parts[parts.length - 1];
                }

                capsule(context, x, ry - 2, w, 16, 4, bgTop(), bgBot());
                context.drawTextWithShadow(mc.textRenderer, name, x + 8, ry + 2, TEXT);
                int tw = mc.textRenderer.getWidth(time);
                context.drawTextWithShadow(mc.textRenderer, time, x + w - 8 - tw, ry + 2, 0xFFBBAAFF);
                ry += rowH;
            }
        }

        if (editorMode) context.drawBorder(x - 3, y - 3, w + 6, h + 6, 0xFF8800FF);
    }

    private void renderCooldowns(DrawContext context, float a) {
        int x = (int) cooldownsX;
        int y = (int) (cooldownsY - (1f - a) * 12);

        List<String[]> lines = new ArrayList<>();
        for (int i = 0; i < 36; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (s.isEmpty()) continue;
            if (mc.player.getItemCooldownManager().isCoolingDown(s)) {
                float prog = mc.player.getItemCooldownManager().getCooldownProgress(s, 0f);
                float rem = (1f - prog) * 10f;
                lines.add(new String[]{ s.getName().getString(), String.format("%.1fs", rem) });
            }
        }
        if (lines.isEmpty() && !editorMode) return;

        int rowH = 18;
        int w = 140;
        int h = 24 + Math.max(1, lines.size()) * rowH;

        capsule(context, x, y, w, 24, 6, bgTop(), bgBot());
        RenderUtil.roundedGradient(context, x + 4, y + 3, 18, 18, 4, capTop(), capBot());
        context.drawTextWithShadow(mc.textRenderer, "⌛", x + 7, y + 6, 0xFFFFFFFF);
        context.drawTextWithShadow(mc.textRenderer, "Cooldowns", x + 26, y + 7, TEXT);

        int ry = y + 28;
        if (lines.isEmpty()) {
            capsule(context, x, ry - 2, w, 16, 4, bgTop(), bgBot());
            context.drawTextWithShadow(mc.textRenderer, "—", x + 8, ry + 2, TEXT_DIM);
        } else {
            for (String[] it : lines) {
                capsule(context, x, ry - 2, w, 16, 4, bgTop(), bgBot());
                context.drawTextWithShadow(mc.textRenderer, it[0], x + 8, ry + 2, TEXT);
                int tw = mc.textRenderer.getWidth(it[1]);
                context.drawTextWithShadow(mc.textRenderer, it[1], x + w - 8 - tw, ry + 2, 0xFFBBAAFF);
                ry += rowH;
            }
        }

        if (editorMode) context.drawBorder(x - 3, y - 3, w + 6, h + 6, 0xFF8800FF);
    }

    private void renderTarget(DrawContext context, float a) {
        LivingEntity target = null;
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            Entity e = ((EntityHitResult) mc.crosshairTarget).getEntity();
            if (e instanceof LivingEntity && e != mc.player) target = (LivingEntity) e;
        }
        if (target == null) {
            if (lastTarget != null && System.currentTimeMillis() - lastTargetTime < TARGET_HIDE_MS) target = lastTarget;
            else { lastTarget = null; return; }
        } else {
            lastTarget = target;
            lastTargetTime = System.currentTimeMillis();
        }

        int tx = (int) targetX;
        int ty = (int) (targetY + (1f - a) * 12);

        String name = target.getName().getString();
        float hp = target.getHealth();
        float maxHp = target.getMaxHealth();
        float absorb = target.getAbsorptionAmount();
        float pct = MathHelper.clamp(hp / maxHp, 0f, 1f);

        int w = 160;
        int h = 42;

        capsule(context, tx, ty, w, h, 6, bgTop(), bgBot());

        context.drawTextWithShadow(mc.textRenderer, name, tx + 8, ty + 6, TEXT);
        String hpText = (int)hp + " HP";
        int htw = mc.textRenderer.getWidth(hpText);
        context.drawTextWithShadow(mc.textRenderer, hpText, tx + w - htw - 8, ty + 6, TEXT);

        int barX = tx + 6;
        int barY = ty + h - 12;
        int barW = w - 12;
        int barH = 6;

        RenderUtil.roundedRect(context, barX, barY, barW, barH, 3, 0x90332270);

        int filled = (int)(barW * pct);
        for (int i = 0; i < filled; i++) {
            float t = (float) i / barW;
            int color = hpColor(t);
            context.fill(barX + i, barY, barX + i + 1, barY + barH, color);
        }

        if (absorb > 0) {
            float apct = MathHelper.clamp(absorb / maxHp, 0f, 1f);
            int af = (int)(barW * apct);
            RenderUtil.roundedRect(context, barX, barY, af, barH, 3, 0xFFEEDD55);
        }

        if (editorMode) context.drawBorder(tx - 3, ty - 3, w + 6, h + 6, 0xFF8800FF);
    }

    private int hpColor(float hpPercent) {
        if (hpPercent < 0.25f) {
            float t = hpPercent / 0.25f;
            int r = 220;
            int g = (int)(60 + 120 * t);
            return 0xFF000000 | (r << 16) | (g << 8) | 0x30;
        } else if (hpPercent < 0.6f) {
            float t = (hpPercent - 0.25f) / 0.35f;
            int r = 230;
            int g = (int)(180 + 40 * t);
            return 0xFF000000 | (r << 16) | (g << 8) | 0x30;
        } else {
            return 0xFF55DD77;
        }
    }

    private void renderArmor(DrawContext context, float a) {
        int x = (int) armorX;
        int y = (int) (armorY - (1f - a) * 12);

        ItemStack[] armor = {
                mc.player.getInventory().getArmorStack(3),
                mc.player.getInventory().getArmorStack(2),
                mc.player.getInventory().getArmorStack(1),
                mc.player.getInventory().getArmorStack(0)
        };

        boolean any = false;
        for (ItemStack s : armor) if (!s.isEmpty()) { any = true; break; }
        if (!any && !editorMode) return;

        int slotW = 38;
        int slotH = 34;
        int w = slotW * 4 + 8;
        int h = slotH + 6;

        capsule(context, x, y, w, h, 6, bgTop(), bgBot());

        for (int i = 0; i < 4; i++) {
            int sx = x + 4 + i * slotW;
            int sy = y + 3;
            ItemStack s = armor[i];

            capsule(context, sx, sy, slotW - 3, slotH, 4, bgTop(), bgBot());

            if (!s.isEmpty()) {
                context.drawItem(s, sx + 4, sy + 2);

                if (s.isDamageable()) {
                    int max = s.getMaxDamage();
                    int dmg = s.getDamage();
                    int percent = (int)((1f - (float) dmg / max) * 100f);
                    String p = percent + "%";
                    int color = percent > 60 ? 0xFF55DD77 : percent > 25 ? 0xFFEEDD55 : 0xFFDD5555;
                    int pw = mc.textRenderer.getWidth(p);
                    context.drawTextWithShadow(mc.textRenderer, p,
                            sx + (slotW - 3 - pw) / 2, sy + slotH - 12, color);
                }
            } else {
                context.drawTextWithShadow(mc.textRenderer, "—",
                        sx + (slotW - 3) / 2 - 3, sy + slotH / 2 - 2, 0xFF8070A0);
            }
        }

        if (editorMode) context.drawBorder(x - 3, y - 3, w + 6, h + 6, 0xFF8800FF);
    }
}
