package com.felest.module.impl;

import com.felest.FelestDLC;
import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import com.felest.util.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;

import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Hud extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting scale = new Setting("Размер", 1.0f, 0.6f, 1.6f, 0.05f);
    public final Setting info = new Setting("Info", true);
    public final Setting keybinds = new Setting("Hotkeys", true);
    public final Setting potions = new Setting("Potions", true);
    public final Setting cooldowns = new Setting("Cooldowns", true);
    public final Setting targetHud = new Setting("TargetHUD", true);
    public final Setting armorHud = new Setting("Armor", true);

    public float infoX = 8, infoY = 8;
    public float keybindsX = 8, keybindsY = 70;
    public float potionsX = 8, potionsY = 130;
    public float cooldownsX = 8, cooldownsY = 200;
    public float targetX = 380, targetY = 250;
    public float armorX = 8, armorY = 280;

    private float infoAnim = 0f, kbAnim = 0f, potAnim = 0f, cdAnim = 0f, targetAnim = 0f, armorAnim = 0f;

    private LivingEntity lastTarget = null;
    private long lastTargetTime = 0L;
    private final long TARGET_HIDE_MS = 4000L;

    public boolean editorMode = false;

    // Сине-фиолетовая палитра
    private final int BG_DARK = new Color(20, 15, 40, 200).getRGB();
    private final int BG_MID = new Color(40, 25, 70, 220).getRGB();
    private final int CAP_TOP = new Color(140, 100, 255, 200).getRGB();
    private final int CAP_BOT = new Color(90, 60, 200, 220).getRGB();
    private final int TEXT = 0xFFFFFFFF;
    private final int TEXT_DIM = new Color(200, 190, 230).getRGB();

    public Hud() {
        super("HUD", Category.Render);
        addSetting(scale);
        addSetting(info);
        addSetting(keybinds);
        addSetting(potions);
        addSetting(cooldowns);
        addSetting(targetHud);
        addSetting(armorHud);
    }

    @Override
    public void onUpdate() {
        infoAnim   = anim(infoAnim, info.getBool() ? 1f : 0f);
        kbAnim     = anim(kbAnim, keybinds.getBool() ? 1f : 0f);
        potAnim    = anim(potAnim, potions.getBool() ? 1f : 0f);
        cdAnim     = anim(cdAnim, cooldowns.getBool() ? 1f : 0f);
        targetAnim = anim(targetAnim, targetHud.getBool() ? 1f : 0f);
        armorAnim  = anim(armorAnim, armorHud.getBool() ? 1f : 0f);
    }

    private float anim(float current, float target) {
        if (current < target) return Math.min(target, current + 0.1f);
        if (current > target) return Math.max(target, current - 0.1f);
        return current;
    }

    public void render(DrawContext context) {
        if (mc.player == null) return;

        float sc = scale.getFloat();
        context.getMatrices().push();
        context.getMatrices().scale(sc, sc, 1f);

        if (infoAnim > 0.01f)      renderInfo(context, infoAnim);
        if (kbAnim > 0.01f)        renderHotkeys(context, kbAnim);
        if (potAnim > 0.01f)       renderPotions(context, potAnim);
        if (cdAnim > 0.01f)        renderCooldowns(context, cdAnim);
        if (targetAnim > 0.01f)    renderTarget(context, targetAnim);
        if (armorAnim > 0.01f)     renderArmor(context, armorAnim);

        context.getMatrices().pop();
    }

    // ============ INFO ============
    private void renderInfo(DrawContext context, float a) {
        int x = (int) infoX;
        int y = (int) (infoY - (1f - a) * 12);

        String time = new SimpleDateFormat("HH:mm:ss").format(new Date());
        int fps = mc.getCurrentFps();
        String user = mc.getSession().getUsername();
        String coords = (int)mc.player.getX() + " " + (int)mc.player.getY() + " " + (int)mc.player.getZ();
        int ping = 0;
        try {
            if (mc.getNetworkHandler() != null && mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()) != null) {
                ping = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()).getLatency();
            }
        } catch (Exception ignored) {}

        int rowH = 18;

        // Строка 1: Release | user | FPS | time
        int r1w = 10 + mc.textRenderer.getWidth("●Release") + 14
                + mc.textRenderer.getWidth("●" + user) + 14
                + mc.textRenderer.getWidth("●" + fps + " FPS") + 14
                + mc.textRenderer.getWidth("●" + time) + 12;

        RenderUtil.roundedRect(context, x, y, r1w, rowH, 6, BG_DARK);
        RenderUtil.roundedOutline(context, x, y, r1w, rowH, 6, CAP_TOP, 1);

        int cx = x + 8;
        cx = drawChip(context, cx, y + 2, "Release", 0xFF55DD77);
        cx = drawChip(context, cx, y + 2, user, 0xFFFFFFFF);
        cx = drawChip(context, cx, y + 2, fps + " FPS", 0xFFFFFFFF);
        cx = drawChip(context, cx, y + 2, time, 0xFFFFFFFF);

        // Строка 2: coords | ping
        int y2 = y + rowH + 3;
        int r2w = 10 + mc.textRenderer.getWidth("◈" + coords) + 14
                + mc.textRenderer.getWidth("◈" + ping + " Ping") + 12;

        RenderUtil.roundedRect(context, x, y2, r2w, rowH, 6, BG_DARK);
        RenderUtil.roundedOutline(context, x, y2, r2w, rowH, 6, CAP_TOP, 1);

        int cx2 = x + 8;
        context.drawTextWithShadow(mc.textRenderer, "◈", cx2 + 2, y2 + 5, 0xFF7FAAFF);
        context.drawTextWithShadow(mc.textRenderer, coords, cx2 + 14, y2 + 5, TEXT);
        cx2 += 10 + mc.textRenderer.getWidth("◈" + coords) + 6;
        context.drawTextWithShadow(mc.textRenderer, "◈", cx2 + 2, y2 + 5, 0xFF7FAAFF);
        context.drawTextWithShadow(mc.textRenderer, ping + " Ping", cx2 + 14, y2 + 5, TEXT);

        if (editorMode) context.drawBorder(x - 2, y - 2, Math.max(r1w, r2w) + 4, rowH * 2 + 7, 0xFF8800FF);
    }

    private int drawChip(DrawContext context, int x, int y, String text, int dotColor) {
        // "●" + текст
        context.drawTextWithShadow(mc.textRenderer, "●", x + 2, y + 5, dotColor);
        context.drawTextWithShadow(mc.textRenderer, text, x + 12, y + 5, TEXT);
        return x + 12 + mc.textRenderer.getWidth(text) + 10;
    }

    // ============ HOTKEYS ============
    private void renderHotkeys(DrawContext context, float a) {
        int x = (int) keybindsX;
        int y = (int) (keybindsY - (1f - a) * 12);

        List<Module> enabled = new ArrayList<>();
        for (Module m : FelestDLC.moduleManager.getModules()) {
            // Только ВКЛЮЧЁННЫЕ и с ЗАБИНДЕННОЙ клавишей, кроме HUD
            if (m.isEnabled() && m.getKeyBind() != -1 && !m.getName().equals("HUD")) {
                enabled.add(m);
            }
        }
        if (enabled.isEmpty() && !editorMode) return;

        int rowH = 16;
        int w = 130;
        int h = 22 + Math.max(1, enabled.size()) * rowH;

        // Заголовок капсулы
        RenderUtil.roundedRect(context, x, y, w, 22, 5, BG_DARK);
        RenderUtil.roundedRect(context, x, y, w, 22, 5, CAP_TOP);
        RenderUtil.roundedOutline(context, x, y, w, 22, 5, 0xFFAA88FF, 1);
        context.drawTextWithShadow(mc.textRenderer, "⌨", x + 6, y + 7, 0xFFFFFFFF);
        context.drawTextWithShadow(mc.textRenderer, "Hotkeys", x + 20, y + 7, TEXT);

        int ry = y + 26;
        if (enabled.isEmpty()) {
            RenderUtil.roundedRect(context, x, ry - 2, w, 16, 4, BG_MID);
            context.drawTextWithShadow(mc.textRenderer, "—", x + 8, ry + 1, TEXT_DIM);
        } else {
            for (Module m : enabled) {
                RenderUtil.roundedRect(context, x, ry - 2, w, 16, 4, BG_MID);
                context.drawTextWithShadow(mc.textRenderer, m.getName(), x + 8, ry + 1, TEXT);

                String key = org.lwjgl.glfw.GLFW.glfwGetKeyName(m.getKeyBind(), 0);
                if (key == null) key = "?";
                key = key.toUpperCase();
                int kw = mc.textRenderer.getWidth(key);
                RenderUtil.roundedRect(context, x + w - 10 - kw - 6, ry, kw + 10, 13, 3, CAP_BOT);
                context.drawTextWithShadow(mc.textRenderer, key, x + w - 10 - kw - 1, ry + 2, TEXT);
                ry += rowH;
            }
        }

        if (editorMode) context.drawBorder(x - 2, y - 2, w + 4, h + 4, 0xFF8800FF);
    }

    // ============ POTIONS ============
    private void renderPotions(DrawContext context, float a) {
        if (mc.player.getStatusEffects().isEmpty() && !editorMode) return;

        int x = (int) potionsX;
        int y = (int) (potionsY - (1f - a) * 12);

        List<StatusEffectInstance> effects = new ArrayList<>(mc.player.getStatusEffects());
        int rowH = 16;
        int w = 160;
        int h = 22 + Math.max(1, effects.size()) * rowH;

        RenderUtil.roundedRect(context, x, y, w, 22, 5, BG_DARK);
        RenderUtil.roundedRect(context, x, y, w, 22, 5, CAP_TOP);
        RenderUtil.roundedOutline(context, x, y, w, 22, 5, 0xFFAA88FF, 1);
        context.drawTextWithShadow(mc.textRenderer, "⚗", x + 6, y + 7, 0xFFFFFFFF);
        context.drawTextWithShadow(mc.textRenderer, "Active Potions", x + 22, y + 7, TEXT);

        int ry = y + 26;
        if (effects.isEmpty()) {
            RenderUtil.roundedRect(context, x, ry - 2, w, 16, 4, BG_MID);
            context.drawTextWithShadow(mc.textRenderer, "—", x + 8, ry + 1, TEXT_DIM);
        } else {
            for (StatusEffectInstance e : effects) {
                String name = e.getEffectType().value().getName().getString();
                int sec = e.getDuration() / 20;
                String time = (sec / 60) + ":" + String.format("%02d", sec % 60);

                if (name.contains(" ")) {
                    String[] parts = name.split(" ");
                    if (parts.length > 1) name = parts[parts.length - 1];
                }

                RenderUtil.roundedRect(context, x, ry - 2, w, 16, 4, BG_MID);
                context.drawTextWithShadow(mc.textRenderer, name, x + 8, ry + 1, TEXT);
                int tw = mc.textRenderer.getWidth(time);
                context.drawTextWithShadow(mc.textRenderer, time, x + w - 8 - tw, ry + 1, 0xFFAA88FF);
                ry += rowH;
            }
        }

        if (editorMode) context.drawBorder(x - 2, y - 2, w + 4, h + 4, 0xFF8800FF);
    }

    // ============ COOLDOWNS ============
    private void renderCooldowns(DrawContext context, float a) {
        int x = (int) cooldownsX;
        int y = (int) (cooldownsY - (1f - a) * 12);

        List<String[]> lines = new ArrayList<>();
        for (int i = 0; i < 36; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (s.isEmpty()) continue;
            if (mc.player.getItemCooldownManager().isCoolingDown(s)) {
                float prog = mc.player.getItemCooldownManager().getCooldownProgress(s, 0f);
                float rem = (1f - prog) * 10f;
                lines.add(new String[]{ s.getName().getString(), String.format("%.1fs", rem) });
            }
        }
        if (lines.isEmpty() && !editorMode) return;

        int rowH = 16;
        int w = 140;
        int h = 22 + Math.max(1, lines.size()) * rowH;

        RenderUtil.roundedRect(context, x, y, w, 22, 5, BG_DARK);
        RenderUtil.roundedRect(context, x, y, w, 22, 5, CAP_TOP);
        RenderUtil.roundedOutline(context, x, y, w, 22, 5, 0xFFAA88FF, 1);
        context.drawTextWithShadow(mc.textRenderer, "⌛", x + 6, y + 7, 0xFFFFFFFF);
        context.drawTextWithShadow(mc.textRenderer, "Cooldowns", x + 22, y + 7, TEXT);

        int ry = y + 26;
        if (lines.isEmpty()) {
            RenderUtil.roundedRect(context, x, ry - 2, w, 16, 4, BG_MID);
            context.drawTextWithShadow(mc.textRenderer, "—", x + 8, ry + 1, TEXT_DIM);
        } else {
            for (String[] it : lines) {
                RenderUtil.roundedRect(context, x, ry - 2, w, 16, 4, BG_MID);
                context.drawTextWithShadow(mc.textRenderer, it[0], x + 8, ry + 1, TEXT);
                int tw = mc.textRenderer.getWidth(it[1]);
                context.drawTextWithShadow(mc.textRenderer, it[1], x + w - 8 - tw, ry + 1, 0xFFAA88FF);
                ry += rowH;
            }
        }

        if (editorMode) context.drawBorder(x - 2, y - 2, w + 4, h + 4, 0xFF8800FF);
    }

    // ============ TARGET HUD ============
    private void renderTarget(DrawContext context, float a) {
        LivingEntity target = null;
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            Entity e = ((EntityHitResult) mc.crosshairTarget).getEntity();
            if (e instanceof LivingEntity && e != mc.player) target = (LivingEntity) e;
        }
        if (target == null) {
            if (lastTarget != null && System.currentTimeMillis() - lastTargetTime < TARGET_HIDE_MS) target = lastTarget;
            else { lastTarget = null; return; }
        } else {
            lastTarget = target;
            lastTargetTime = System.currentTimeMillis();
        }

        int tx = (int) targetX;
        int ty = (int) (targetY + (1f - a) * 12);

        String name = target.getName().getString();
        float hp = target.getHealth();
        float maxHp = target.getMaxHealth();
        float absorb = target.getAbsorptionAmount();
        float pct = MathHelper.clamp(hp / maxHp, 0f, 1f);

        int w = 160;
        int h = 42;

        RenderUtil.roundedRect(context, tx, ty, w, h, 6, BG_DARK);
        RenderUtil.roundedOutline(context, tx, ty, w, h, 6, CAP_TOP, 1);

        // Ник
        context.drawTextWithShadow(mc.textRenderer, name, tx + 8, ty + 6, TEXT);
        // HP текст
        String hpText = (int)hp + " HP";
        int htw = mc.textRenderer.getWidth(hpText);
        context.drawTextWithShadow(mc.textRenderer, hpText, tx + w - htw - 8, ty + 6, TEXT);

        // HP бар снизу
        int barX = tx + 6;
        int barY = ty + h - 12;
        int barW = w - 12;
        int barH = 6;

        RenderUtil.roundedRect(context, barX, barY, barW, barH, 3, new Color(30, 20, 50, 220).getRGB());
        int filled = (int)(barW * pct);
        if (filled > 0) RenderUtil.roundedRect(context, barX, barY, filled, barH, 3, 0xFF66DD88);
        if (absorb > 0) {
            float apct = MathHelper.clamp(absorb / maxHp, 0f, 1f);
            int af = (int)(barW * apct);
            RenderUtil.roundedRect(context, barX, barY, af, barH, 3, 0xFFEEDD55);
        }

        if (editorMode) context.drawBorder(tx - 2, ty - 2, w + 4, h + 4, 0xFF8800FF);
    }

    // ============ ARMOR ============
    private void renderArmor(DrawContext context, float a) {
        int x = (int) armorX;
        int y = (int) (armorY - (1f - a) * 12);

        ItemStack[] armor = {
                mc.player.getInventory().getArmorStack(3),
                mc.player.getInventory().getArmorStack(2),
                mc.player.getInventory().getArmorStack(1),
                mc.player.getInventory().getArmorStack(0)
        };

        boolean any = false;
        for (ItemStack s : armor) if (!s.isEmpty()) { any = true; break; }
        if (!any && !editorMode) return;

        int slotW = 30;
        int w = slotW * 4 + 8;
        int h = 26;

        RenderUtil.roundedRect(context, x, y, w, h, 5, BG_DARK);
        RenderUtil.roundedOutline(context, x, y, w, h, 5, CAP_TOP, 1);

        for (int i = 0; i < 4; i++) {
            int sx = x + 4 + i * slotW;
            int sy = y + 3;
            ItemStack s = armor[i];

            RenderUtil.roundedRect(context, sx, sy, slotW - 3, 20, 4, BG_MID);

            if (!s.isEmpty()) {
                context.drawItem(s, sx + 4, sy + 2);
                if (s.isDamageable()) {
                    int max = s.getMaxDamage();
                    int dmg = s.getDamage();
                    int percent = (int)((1f - (float) dmg / max) * 100f);
                    int color = percent > 60 ? 0xFF55DD77 : percent > 25 ? 0xFFEEDD55 : 0xFFDD5555;
                    String p = percent + "%";
                    context.getMatrices().push();
                    context.getMatrices().translate(sx + slotW - 5, sy + 11, 0);
                    context.getMatrices().scale(0.5f, 0.5f, 1f);
                    context.drawTextWithShadow(mc.textRenderer, p, -mc.textRenderer.getWidth(p), 0, color);
                    context.getMatrices().pop();
                }
            } else {
                context.drawTextWithShadow(mc.textRenderer, "—", sx + 8, sy + 6, new Color(80, 70, 110).getRGB());
            }
        }

        if (editorMode) context.drawBorder(x - 2, y - 2, w + 4, h + 4, 0xFF8800FF);
    }
}
