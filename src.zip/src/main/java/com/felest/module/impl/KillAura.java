package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class KillAura extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting range = new Setting("Дистанция", 3.0f, 2.0f, 4.5f, 0.1f);
    public final Setting fov = new Setting("FOV", 360f, 0f, 360f, 5f);
    public final Setting rotation = new Setting("Ротация", "SpookyTime", "SpookyTime", "MixerGrief");
    public final Setting aimMode = new Setting("Наводка", "Таргет", "Таргет", "Свободная");
    public final Setting sprintReset = new Setting("Сброс спринта", "Легит", "Легит", "Без сброса");
    public final Setting onlyCrits = new Setting("Только криты", false);
    public final Setting smartCrits = new Setting("Умные криты", false);

    private float smoothYaw = 0f;
    private float smoothPitch = 0f;
    private boolean hasSmooth = false;
    private int sprintTicks = 0;
    private boolean wasSprinting = false;

    private double groundY = 0;
    private double peakY = 0;
    private double midFallY = -999;
    private boolean wasFalling = false;
    private boolean hasHitThisJump = false;

    public KillAura() {
        super("KillAura", Category.Combat);
        addSetting(range);
        addSetting(fov);
        addSetting(rotation);
        addSetting(aimMode);
        addSetting(sprintReset);
        addSetting(onlyCrits);
        addSetting(smartCrits);
    }

    @Override
    public void onEnable() {
        resetJumpState();
        hasSmooth = false;
    }

    @Override
    public void onDisable() {
        resetJumpState();
        if (mc.player != null && wasSprinting) {
            mc.player.setSprinting(true);
            mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_SPRINTING));
            wasSprinting = false;
        }
        sprintTicks = 0;
    }

    private void resetJumpState() {
        if (mc.player != null) {
            groundY = mc.player.getY();
            peakY = groundY;
        }
        midFallY = -999;
        wasFalling = false;
        hasHitThisJump = false;
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        // Возврат спринта после сброса
        if (sprintTicks > 0) {
            sprintTicks--;
            if (sprintTicks == 0 && wasSprinting) {
                mc.player.setSprinting(true);
                mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_SPRINTING));
                wasSprinting = false;
            }
        }

        updateJumpTracking();

        LivingEntity target = findTarget();
        if (target == null) {
            hasSmooth = false;
            return;
        }

        // Целевые углы
        double dx = target.getX() - mc.player.getX();
        double dy = target.getEyeY() - mc.player.getEyeY();
        double dz = target.getZ() - mc.player.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);
        float targetYaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        float targetPitch = (float)-Math.toDegrees(Math.atan2(dy, dist));

        // ===== РОТАЦИЯ =====
        float finalYaw;
        float finalPitch;
        String rot = rotation.getString();

        if (rot.equals("SpookyTime")) {
            if (!hasSmooth) {
                smoothYaw = mc.player.getYaw();
                smoothPitch = mc.player.getPitch();
                hasSmooth = true;
            }
            // Плавное доведение (как аим-ассист)
            smoothYaw = lerpAngle(smoothYaw, targetYaw, 0.35f);
            smoothPitch = lerpAngle(smoothPitch, targetPitch, 0.35f);

            // Восьмёрка (figure-8 jitter) — чтобы античит видел "живую" руку
            float t = (System.currentTimeMillis() % 100000L) / 1000f;
            float jitterYaw = (float)(Math.sin(t * 2.5) * 1.8);
            float jitterPitch = (float)(Math.sin(t * 5.0) * 0.9);

            finalYaw = smoothYaw + jitterYaw;
            finalPitch = smoothPitch + jitterPitch;
        } else {
            // MixerGrief — заглушка (резкая наводка), обсудим позже
            finalYaw = targetYaw;
            finalPitch = targetPitch;
            smoothYaw = targetYaw;
            smoothPitch = targetPitch;
            hasSmooth = true;
        }

        // Отправляем серверные углы (silent aim — наша камера не двигается)
        mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                finalYaw, finalPitch, mc.player.isOnGround(), mc.player.horizontalCollision));

        // ===== РЕЖИМ НАВОДКИ =====
        if (aimMode.getString().equals("Таргет")) {
            // Игрок идёт в сторону цели (бесконечное движение)
            double dirX = target.getX() - mc.player.getX();
            double dirZ = target.getZ() - mc.player.getZ();
            double len = Math.sqrt(dirX * dirX + dirZ * dirZ);
            if (len > 0.5) {
                double speed = 0.16;
                mc.player.setVelocity(dirX / len * speed, mc.player.getVelocity().y, dirZ / len * speed);
            }
        }
        // Режим "Свободная" — ничего не делаем, игрок сам ходит

        // ===== КРИТЫ =====
        boolean canHit = false;

        if (onlyCrits.getBool()) {
            if (wasFalling && !hasHitThisJump && mc.player.getY() <= midFallY) canHit = true;
        } else if (smartCrits.getBool()) {
            if (mc.player.isOnGround()) {
                if (mc.player.getAttackCooldownProgress(0.0f) >= 1.0f) canHit = true;
            } else if (wasFalling && !hasHitThisJump && mc.player.getY() <= midFallY) {
                canHit = true;
            }
        } else {
            if (mc.player.getAttackCooldownProgress(0.0f) >= 1.0f) canHit = true;
        }

        if (canHit) {
            // Спринт-ресет (легит)
            if (sprintReset.getString().equals("Легит") && mc.player.isSprinting()) {
                wasSprinting = true;
                mc.player.setSprinting(false);
                mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
                sprintTicks = 3;
            }

            mc.interactionManager.attackEntity(mc.player, target);
            mc.player.swingHand(Hand.MAIN_HAND);
            hasHitThisJump = true;
        }
    }

    private float lerpAngle(float current, float target, float speed) {
        float delta = ((target - current + 540) % 360) - 180;
        return current + delta * speed;
    }

    private void updateJumpTracking() {
        double y = mc.player.getY();
        double vy = mc.player.getVelocity().y;

        if (mc.player.isOnGround()) {
            groundY = y;
            peakY = y;
            midFallY = -999;
            wasFalling = false;
            hasHitThisJump = false;
        } else {
            if (vy > 0) {
                peakY = Math.max(peakY, y);
                wasFalling = false;
            } else if (vy < 0) {
                if (!wasFalling) {
                    wasFalling = true;
                    midFallY = (groundY + peakY) / 2.0;
                }
            }
        }
    }

    private LivingEntity findTarget() {
        List<Entity> entities = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) entities.add(e);

        float r = range.getFloat();
        return entities.stream()
                .filter(e -> e instanceof LivingEntity)
                .map(e -> (LivingEntity) e)
                .filter(e -> e != mc.player)
                .filter(LivingEntity::isAlive)
                .filter(e -> mc.player.distanceTo(e) <= r)
                .filter(this::inFov)
                .min(Comparator.comparingDouble(e -> mc.player.distanceTo(e)))
                .orElse(null);
    }

    private boolean inFov(LivingEntity target) {
        float f = fov.getFloat();
        if (f >= 360f) return true;
        double dx = target.getX() - mc.player.getX();
        double dz = target.getZ() - mc.player.getZ();
        float targetYaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        float delta = Math.abs(MathHelper.wrapDegrees(targetYaw - mc.player.getYaw()));
        return delta <= f / 2f;
    }
}
