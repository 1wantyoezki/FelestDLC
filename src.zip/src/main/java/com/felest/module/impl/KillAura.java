package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class KillAura extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting range = new Setting("Дистанция", 3.0f, 2.0f, 4.5f, 0.1f);
    public final Setting fov = new Setting("FOV", 360f, 0f, 360f, 5f);
    public final Setting rotation = new Setting("Ротация", "SpookyTime", "SpookyTime", "MixerGrief");
    public final Setting smoothness = new Setting("Плавность", 0.18f, 0.05f, 0.5f, 0.01f);
    public final Setting sprintReset = new Setting("Сброс спринта", "Легит", "Легит", "Без сброса");
    public final Setting onlyCrits = new Setting("Только криты", false);
    public final Setting smartCrits = new Setting("Умные криты", false);

    public boolean silentActive = false;
    public float silentYaw = 0f;
    public float silentPitch = 0f;
    public float serverYaw = 0f;
    public float serverPitch = 0f;
    public float realYaw = 0f;
    public float realPitch = 0f;

    private float smoothYaw = 0f;
    private float smoothPitch = 0f;
    private boolean hasSmooth = false;
    private int sprintTicks = 0;
    private boolean wasSprinting = false;

    private double groundY = 0;
    private double peakY = 0;
    private double midFallY = -999;
    private boolean wasFalling = false;
    private boolean hasHitThisJump = false;

    public KillAura() {
        super("KillAura", Category.Combat);
        addSetting(range);
        addSetting(fov);
        addSetting(rotation);
        addSetting(smoothness);
        addSetting(sprintReset);
        addSetting(onlyCrits);
        addSetting(smartCrits);
    }

    @Override
    public void onEnable() {
        resetJumpState();
        hasSmooth = false;
        silentActive = false;
    }

    @Override
    public void onDisable() {
        resetJumpState();
        // НЕ выключаем silent сразу — даём плавно вернуться (см. tick)
        if (mc.player != null && wasSprinting) {
            mc.player.setSprinting(true);
            mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_SPRINTING));
            wasSprinting = false;
        }
        sprintTicks = 0;
    }

    private void resetJumpState() {
        if (mc.player != null) {
            groundY = mc.player.getY();
            peakY = groundY;
        }
        midFallY = -999;
        wasFalling = false;
        hasHitThisJump = false;
    }

    // Вызывается КАЖДЫЙ тик из FelestDLC, даже когда модуль выключен —
    // чтобы плавно вернуть экран к реальным углам игрока.
    public void tickAlways() {
        if (mc.player == null) return;

        if (!isEnabled()) {
            // Плавный возврат к настоящим углам
            if (silentActive) {
                smoothYaw = lerpAngle(smoothYaw, mc.player.getYaw(), 0.2f);
                smoothPitch = lerpAngle(smoothPitch, mc.player.getPitch(), 0.2f);
                silentYaw = smoothYaw;
                silentPitch = smoothPitch;

                float dy = Math.abs(wrap(mc.player.getYaw() - smoothYaw));
                float dp = Math.abs(mc.player.getPitch() - smoothPitch);
                if (dy < 0.5f && dp < 0.5f) {
                    silentActive = false;
                }
            }
            return;
        }

        // Модуль включён — работает логика
        onUpdateTick();
    }

    private void onUpdateTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        if (sprintTicks > 0) {
            sprintTicks--;
            if (sprintTicks == 0 && wasSprinting) {
                mc.player.setSprinting(true);
                mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_SPRINTING));
                wasSprinting = false;
            }
        }

        updateJumpTracking();

        LivingEntity target = findTarget();

        if (target == null) {
            // Плавный возврат к настоящим углам
            smoothYaw = lerpAngle(smoothYaw, mc.player.getYaw(), 0.2f);
            smoothPitch = lerpAngle(smoothPitch, mc.player.getPitch(), 0.2f);
            silentYaw = smoothYaw;
            silentPitch = smoothPitch;

            float dy = Math.abs(wrap(mc.player.getYaw() - smoothYaw));
            float dp = Math.abs(mc.player.getPitch() - smoothPitch);
            if (dy < 0.5f && dp < 0.5f) {
                silentActive = false;
            } else {
                silentActive = true;
            }
            return;
        }

        // Центр тела — середина высоты цели
        double tx = target.getX();
        double ty = target.getY() + target.getHeight() * 0.5;
        double tz = target.getZ();

        double dx = tx - mc.player.getX();
        double dy = ty - mc.player.getEyeY();
        double dz = tz - mc.player.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);

        float targetYaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        float targetPitch = (float)-Math.toDegrees(Math.atan2(dy, dist));

        if (!hasSmooth) {
            smoothYaw = mc.player.getYaw();
            smoothPitch = mc.player.getPitch();
            hasSmooth = true;
        }

        float lerpSpeed = smoothness.getFloat();
        // На близкой дистанции — медленнее, чтобы не уходило в сторону
        if (dist < 2.5) lerpSpeed *= 0.6f;

        String rot = rotation.getString();
        if (rot.equals("SpookyTime")) {
            smoothYaw = lerpAngle(smoothYaw, targetYaw, lerpSpeed);
            smoothPitch = lerpAngle(smoothPitch, targetPitch, lerpSpeed);
            silentYaw = smoothYaw;
            silentPitch = smoothPitch;
        } else {
            smoothYaw = lerpAngle(smoothYaw, targetYaw, 0.6f);
            smoothPitch = lerpAngle(smoothPitch, targetPitch, 0.6f);
            silentYaw = smoothYaw;
            silentPitch = smoothPitch;
        }

        silentActive = true;

        // КРИТЫ
        boolean canHit = false;
        if (onlyCrits.getBool()) {
            if (wasFalling && !hasHitThisJump && mc.player.getY() <= midFallY) canHit = true;
        } else if (smartCrits.getBool()) {
            if (mc.player.isOnGround()) {
                if (mc.player.getAttackCooldownProgress(0.0f) >= 1.0f) canHit = true;
            } else if (wasFalling && !hasHitThisJump && mc.player.getY() <= midFallY) {
                canHit = true;
            }
        } else {
            if (mc.player.getAttackCooldownProgress(0.0f) >= 1.0f) canHit = true;
        }

        if (canHit) {
            if (sprintReset.getString().equals("Легит") && mc.player.isSprinting()) {
                wasSprinting = true;
                mc.player.setSprinting(false);
                mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
                sprintTicks = 2;
            }

            mc.interactionManager.attackEntity(mc.player, target);
            mc.player.swingHand(Hand.MAIN_HAND);
            hasHitThisJump = true;
        }
    }

    @Override
    public void onUpdate() {
        // логика в tickAlways()
    }

    private float wrap(float deg) {
        deg = deg % 360f;
        if (deg >= 180f) deg -= 360f;
        if (deg < -180f) deg += 360f;
        return deg;
    }

    private float lerpAngle(float current, float target, float speed) {
        float delta = ((target - current + 540) % 360) - 180;
        return current + delta * speed;
    }

    private void updateJumpTracking() {
        double y = mc.player.getY();
        double vy = mc.player.getVelocity().y;

        if (mc.player.isOnGround()) {
            groundY = y;
            peakY = y;
            midFallY = -999;
            wasFalling = false;
            hasHitThisJump = false;
        } else {
            if (vy > 0) {
                peakY = Math.max(peakY, y);
                wasFalling = false;
            } else if (vy < 0) {
                if (!wasFalling) {
                    wasFalling = true;
                    midFallY = (groundY + peakY) / 2.0;
                }
            }
        }
    }

    private LivingEntity findTarget() {
        List<Entity> entities = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) entities.add(e);

        float r = range.getFloat();
        return entities.stream()
                .filter(e -> e instanceof LivingEntity)
                .map(e -> (LivingEntity) e)
                .filter(e -> e != mc.player)
                .filter(LivingEntity::isAlive)
                .filter(e -> mc.player.distanceTo(e) <= r)
                .filter(this::inFov)
                .min(Comparator.comparingDouble(e -> mc.player.distanceTo(e)))
                .orElse(null);
    }

    private boolean inFov(LivingEntity target) {
        float f = fov.getFloat();
        if (f >= 360f) return true;
        double dx = target.getX() - mc.player.getX();
        double dz = target.getZ() - mc.player.getZ();
        float targetYaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        float delta = Math.abs(MathHelper.wrapDegrees(targetYaw - mc.player.getYaw()));
        return delta <= f / 2f;
    }
}
