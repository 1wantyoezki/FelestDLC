package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;

public class KillAura extends Module {

    public final Setting range = new Setting("Дистанция", 3.0f, 2.0f, 4.5f, 0.1f);
    public final Setting fov = new Setting("FOV", 360f, 0f, 360f, 5f);
    public final Setting onlyCrits = new Setting("Только криты", false);
    public final Setting smartCrits = new Setting("Умные криты", false);

    public KillAura() {
        super("KillAura", Category.Combat);
        addSetting(range);
        addSetting(fov);
        addSetting(onlyCrits);
        addSetting(smartCrits);
    }

    @Override
    public void onUpdate() {
        // Логика позже
    }
}
