package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

public class KillAura extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final Random random = new Random();

    public final Setting rotation = new Setting("Ротация", "SpookyTime", "SpookyTime", "HolyTime", "MixerGrief");
    public final Setting behavior = new Setting("Поведение", "Таргет", "Таргет", "Свободный", "Незаметный");
    public final Setting sprintReset = new Setting("Сброс спринта", "Легитный", "Легитный", "Без сброса");
    public final Setting range = new Setting("Дистанция", 3.0f, 2.0f, 4.0f, 0.1f);
    public final Setting onlyCrits = new Setting("Только криты", false);
    public final Setting smartCrits = new Setting("Умные криты", false);

    // Серверные углы (то, что видит сервер)
    private float silentYaw = 0f;
    private float silentPitch = 0f;
    // Сглаживание (плавный доворот)
    private float smoothYaw = 0f;
    private float smoothPitch = 0f;
    private int sprintTicks = 0;
    private boolean wasSprinting = false;
    private int jitterTicks = 0;
    private float jitterOffset = 0f;

    public KillAura() {
        super("KillAura", Category.Combat);
        addSetting(rotation);
        addSetting(behavior);
        addSetting(sprintReset);
        addSetting(range);
        addSetting(onlyCrits);
        addSetting(smartCrits);
    }

    @Override
    public void onEnable() {
        if (mc.player != null) {
            silentYaw = mc.player.getYaw();
            silentPitch = mc.player.getPitch();
            smoothYaw = silentYaw;
            smoothPitch = silentPitch;
        }
        sprintTicks = 0;
        wasSprinting = false;
        jitterTicks = 0;
    }

    @Override
    public void onDisable() {
        if (mc.player != null && wasSprinting) {
            mc.player.setSprinting(true);
            mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_SPRINTING));
            wasSprinting = false;
        }
        sprintTicks = 0;
        jitterTicks = 0;
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        if (sprintTicks > 0) {
            sprintTicks--;
            if (sprintTicks == 0 && wasSprinting) {
                mc.player.setSprinting(true);
                mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_SPRINTING));
                wasSprinting = false;
            }
        }

        LivingEntity target = findTarget();
        if (target == null) {
            // Возвращаем серверный угол к клиентскому
            silentYaw = mc.player.getYaw();
            silentPitch = mc.player.getPitch();
            smoothYaw = silentYaw;
            smoothPitch = silentPitch;
            return;
        }

        boolean inAir = !mc.player.isOnGround();
        boolean falling = mc.player.fallDistance > 0.0f;
        boolean canCrit = inAir && falling;
        boolean cooldownReady = mc.player.getAttackCooldownProgress(0.0f) >= 1.0f;

        if (!cooldownReady) return;
        if (smartCrits.getBool()) {
        } else if (onlyCrits.getBool()) {
            if (!canCrit) return;
        }

        // ===== СЧИТАЕМ ЦЕЛЕВЫЕ УГЛЫ =====
        double dx = target.getX() - mc.player.getX();
        double dy = target.getEyeY() - mc.player.getEyeY();
        double dz = target.getZ() - mc.player.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, dist));

        // ===== РОТАЦИИ =====
        String rot = rotation.getString();
        if (rot.equals("SpookyTime")) {
            // Плавно + лёгкий джиттер
            smoothYaw = lerpAngle(smoothYaw, targetYaw, 0.35f);
            smoothPitch = lerpAngle(smoothPitch, targetPitch, 0.35f);
            if (jitterTicks <= 0) {
                jitterTicks = 4 + random.nextInt(3);
                jitterOffset = (random.nextFloat() - 0.5f) * 1.2f;
            }
            jitterTicks--;
            silentYaw = smoothYaw + jitterOffset;
            silentPitch = smoothPitch;
        } else if (rot.equals("MixerGrief")) {
            // Резко, без плавности
            silentYaw = targetYaw;
            silentPitch = targetPitch;
            smoothYaw = targetYaw;
            smoothPitch = targetPitch;
        } else if (rot.equals("HolyTime")) {
            // Средне + минимальный джиттер
            smoothYaw = lerpAngle(smoothYaw, targetYaw, 0.6f);
            smoothPitch = lerpAngle(smoothPitch, targetPitch, 0.6f);
            if (jitterTicks <= 0) {
                jitterTicks = 6 + random.nextInt(4);
                jitterOffset = (random.nextFloat() - 0.5f) * 0.5f;
            }
            jitterTicks--;
            silentYaw = smoothYaw + jitterOffset;
            silentPitch = smoothPitch;
        }

        // === SILENT AIM: отправляем пакет с углом на цель ===
        // Клиентская камера (mc.player.getYaw/Pitch) не трогается вообще!
        mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                silentYaw, silentPitch, mc.player.isOnGround(), mc.player.horizontalCollision));

        // ===== АТАКА =====
        boolean wasSprint = mc.player.isSprinting();
        if (wasSprint) {
            mc.player.setSprinting(false);
            mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
        }

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);

        if (wasSprint && sprintReset.getString().equals("Легитный")) {
            wasSprinting = true;
            sprintTicks = 3;
        } else if (wasSprint) {
            mc.player.setSprinting(true);
            mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_SPRINTING));
        }
    }

    private float lerpAngle(float current, float target, float speed) {
        float delta = ((target - current + 540) % 360) - 180;
        return current + delta * speed;
    }

    private LivingEntity findTarget() {
        List<Entity> entities = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) entities.add(e);
        float r = range.getFloat();
        return entities.stream()
                .filter(e -> e instanceof LivingEntity)
                .map(e -> (LivingEntity) e)
                .filter(e -> e != mc.player)
                .filter(e -> !(e instanceof PlayerEntity))
                .filter(e -> mc.player.distanceTo(e) <= r)
                .filter(LivingEntity::isAlive)
                .min(Comparator.comparingDouble(e -> mc.player.distanceTo(e)))
                .orElse(null);
    }
}
