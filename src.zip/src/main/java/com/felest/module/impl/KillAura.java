package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class KillAura extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting rotation = new Setting("Ротация", "SpookyTime", "SpookyTime", "HolyTime", "MixerGrief");
    public final Setting behavior = new Setting("Поведение", "Таргет", "Таргет", "Свободный", "Незаметный");
    public final Setting sprintReset = new Setting("Сброс спринта", "Легитный", "Легитный", "Без сброса");
    public final Setting range = new Setting("Дистанция", 3.0f, 2.0f, 4.0f, 0.1f);
    public final Setting onlyCrits = new Setting("Только криты", false);
    public final Setting smartCrits = new Setting("Умные криты", false);

    private float serverYaw = 0f;
    private float serverPitch = 0f;
    private int sprintTicks = 0;
    private boolean wasSprinting = false;

    public KillAura() {
        super("KillAura", Category.Combat);
        addSetting(rotation);
        addSetting(behavior);
        addSetting(sprintReset);
        addSetting(range);
        addSetting(onlyCrits);
        addSetting(smartCrits);
    }

    @Override
    public void onEnable() {
        if (mc.player != null) {
            serverYaw = mc.player.getYaw();
            serverPitch = mc.player.getPitch();
        }
        sprintTicks = 0;
        wasSprinting = false;
    }

    @Override
    public void onDisable() {
        if (mc.player != null && wasSprinting) {
            mc.player.setSprinting(true);
            mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_SPRINTING));
            wasSprinting = false;
        }
        sprintTicks = 0;
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        if (sprintTicks > 0) {
            sprintTicks--;
            if (sprintTicks == 0 && wasSprinting) {
                mc.player.setSprinting(true);
                mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_SPRINTING));
                wasSprinting = false;
            }
        }

        LivingEntity target = findTarget();
        if (target == null) {
            serverYaw = mc.player.getYaw();
            serverPitch = mc.player.getPitch();
            return;
        }

        boolean inAir = !mc.player.isOnGround();
        boolean falling = mc.player.fallDistance > 0.0f;
        boolean canCrit = inAir && falling;
        boolean cooldownReady = mc.player.getAttackCooldownProgress(0.0f) >= 1.0f;

        if (!cooldownReady) return;

        if (smartCrits.getBool()) {
            // всегда по КД
        } else if (onlyCrits.getBool()) {
            if (!canCrit) return;
        }

        // Поворот
        String b = behavior.getString();
        if (b.equals("Таргет") || b.equals("Незаметный")) {
            double dx = target.getX() - mc.player.getX();
            double dy = target.getEyeY() - mc.player.getEyeY();
            double dz = target.getZ() - mc.player.getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);
            float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
            float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, dist));
            float speed = b.equals("Незаметный") ? 0.3f : 0.6f;
            serverYaw = lerpAngle(serverYaw, targetYaw, speed);
            serverPitch = lerpAngle(serverPitch, targetPitch, speed);
            mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(serverYaw, serverPitch, mc.player.isOnGround(), mc.player.horizontalCollision));
        }

        // === ФИКС СПЛЕША ===
        // Всегда сбрасываем спринт перед ударом
        boolean wasSprint = mc.player.isSprinting();
        if (wasSprint) {
            mc.player.setSprinting(false);
            mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
        }

        // Атака
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);

        // Возврат спринта
        if (wasSprint && sprintReset.getString().equals("Легитный")) {
            wasSprinting = true;
            sprintTicks = 3;
        } else if (wasSprint) {
            mc.player.setSprinting(true);
            mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_SPRINTING));
        }
    }

    private float lerpAngle(float current, float target, float speed) {
        float delta = ((target - current + 540) % 360) - 180;
        return current + delta * speed;
    }

    private LivingEntity findTarget() {
        List<Entity> entities = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) entities.add(e);
        float r = range.getFloat();
        return entities.stream()
                .filter(e -> e instanceof LivingEntity)
                .map(e -> (LivingEntity) e)
                .filter(e -> e != mc.player)
                .filter(e -> !(e instanceof PlayerEntity))
                .filter(e -> mc.player.distanceTo(e) <= r)
                .filter(LivingEntity::isAlive)
                .min(Comparator.comparingDouble(e -> mc.player.distanceTo(e)))
                .orElse(null);
    }
}
