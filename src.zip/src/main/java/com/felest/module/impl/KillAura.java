package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class KillAura extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting<String> rotation = new Setting<>("Ротация", "SpookyTime", "SpookyTime", "HolyTime", "MixerGrief");
    public final Setting<String> behavior = new Setting<>("Поведение", "Таргет", "Таргет", "Свободный", "Незаметный");
    public final Setting<String> sprintReset = new Setting<>("Сброс спринта", "Легитный", "Легитный", "Без сброса");
    public final Setting<Boolean> onlyCrits = new Setting<>("Только криты", false);
    public final Setting<Boolean> smartCrits = new Setting<>("Умные криты", false);

    private float serverYaw = 0f;
    private float serverPitch = 0f;

    public KillAura() {
        super("KillAura", Category.Combat);
        addSetting(rotation);
        addSetting(behavior);
        addSetting(sprintReset);
        addSetting(onlyCrits);
        addSetting(smartCrits);
    }

    @Override
    public void onEnable() {
        if (mc.player != null) {
            serverYaw = mc.player.getYaw();
            serverPitch = mc.player.getPitch();
        }
    }

    @Override
    public void onDisable() {}

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        if (smartCrits.getValue() && !onlyCrits.getValue()) {
            smartCrits.setValue(false);
        }

        LivingEntity target = findTarget();
        if (target == null) {
            serverYaw = mc.player.getYaw();
            serverPitch = mc.player.getPitch();
            return;
        }

        if (onlyCrits.getValue()) {
            if (mc.player.isOnGround()) return;
            if (mc.player.fallDistance <= 0.0f) return;
        }

        if (sprintReset.getValue().equals("Легитный")) {
            mc.player.setSprinting(false);
        }

        if (behavior.getValue().equals("Таргет") || behavior.getValue().equals("Незаметный")) {
            double dx = target.getX() - mc.player.getX();
            double dy = target.getEyeY() - mc.player.getEyeY();
            double dz = target.getZ() - mc.player.getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);
            float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
            float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, dist));

            float speed = behavior.getValue().equals("Незаметный") ? 0.3f : 0.6f;
            serverYaw = lerpAngle(serverYaw, targetYaw, speed);
            serverPitch = lerpAngle(serverPitch, targetPitch, speed);

            mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                    serverYaw, serverPitch, mc.player.isOnGround(), mc.player.horizontalCollision));
        }

        if (mc.player.getAttackCooldownProgress(0.0f) >= 1.0f) {
            mc.interactionManager.attackEntity(mc.player, target);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }

    private float lerpAngle(float current, float target, float speed) {
        float delta = ((target - current + 540) % 360) - 180;
        return current + delta * speed;
    }

    private LivingEntity findTarget() {
        List<Entity> entities = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) entities.add(e);

        return entities.stream()
                .filter(e -> e instanceof LivingEntity)
                .map(e -> (LivingEntity) e)
                .filter(e -> e != mc.player)
                .filter(e -> !(e instanceof PlayerEntity))
                .filter(e -> mc.player.distanceTo(e) <= 3.0f)
                .filter(LivingEntity::isAlive)
                .min(Comparator.comparingDouble(e -> mc.player.distanceTo(e)))
                .orElse(null);
    }
}
