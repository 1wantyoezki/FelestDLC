package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class KillAura extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting range = new Setting("Дистанция", 3.0f, 2.0f, 4.5f, 0.1f);
    public final Setting fov = new Setting("FOV", 360f, 0f, 360f, 5f);
    public final Setting onlyCrits = new Setting("Только криты", false);
    public final Setting smartCrits = new Setting("Умные криты", false);

    // Состояние прыжка/падения
    private double groundY = 0;
    private double peakY = 0;
    private double midFallY = -999;
    private boolean wasFalling = false;
    private boolean hasHitThisJump = false;

    public KillAura() {
        super("KillAura", Category.Combat);
        addSetting(range);
        addSetting(fov);
        addSetting(onlyCrits);
        addSetting(smartCrits);
    }

    @Override
    public void onEnable() { resetJumpState(); }

    @Override
    public void onDisable() { resetJumpState(); }

    private void resetJumpState() {
        if (mc.player != null) {
            groundY = mc.player.getY();
            peakY = groundY;
        }
        midFallY = -999;
        wasFalling = false;
        hasHitThisJump = false;
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        updateJumpTracking();

        LivingEntity target = findTarget();
        if (target == null) return;

        boolean canHit = false;

        if (onlyCrits.getBool()) {
            // Только криты — ждём середину падения, нигде больше не бьём
            if (wasFalling && !hasHitThisJump && mc.player.getY() <= midFallY) {
                canHit = true;
            }
        } else if (smartCrits.getBool()) {
            // Умные криты — с земли бьёт по КД, в прыжке ждёт середину падения
            if (mc.player.isOnGround()) {
                if (mc.player.getAttackCooldownProgress(0.0f) >= 1.0f) canHit = true;
            } else if (wasFalling && !hasHitThisJump && mc.player.getY() <= midFallY) {
                canHit = true;
            }
        } else {
            // Без критов — обычная аура по КД
            if (mc.player.getAttackCooldownProgress(0.0f) >= 1.0f) canHit = true;
        }

        if (canHit) {
            mc.interactionManager.attackEntity(mc.player, target);
            mc.player.swingHand(Hand.MAIN_HAND);
            hasHitThisJump = true;
        }
    }

    // Считаем groundY, peakY, midFallY — середину пути падения
    private void updateJumpTracking() {
        double y = mc.player.getY();
        double vy = mc.player.getVelocity().y;

        if (mc.player.isOnGround()) {
            groundY = y;
            peakY = y;
            midFallY = -999;
            wasFalling = false;
            hasHitThisJump = false;
        } else {
            if (vy > 0) {
                // Летим вверх — обновляем пик
                peakY = Math.max(peakY, y);
                wasFalling = false;
            } else if (vy < 0) {
                // Начали падать — запоминаем середину
                if (!wasFalling) {
                    wasFalling = true;
                    midFallY = (groundY + peakY) / 2.0;
                }
            }
        }
    }

    private LivingEntity findTarget() {
        List<Entity> entities = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) entities.add(e);

        float r = range.getFloat();
        return entities.stream()
                .filter(e -> e instanceof LivingEntity)
                .map(e -> (LivingEntity) e)
                .filter(e -> e != mc.player)
                .filter(LivingEntity::isAlive)
                .filter(e -> mc.player.distanceTo(e) <= r)
                .filter(this::inFov)
                .min(Comparator.comparingDouble(e -> mc.player.distanceTo(e)))
                .orElse(null);
    }

    private boolean inFov(LivingEntity target) {
        float f = fov.getFloat();
        if (f >= 360f) return true;
        double dx = target.getX() - mc.player.getX();
        double dz = target.getZ() - mc.player.getZ();
        float targetYaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        float delta = Math.abs(MathHelper.wrapDegrees(targetYaw - mc.player.getYaw()));
        return delta <= f / 2f;
    }
}
