package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;

public class MiniBoard extends Module {

    public final Setting scale = new Setting("Размер", 0.8f, 0.4f, 1.5f, 0.05f);
    public final Setting opacity = new Setting("Прозрачность", 100f, 0f, 100f, 5f);

    public MiniBoard() {
        super("MiniBoard", Category.Render);
        addSetting(scale);
        addSetting(opacity);
    }

    @Override
    public void onUpdate() {}
}
