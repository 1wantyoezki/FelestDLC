package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;

public class MiniChat extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting scale = new Setting("Размер", 0.8f, 0.5f, 1.5f, 0.05f);
    public final Setting opacity = new Setting("Видимость", 100f, 0f, 100f, 5f);
    public final Setting height = new Setting("Высота (строк)", 8f, 3f, 20f, 1f);

    private double oldOpacity = 1.0;

    public MiniChat() {
        super("MiniChat", Category.Render);
        addSetting(scale);
        addSetting(opacity);
        addSetting(height);
    }

    @Override
    public void onEnable() {
        if (mc.options != null) {
            oldOpacity = mc.options.getTextBackgroundOpacity().getValue();
        }
    }

    @Override
    public void onUpdate() {
        if (mc.options == null) return;
        // Применяем прозрачность фона (0 = полностью скрыт)
        mc.options.getTextBackgroundOpacity().setValue(opacity.getFloat() / 100.0);
    }

    @Override
    public void onDisable() {
        if (mc.options != null) {
            mc.options.getTextBackgroundOpacity().setValue(oldOpacity);
        }
    }

    public float getOpacity() {
        return opacity.getFloat();
    }
}
