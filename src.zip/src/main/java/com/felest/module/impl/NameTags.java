package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;

public class NameTags extends Module {

    public final Setting showHealth = new Setting("Показывать HP", true);
    public final Setting scale = new Setting("Масштаб", 1.5f, 0.5f, 3.0f, 0.1f);

    public NameTags() {
        super("NameTags", Category.Render);
        addSetting(showHealth);
        addSetting(scale);
    }

    @Override
    public void onUpdate() {}
}
