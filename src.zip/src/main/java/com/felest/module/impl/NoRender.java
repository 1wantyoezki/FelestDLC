package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;

public class NoRender extends Module {

    public final Setting rain = new Setting("Дождь", true);
    public final Setting thunder = new Setting("Гроза", true);
    public final Setting snow = new Setting("Снег", true);
    public final Setting sound = new Setting("Звуки погоды", true);
    public final Setting entityCull = new Setting("Скрывать сзади", false);

    public NoRender() {
        super("NoRender", Category.Render);
        addSetting(rain);
        addSetting(thunder);
        addSetting(snow);
        addSetting(sound);
        addSetting(entityCull);
    }

    @Override
    public void onUpdate() {}
}
