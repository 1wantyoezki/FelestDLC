package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;

public class NoRender extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting rain = new Setting("Дождь", true);
    public final Setting thunder = new Setting("Гроза", true);
    public final Setting snow = new Setting("Снег", true);
    public final Setting sound = new Setting("Звуки погоды", true);

    public NoRender() {
        super("NoRender", Category.Render);
        addSetting(rain);
        addSetting(thunder);
        addSetting(snow);
        addSetting(sound);
    }

    // Логика: проверяется в миксине WorldRendererMixin / ClientWorldMixin
    // Тут только настройки.
    @Override
    public void onUpdate() {}
}
