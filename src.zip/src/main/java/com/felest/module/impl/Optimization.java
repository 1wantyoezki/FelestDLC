package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;

public class Optimization extends Module {

    public final Setting particles = new Setting("Частицы", "Минимум", "Минимум", "Средне", "Все");
    public final Setting clouds = new Setting("Облака", "Выкл", "Выкл", "Быстрые", "Полные");

    // То, чего нет в настройках Minecraft
    public final Setting noFireOverlay = new Setting("Убрать огонь", true);       // не видно огня при горении
    public final Setting noWaterOverlay = new Setting("Убрать воду", false);      // не видно воды под водой
    public final Setting noBlockBreakParticles = new Setting("Без частиц копания", true);
    public final Setting noPotionParticles = new Setting("Без частиц зелий", true);
    public final Setting noHurtCam = new Setting("Без тряски от урона", true);    // камера не трясётся при уроне
    public final Setting noNausea = new Setting("Без тошноты", true);             // портал в ад не искажает
    public final Setting noVignette = new Setting("Без виньетки", true);          // затемнение по краям
    public final Setting noScoreboard = new Setting("Скрыть счёт", false);        // таблица справа
    public final Setting noToast = new Setting("Без уведомлений", true);          // не вылезают "получено достижение"
    public final Setting noTotemPop = new Setting("Без анимации тотема", true);   // экран не заливает при активации тотема
    public final Setting noArmorStand = new Setting("Скрыть стойки", false);      // армор-стенды не рендерятся
    public final Setting noItemFrame = new Setting("Скрыть рамки", false);        // рамки с предметами не рендерятся

    public Optimization() {
        super("Optimization", Category.Render);
        addSetting(particles);
        addSetting(clouds);
        addSetting(noFireOverlay);
        addSetting(noWaterOverlay);
        addSetting(noBlockBreakParticles);
        addSetting(noPotionParticles);
        addSetting(noHurtCam);
        addSetting(noNausea);
        addSetting(noVignette);
        addSetting(noScoreboard);
        addSetting(noToast);
        addSetting(noTotemPop);
        addSetting(noArmorStand);
        addSetting(noItemFrame);
    }

    @Override
    public void onUpdate() {}
}
