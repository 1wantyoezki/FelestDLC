package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;

public class Optimization extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting particles = new Setting("Частицы", "Минимум", "Минимум", "Средне", "Все");
    public final Setting clouds = new Setting("Облака", "Выкл", "Выкл", "Быстрые", "Полные");
    public final Setting fog = new Setting("Туман", true);

    public Optimization() {
        super("Optimization", Category.Render);
        addSetting(particles);
        addSetting(clouds);
        addSetting(fog);
    }

    @Override
    public void onUpdate() {
        if (mc.options == null) return;

        String p = particles.getString();
        if (p.equals("Минимум")) mc.options.getParticles().setValue(net.minecraft.client.option.ParticlesMode.MINIMAL);
        else if (p.equals("Средне")) mc.options.getParticles().setValue(net.minecraft.client.option.ParticlesMode.DECREASED);
        else mc.options.getParticles().setValue(net.minecraft.client.option.ParticlesMode.ALL);

        String c = clouds.getString();
        if (c.equals("Выкл")) mc.options.getCloudRenderMode().setValue(net.minecraft.client.option.CloudRenderMode.OFF);
        else if (c.equals("Быстрые")) mc.options.getCloudRenderMode().setValue(net.minecraft.client.option.CloudRenderMode.FAST);
        else mc.options.getCloudRenderMode().setValue(net.minecraft.client.option.CloudRenderMode.FANCY);
    }
}
