package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;

public class Optimization extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting particles = new Setting("Частицы", "Минимум", "Минимум", "Средне", "Все");
    public final Setting clouds = new Setting("Облака", "Выкл", "Выкл", "Быстрые", "Полные");
    public final Setting fog = new Setting("Туман", true);

    public Optimization() {
        super("Optimization", Category.Render);
        addSetting(particles);
        addSetting(clouds);
        addSetting(fog);
    }

    @Override
    public void onUpdate() {
        if (mc.options == null) return;
        // Упрощённо: ничего не трогаем через enum, только логируем что модуль работает.
        // В 1.21.4 ParticlesMode в другом пакете, сделаем фикс позже.
    }
}
