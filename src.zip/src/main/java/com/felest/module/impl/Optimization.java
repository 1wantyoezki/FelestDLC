package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;

public class Optimization extends Module {

    public final Setting particles = new Setting("Частицы", "Минимум", "Минимум", "Средне", "Все");
    public final Setting clouds = new Setting("Облака", "Выкл", "Выкл", "Быстрые", "Полные");

    // Рабочие настройки
    public final Setting noBlockBreakParticles = new Setting("Без частиц копания", true);
    public final Setting noPotionParticles = new Setting("Без частиц зелий", true);
    public final Setting noHurtCam = new Setting("Без тряски от урона", true);

    // Заглушки (пока не работают — оставлены для настроек)
    public final Setting noFireOverlay = new Setting("Убрать огонь", false);
    public final Setting noWaterOverlay = new Setting("Убрать воду", false);
    public final Setting noNausea = new Setting("Без тошноты", false);
    public final Setting noVignette = new Setting("Без виньетки", false);
    public final Setting noScoreboard = new Setting("Скрыть счёт", false);
    public final Setting noToast = new Setting("Без уведомлений", false);
    public final Setting noTotemPop = new Setting("Без анимации тотема", false);

    public Optimization() {
        super("Optimization", Category.Render);
        addSetting(particles);
        addSetting(clouds);
        addSetting(noBlockBreakParticles);
        addSetting(noPotionParticles);
        addSetting(noHurtCam);
        addSetting(noFireOverlay);
        addSetting(noWaterOverlay);
        addSetting(noNausea);
        addSetting(noVignette);
        addSetting(noScoreboard);
        addSetting(noToast);
        addSetting(noTotemPop);
    }

    @Override
    public void onUpdate() {}
}
