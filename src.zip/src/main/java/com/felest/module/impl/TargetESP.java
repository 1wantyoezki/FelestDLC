package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;

import java.awt.Color;

public class TargetESP extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting mode = new Setting("Режим", "Квадрат", "Квадрат", "Души");
    public final Setting rotation = new Setting("Скорость", 2.0f, 0.5f, 5.0f, 0.1f);
    public final Setting size = new Setting("Размер", 0.9f, 0.5f, 1.5f, 0.05f);
    public final Setting soulsCount = new Setting("Кол-во душ", 5f, 1f, 15f, 1f);
    public final Setting color = new Setting("Цвет", "Фиолетовый",
            "Фиолетовый", "Синий", "Зелёный", "Красный", "Серый", "Жёлтый", "Оранжевый");

    public LivingEntity currentTarget = null;
    private LivingEntity lastTarget = null;
    private long lastTargetTime = 0L;
    private static final long HIDE_MS = 4000L;

    // Плавные координаты центра цели (интерполяция)
    public double smoothX = 0, smoothY = 0, smoothZ = 0;
    public boolean hasSmooth = false;

    public TargetESP() {
        super("TargetESP", Category.Render);
        addSetting(mode);
        addSetting(rotation);
        addSetting(size);
        addSetting(soulsCount);
        addSetting(color);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) return;

        LivingEntity found = null;
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            Entity e = ((EntityHitResult) mc.crosshairTarget).getEntity();
            if (e instanceof LivingEntity && e != mc.player && e.isAlive()) {
                found = (LivingEntity) e;
            }
        }

        if (found != null) {
            lastTarget = found;
            lastTargetTime = System.currentTimeMillis();
            currentTarget = found;
        } else {
            if (lastTarget != null && System.currentTimeMillis() - lastTargetTime < HIDE_MS) {
                currentTarget = lastTarget;
            } else {
                currentTarget = null;
                lastTarget = null;
                hasSmooth = false;
            }
        }

        // Интерполируем позицию центра цели
        if (currentTarget != null) {
            double tx = currentTarget.getX();
            double ty = currentTarget.getY() + currentTarget.getHeight() / 2.0;
            double tz = currentTarget.getZ();

            if (!hasSmooth) {
                smoothX = tx; smoothY = ty; smoothZ = tz;
                hasSmooth = true;
            } else {
                // Плавное приближение (lerp)
                double lerp = 0.35;
                smoothX += (tx - smoothX) * lerp;
                smoothY += (ty - smoothY) * lerp;
                smoothZ += (tz - smoothZ) * lerp;
            }
        }
    }

    public Vec3d getSmoothPos() {
        return new Vec3d(smoothX, smoothY, smoothZ);
    }

    public int getAccentColor() {
        switch (color.getString()) {
            case "Фиолетовый": return new Color(160, 60, 220, 220).getRGB();
            case "Синий":      return new Color(60, 120, 220, 220).getRGB();
            case "Зелёный":    return new Color(60, 200, 100, 220).getRGB();
            case "Красный":    return new Color(220, 60, 60, 220).getRGB();
            case "Серый":      return new Color(150, 150, 160, 220).getRGB();
            case "Жёлтый":     return new Color(230, 210, 60, 220).getRGB();
            case "Оранжевый":  return new Color(240, 140, 40, 220).getRGB();
            default:           return new Color(160, 60, 220, 220).getRGB();
        }
    }
}
