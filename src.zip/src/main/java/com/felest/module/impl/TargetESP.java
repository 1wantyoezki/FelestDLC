package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;

import java.awt.Color;

public class TargetESP extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting rotation = new Setting("Скорость", 2.0f, 0.5f, 5.0f, 0.1f);
    public final Setting size = new Setting("Размер", 0.9f, 0.5f, 1.5f, 0.05f);
    public final Setting thickness = new Setting("Толщина", 3f, 1f, 8f, 0.5f);
    public final Setting ringWidth = new Setting("Толщина рамки", 0.3f, 0.1f, 0.6f, 0.05f);
    public final Setting color = new Setting("Цвет", "Фиолетовый",
            "Фиолетовый", "Синий", "Зелёный", "Красный", "Серый", "Жёлтый", "Оранжевый");

    public LivingEntity currentTarget = null;
    private LivingEntity lastTarget = null;
    private long lastTargetTime = 0L;
    private static final long HIDE_MS = 4000L;

    public TargetESP() {
        super("TargetESP", Category.Render);
        addSetting(rotation);
        addSetting(size);
        addSetting(thickness);
        addSetting(ringWidth);
        addSetting(color);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) return;

        LivingEntity found = null;
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            Entity e = ((EntityHitResult) mc.crosshairTarget).getEntity();
            if (e instanceof LivingEntity && e != mc.player && e.isAlive()) {
                found = (LivingEntity) e;
            }
        }

        if (found != null) {
            lastTarget = found;
            lastTargetTime = System.currentTimeMillis();
            currentTarget = found;
        } else {
            if (lastTarget != null && System.currentTimeMillis() - lastTargetTime < HIDE_MS) {
                currentTarget = lastTarget;
            } else {
                currentTarget = null;
                lastTarget = null;
            }
        }
    }

    // Точная позиция — без сглаживания, чтобы не дёргалось
    public Vec3d getTargetPos() {
        if (currentTarget == null) return Vec3d.ZERO;
        // Используем интерполированную позицию клиента (getLerpedPos)
        double x = net.minecraft.util.math.MathHelper.lerp(
                mc.getRenderTickCounter().getTickDelta(false), currentTarget.prevX, currentTarget.getX());
        double y = net.minecraft.util.math.MathHelper.lerp(
                mc.getRenderTickCounter().getTickDelta(false), currentTarget.prevY, currentTarget.getY())
                + currentTarget.getHeight() / 2.0;
        double z = net.minecraft.util.math.MathHelper.lerp(
                mc.getRenderTickCounter().getTickDelta(false), currentTarget.prevZ, currentTarget.getZ());
        return new Vec3d(x, y, z);
    }

    public int getAccentColor() {
        switch (color.getString()) {
            case "Фиолетовый": return new Color(160, 60, 220, 220).getRGB();
            case "Синий":      return new Color(60, 120, 220, 220).getRGB();
            case "Зелёный":    return new Color(60, 200, 100, 220).getRGB();
            case "Красный":    return new Color(220, 60, 60, 220).getRGB();
            case "Серый":      return new Color(150, 150, 160, 220).getRGB();
            case "Жёлтый":     return new Color(230, 210, 60, 220).getRGB();
            case "Оранжевый":  return new Color(240, 140, 40, 220).getRGB();
            default:           return new Color(160, 60, 220, 220).getRGB();
        }
    }
}
