package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

public class TriggerBot extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting range = new Setting("Дистанция", 3.0f, 2.0f, 4.0f, 0.1f);
    public final Setting delay = new Setting("Задержка", 50f, 0f, 300f, 10f);
    public final Setting onlyPlayers = new Setting("Только игроки", false);
    public final Setting onlyCrits = new Setting("Только криты", false);
    public final Setting smartCrits = new Setting("Умные криты", false);

    private long lastAttackTime = 0L;
    private boolean hasHitThisJump = false;

    public TriggerBot() {
        super("TriggerBot", Category.Combat);
        addSetting(range);
        addSetting(delay);
        addSetting(onlyPlayers);
        addSetting(onlyCrits);
        addSetting(smartCrits);
    }

    @Override
    public void onEnable() { hasHitThisJump = false; }

    @Override
    public void onDisable() { hasHitThisJump = false; }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        if (mc.player.isOnGround()) hasHitThisJump = false;

        HitResult hit = mc.crosshairTarget;
        if (hit == null || hit.getType() != HitResult.Type.ENTITY) return;

        Entity entity = ((EntityHitResult) hit).getEntity();
        if (!(entity instanceof LivingEntity)) return;
        if (entity == mc.player) return;
        if (onlyPlayers.getBool() && !(entity instanceof PlayerEntity)) return;

        LivingEntity target = (LivingEntity) entity;
        if (!target.isAlive()) return;
        if (mc.player.distanceTo(target) > range.getFloat()) return;
        if (mc.player.getAttackCooldownProgress(0.0f) < 1.0f) return;

        boolean inAir = !mc.player.isOnGround();
        boolean falling = mc.player.fallDistance > 0.05f;
        boolean canCrit = inAir && falling;

        boolean canHit = false;
        if (onlyCrits.getBool()) {
            if (canCrit && !hasHitThisJump) canHit = true;
        } else if (smartCrits.getBool()) {
            if (mc.player.isOnGround()) canHit = true;
            else if (canCrit && !hasHitThisJump) canHit = true;
        } else {
            canHit = true;
        }
        if (!canHit) return;

        long now = System.currentTimeMillis();
        if (now - lastAttackTime < (long) delay.getFloat()) return;

        // ★ КРИТИЧНО: синхронизируем текущую (Aimbot'ом наведённую) ротацию с сервером
        float curYaw = mc.player.getYaw();
        float curPitch = mc.player.getPitch();
        mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                curYaw, curPitch, mc.player.isOnGround(), mc.player.horizontalCollision));

        // Атака — сразу после rotation, в одном тике
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);

        lastAttackTime = now;
        hasHitThisJump = true;
    }
}
