package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class TriggerBot extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting range = new Setting("Дистанция", 2.8f, 2.0f, 4.0f, 0.1f);
    public final Setting fov = new Setting("FOV", 15f, 3f, 45f, 1f);
    public final Setting delay = new Setting("Задержка", 50f, 0f, 300f, 10f);
    public final Setting onlyPlayers = new Setting("Только игроки", false);
    public final Setting onlyCrits = new Setting("Только криты", false);
    public final Setting smartCrits = new Setting("Умные криты", false);

    private long lastAttackTime = 0L;

    private double groundY = 0;
    private double peakY = 0;
    private double midFallY = -999;
    private boolean wasFalling = false;
    private boolean hasHitThisJump = false;

    public TriggerBot() {
        super("TriggerBot", Category.Combat);
        addSetting(range);
        addSetting(fov);
        addSetting(delay);
        addSetting(onlyPlayers);
        addSetting(onlyCrits);
        addSetting(smartCrits);
    }

    @Override
    public void onEnable() {
        if (mc.player != null) { groundY = mc.player.getY(); peakY = groundY; }
        midFallY = -999;
        wasFalling = false;
        hasHitThisJump = false;
    }

    @Override
    public void onDisable() {
        midFallY = -999;
        wasFalling = false;
        hasHitThisJump = false;
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        updateJumpTracking();

        LivingEntity target = findTarget();
        if (target == null) return;

        if (!isLookingAt(target, fov.getFloat())) return;
        if (mc.player.distanceTo(target) > range.getFloat()) return;

        // КД удара должно быть готово всегда
        if (mc.player.getAttackCooldownProgress(0.0f) < 1.0f) return;

        boolean canHit = false;
        if (onlyCrits.getBool()) {
            if (wasFalling && !hasHitThisJump && mc.player.getY() <= midFallY) canHit = true;
        } else if (smartCrits.getBool()) {
            if (mc.player.isOnGround()) {
                canHit = true;
            } else if (wasFalling && !hasHitThisJump && mc.player.getY() <= midFallY) {
                canHit = true;
            }
        } else {
            canHit = true;
        }

        if (!canHit) return;

        long now = System.currentTimeMillis();
        if (now - lastAttackTime < (long) delay.getFloat()) return;

        // ВАЖНО: перед атакой синхронизируем rotation на сервер.
        // Иначе сервер считает, что мы смотрим в сторону, и отклоняет удар.
        Vec3d eye = mc.player.getEyePos();
        double dx = target.getX() - eye.x;
        double dy = (target.getY() + target.getHeight() / 2) - eye.y;
        double dz = target.getZ() - eye.z;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float targetYaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        float targetPitch = (float)-Math.toDegrees(Math.atan2(dy, dist));

        // Плавно доводим клиент до угла цели (если ещё не там)
        float oldYaw = mc.player.getYaw();
        float oldPitch = mc.player.getPitch();
        mc.player.setYaw(targetYaw);
        mc.player.setPitch(targetPitch);

        // Отправляем rotation-пакет
        mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                targetYaw, targetPitch, mc.player.isOnGround(), mc.player.horizontalCollision));

        // Спринт-ресет — чтобы удар проходил чище
        boolean wasSprinting = mc.player.isSprinting();
        if (wasSprinting) {
            mc.player.setSprinting(false);
            mc.player.networkHandler.sendPacket(new net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket(
                    mc.player, net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket.Mode.STOP_SPRINTING));
        }

        // Атака
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);

        // Возвращаем клиентские углы обратно (чтобы камера не дёргалась)
        // Впрочем, Aimbot всё равно повернёт их в правильную сторону, так что оставляем как есть.

        if (wasSprinting) {
            mc.player.setSprinting(true);
            mc.player.networkHandler.sendPacket(new net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket(
                    mc.player, net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket.Mode.START_SPRINTING));
        }

        lastAttackTime = now;
        hasHitThisJump = true;
    }

    private boolean isLookingAt(LivingEntity target, float fovDeg) {
        Vec3d eye = mc.player.getEyePos();
        double dx = target.getX() - eye.x;
        double dy = (target.getY() + target.getHeight() / 2) - eye.y;
        double dz = target.getZ() - eye.z;
        double dist = Math.sqrt(dx * dx + dz * dz);

        float targetYaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        float targetPitch = (float)-Math.toDegrees(Math.atan2(dy, dist));

        float yawDiff = Math.abs(wrap(mc.player.getYaw() - targetYaw));
        float pitchDiff = Math.abs(mc.player.getPitch() - targetPitch);

        return yawDiff <= fovDeg && pitchDiff <= fovDeg;
    }

    private float wrap(float deg) {
        deg = deg % 360f;
        if (deg >= 180f) deg -= 360f;
        if (deg < -180f) deg += 360f;
        return deg;
    }

    private LivingEntity findTarget() {
        List<Entity> entities = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) entities.add(e);

        return entities.stream()
                .filter(e -> e instanceof LivingEntity)
                .map(e -> (LivingEntity) e)
                .filter(e -> e != mc.player)
                .filter(LivingEntity::isAlive)
                .filter(e -> !onlyPlayers.getBool() || e instanceof PlayerEntity)
                .min(Comparator.comparingDouble(e -> mc.player.distanceTo(e)))
                .orElse(null);
    }

    private void updateJumpTracking() {
        double y = mc.player.getY();
        double vy = mc.player.getVelocity().y;

        if (mc.player.isOnGround()) {
            groundY = y;
            peakY = y;
            midFallY = -999;
            wasFalling = false;
            hasHitThisJump = false;
        } else {
            if (vy > 0) {
                peakY = Math.max(peakY, y);
                wasFalling = false;
            } else if (vy < 0) {
                if (!wasFalling) {
                    wasFalling = true;
                    midFallY = (groundY + peakY) / 2.0;
                }
            }
        }
    }
}
