package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class TriggerBot extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting range = new Setting("Дистанция", 3.0f, 2.0f, 4.0f, 0.1f);
    public final Setting delay = new Setting("Задержка", 50f, 0f, 300f, 10f);
    public final Setting onlyPlayers = new Setting("Только игроки", false);
    public final Setting onlyCrits = new Setting("Только криты", false);
    public final Setting smartCrits = new Setting("Умные криты", false);

    private long lastAttackTime = 0L;

    // Отслеживание падения
    private double fallStartY = 0;
    private boolean wasInAir = false;
    private boolean hasHitInThisFall = false;

    public TriggerBot() {
        super("TriggerBot", Category.Combat);
        addSetting(range);
        addSetting(delay);
        addSetting(onlyPlayers);
        addSetting(onlyCrits);
        addSetting(smartCrits);
    }

    @Override
    public void onEnable() {
        fallStartY = mc.player != null ? mc.player.getY() : 0;
        wasInAir = false;
        hasHitInThisFall = false;
    }

    @Override
    public void onDisable() {
        wasInAir = false;
        hasHitInThisFall = false;
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        updateFallTracking();

        LivingEntity target = findTarget();
        if (target == null) return;
        if (mc.player.distanceTo(target) > range.getFloat()) return;

        boolean onGround = mc.player.isOnGround();
        boolean falling = !onGround && mc.player.fallDistance > 0.05f;
        boolean cooldownReady = mc.player.getAttackCooldownProgress(0.0f) >= 1.0f;

        // Середина падения — проверяем что уже пролетели половину от старта до текущей точки
        // Не знаем где земля, поэтому используем "половину пройденного пути" — как только
        // пролетели больше 0.5 блока и мы в падении — это и есть середина
        boolean inMiddleOfFall = falling && mc.player.fallDistance > 0.5f;

        boolean canHit = false;
        if (smartCrits.getBool()) {
            // Умные криты:
            // - на земле — бьёт независимо от КД (в тайминг, т.е. когда захочет)
            // - в падении — на середине, независимо от КД, один раз за падение
            if (onGround) {
                canHit = true;
            } else if (inMiddleOfFall && !hasHitInThisFall) {
                canHit = true;
            }
        } else if (onlyCrits.getBool()) {
            // Только криты: только на середине падения, независимо от КД
            if (inMiddleOfFall && !hasHitInThisFall) {
                canHit = true;
            }
        } else {
            // Обычная аура: по КД
            if (cooldownReady) canHit = true;
        }

        if (!canHit) return;

        long now = System.currentTimeMillis();
        if (now - lastAttackTime < (long) delay.getFloat()) return;

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
        lastAttackTime = now;
        hasHitInThisFall = true;
    }

    private void updateFallTracking() {
        boolean inAir = !mc.player.isOnGround();

        if (!inAir) {
            // На земле — сбрасываем состояние падения
            wasInAir = false;
            hasHitInThisFall = false;
            fallStartY = mc.player.getY();
        } else {
            if (!wasInAir) {
                // Только что оторвались от земли
                wasInAir = true;
                fallStartY = mc.player.getY();
            }
        }
    }

    private LivingEntity findTarget() {
        List<Entity> entities = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) entities.add(e);
        return entities.stream()
                .filter(e -> e instanceof LivingEntity)
                .map(e -> (LivingEntity) e)
                .filter(e -> e != mc.player)
                .filter(LivingEntity::isAlive)
                .filter(e -> !onlyPlayers.getBool() || e instanceof PlayerEntity)
                .filter(e -> mc.player.distanceTo(e) <= range.getFloat())
                .min(Comparator.comparingDouble(e -> mc.player.distanceTo(e)))
                .orElse(null);
    }
}
