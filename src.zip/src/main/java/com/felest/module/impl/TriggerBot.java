package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

public class TriggerBot extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting range = new Setting("Дистанция", 3.0f, 2.0f, 4.5f, 0.1f);
    public final Setting delay = new Setting("Задержка", 50f, 0f, 300f, 10f);
    public final Setting onlyPlayers = new Setting("Только игроки", false);
    public final Setting onlyCrits = new Setting("Только криты", false);
    public final Setting smartCrits = new Setting("Умные криты", false);

    private long lastAttackTime = 0L;
    private double groundY = 0, peakY = 0, midFallY = -999;
    private boolean wasFalling = false;
    private boolean hasHitThisJump = false;

    public TriggerBot() {
        super("TriggerBot", Category.Combat);
        addSetting(range);
        addSetting(delay);
        addSetting(onlyPlayers);
        addSetting(onlyCrits);
        addSetting(smartCrits);
    }

    @Override
    public void onEnable() {
        if (mc.player != null) { groundY = mc.player.getY(); peakY = groundY; }
        midFallY = -999; wasFalling = false; hasHitThisJump = false;
    }

    @Override
    public void onDisable() {
        midFallY = -999; wasFalling = false; hasHitThisJump = false;
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        updateJumpTracking();

        // Работает по crosshair — как раньше
        HitResult hit = mc.crosshairTarget;
        if (hit == null || hit.getType() != HitResult.Type.ENTITY) return;

        Entity entity = ((EntityHitResult) hit).getEntity();
        if (!(entity instanceof LivingEntity)) return;
        if (entity == mc.player) return;
        if (onlyPlayers.getBool() && !(entity instanceof PlayerEntity)) return;

        LivingEntity target = (LivingEntity) entity;
        if (!target.isAlive()) return;
        if (mc.player.distanceTo(target) > range.getFloat()) return;

        boolean canHit = false;
        if (onlyCrits.getBool()) {
            if (wasFalling && !hasHitThisJump && mc.player.getY() <= midFallY) canHit = true;
        } else if (smartCrits.getBool()) {
            if (mc.player.isOnGround()) {
                if (mc.player.getAttackCooldownProgress(0.0f) >= 1.0f) canHit = true;
            } else if (wasFalling && !hasHitThisJump && mc.player.getY() <= midFallY) {
                canHit = true;
            }
        } else {
            if (mc.player.getAttackCooldownProgress(0.0f) >= 1.0f) canHit = true;
        }

        if (!canHit) return;

        long now = System.currentTimeMillis();
        if (now - lastAttackTime < (long) delay.getFloat()) return;

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
        lastAttackTime = now;
        hasHitThisJump = true;
    }

    private void updateJumpTracking() {
        double y = mc.player.getY();
        double vy = mc.player.getVelocity().y;

        if (mc.player.isOnGround()) {
            groundY = y; peakY = y; midFallY = -999;
            wasFalling = false; hasHitThisJump = false;
        } else {
            if (vy > 0) {
                peakY = Math.max(peakY, y);
                wasFalling = false;
            } else if (vy < 0) {
                if (!wasFalling) {
                    wasFalling = true;
                    midFallY = (groundY + peakY) / 2.0;
                }
            }
        }
    }
}
