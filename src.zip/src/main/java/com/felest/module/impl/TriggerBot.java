package com.felest.module.impl;

import com.felest.module.Category;
import com.felest.module.Module;
import com.felest.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

public class TriggerBot extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting range = new Setting("Дистанция", 3.0f, 2.0f, 4.0f, 0.1f);
    public final Setting delay = new Setting("Задержка", 50f, 0f, 300f, 10f);
    public final Setting smartCrit = new Setting("Умные криты", true);
    public final Setting onlyPlayers = new Setting("Только игроки", false);

    private long lastAttackTime = 0L;

    public TriggerBot() {
        super("TriggerBot", Category.Combat);
        addSetting(range);
        addSetting(delay);
        addSetting(smartCrit);
        addSetting(onlyPlayers);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        HitResult hit = mc.crosshairTarget;
        if (hit == null || hit.getType() != HitResult.Type.ENTITY) return;

        Entity entity = ((EntityHitResult) hit).getEntity();
        if (!(entity instanceof LivingEntity)) return;
        if (entity == mc.player) return;
        if (onlyPlayers.getBool() && !(entity instanceof PlayerEntity)) return;

        LivingEntity target = (LivingEntity) entity;
        if (!target.isAlive()) return;
        if (mc.player.distanceTo(target) > range.getFloat()) return;

        if (mc.player.getAttackCooldownProgress(0.0f) < 1.0f) return;

        if (smartCrit.getBool()) {
            // Если в воздухе — ждём падения (velocity Y < 0)
            if (!mc.player.isOnGround()) {
                if (mc.player.getVelocity().y >= 0) return;
            }
        }

        long now = System.currentTimeMillis();
        if (now - lastAttackTime < (long) delay.getFloat()) return;

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
        lastAttackTime = now;
    }
}
