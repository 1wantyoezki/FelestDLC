package com.felest.render;

import com.felest.FelestDLC;
import com.felest.module.impl.Arrows;
import com.felest.util.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

public class ArrowsRenderer {
    public static void register() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            if (FelestDLC.moduleManager == null) return;
            Arrows arrows = (Arrows) FelestDLC.moduleManager.getModuleByName("Arrows");
            if (arrows == null || !arrows.isEnabled()) return;

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null) return;
            if (mc.options.hudHidden) return;

            int cx = mc.getWindow().getScaledWidth() / 2;
            int cy = mc.getWindow().getScaledHeight() / 2;

            int color = arrows.getColor();
            float radius = arrows.radius.getFloat();
            float size = arrows.size.getFloat();
            String styleStr = arrows.style.getString();
            float thickness = 1.5f * size;

            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof PlayerEntity)) continue;
                if (e == mc.player) continue;
                if (!e.isAlive()) continue;

                double dx = e.getX() - mc.player.getX();
                double dz = e.getZ() - mc.player.getZ();
                float angleToTarget = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
                float delta = MathHelper.wrapDegrees(angleToTarget - mc.player.getYaw());

                double rad = Math.toRadians(delta - 90);
                float ax = cx + (float)(Math.cos(rad) * radius);
                float ay = cy + (float)(Math.sin(rad) * radius);

                switch (styleStr) {
                    case "Указатель": drawPointer(context, ax, ay, delta, size, color, thickness); break;
                    case "Точка":     RenderUtil.circle(context, ax, ay, 4f * size, color); break;
                    default:          drawArrow(context, ax, ay, delta, size, color, thickness); break;
                }

                if (arrows.showDistance.getBool()) {
                    int dist = (int) mc.player.distanceTo(e);
                    String text = dist + "m";
                    int tw = mc.textRenderer.getWidth(text);
                    float tx = ax + (float)(Math.cos(rad) * 16);
                    float ty = ay + (float)(Math.sin(rad) * 16);
                    context.drawTextWithShadow(mc.textRenderer, text, (int)tx - tw / 2, (int)ty - 4, color);
                }
            }
        });
    }

    private static void drawArrow(DrawContext ctx, float cx, float cy, float angleDeg, float size, int color, float thickness) {
        float a = (float) Math.toRadians(angleDeg);
        float len = 9f * size;
        float wid = 5f * size;

        float tipX = cx + (float)(Math.sin(a) * len);
        float tipY = cy - (float)(Math.cos(a) * len);
        float backX = cx - (float)(Math.sin(a) * len * 0.4f);
        float backY = cy + (float)(Math.cos(a) * len * 0.4f);
        float leftX = backX + (float)(Math.cos(a) * wid);
        float leftY = backY + (float)(Math.sin(a) * wid);
        float rightX = backX - (float)(Math.cos(a) * wid);
        float rightY = backY - (float)(Math.sin(a) * wid);

        RenderUtil.smoothLine(ctx, tipX, tipY, leftX, leftY, thickness, color);
        RenderUtil.smoothLine(ctx, tipX, tipY, rightX, rightY, thickness, color);
        RenderUtil.smoothLine(ctx, leftX, leftY, rightX, rightY, thickness, color);
    }

    private static void drawPointer(DrawContext ctx, float cx, float cy, float angleDeg, float size, int color, float thickness) {
        float a = (float) Math.toRadians(angleDeg);
        float len = 10f * size;

        float tipX = cx + (float)(Math.sin(a) * len);
        float tipY = cy - (float)(Math.cos(a) * len);
        float leftX = cx + (float)(Math.sin(a - 0.7) * len * 0.75f);
        float leftY = cy - (float)(Math.cos(a - 0.7) * len * 0.75f);
        float rightX = cx + (float)(Math.sin(a + 0.7) * len * 0.75f);
        float rightY = cy - (float)(Math.cos(a + 0.7) * len * 0.75f);

        RenderUtil.smoothLine(ctx, tipX, tipY, leftX, leftY, thickness, color);
        RenderUtil.smoothLine(ctx, tipX, tipY, rightX, rightY, thickness, color);
    }
}
