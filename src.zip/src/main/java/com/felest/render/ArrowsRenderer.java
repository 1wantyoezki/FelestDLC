package com.felest.render;

import com.felest.FelestDLC;
import com.felest.module.impl.Arrows;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

public class ArrowsRenderer {
    public static void register() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            if (FelestDLC.moduleManager == null) return;
            Arrows arrows = (Arrows) FelestDLC.moduleManager.getModuleByName("Arrows");
            if (arrows == null || !arrows.isEnabled()) return;

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null) return;
            if (mc.options.hudHidden) return;

            int screenW = mc.getWindow().getScaledWidth();
            int screenH = mc.getWindow().getScaledHeight();
            int centerX = screenW / 2;
            int centerY = screenH / 2;

            int color = arrows.getColor();
            float radius = arrows.radius.getFloat();
            float size = arrows.size.getFloat();
            String styleStr = arrows.style.getString();

            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof PlayerEntity)) continue;
                if (e == mc.player) continue;
                if (!e.isAlive()) continue;

                double dx = e.getX() - mc.player.getX();
                double dz = e.getZ() - mc.player.getZ();
                float angleToTarget = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
                float delta = MathHelper.wrapDegrees(angleToTarget - mc.player.getYaw());

                double rad = Math.toRadians(delta - 90);
                float arrowX = centerX + (float)(Math.cos(rad) * radius);
                float arrowY = centerY + (float)(Math.sin(rad) * radius);

                switch (styleStr) {
                    case "Указатель": drawPointer(context, arrowX, arrowY, delta, size, color); break;
                    case "Точка":     drawDot(context, arrowX, arrowY, size, color); break;
                    default:          drawArrow(context, arrowX, arrowY, delta, size, color); break;
                }

                if (arrows.showDistance.getBool()) {
                    int dist = (int) mc.player.distanceTo(e);
                    String text = dist + "m";
                    int tw = mc.textRenderer.getWidth(text);
                    float tx = arrowX + (float)(Math.cos(rad) * 14);
                    float ty = arrowY + (float)(Math.sin(rad) * 14);
                    context.drawTextWithShadow(mc.textRenderer, text, (int)tx - tw / 2, (int)ty - 4, color);
                }
            }
        });
    }

    // Стрела (треугольник)
    private static void drawArrow(DrawContext context, float cx, float cy, float angleDeg, float size, int color) {
        float a = (float) Math.toRadians(angleDeg);
        float len = 8f * size;
        float wid = 5f * size;

        float tipX = cx + (float)(Math.sin(a) * len);
        float tipY = cy - (float)(Math.cos(a) * len);
        float backX = cx - (float)(Math.sin(a) * len * 0.5f);
        float backY = cy + (float)(Math.cos(a) * len * 0.5f);
        float leftX = backX + (float)(Math.cos(a) * wid);
        float leftY = backY + (float)(Math.sin(a) * wid);
        float rightX = backX - (float)(Math.cos(a) * wid);
        float rightY = backY - (float)(Math.sin(a) * wid);

        drawLine(context, tipX, tipY, leftX, leftY, color, 2);
        drawLine(context, tipX, tipY, rightX, rightY, color, 2);
        drawLine(context, leftX, leftY, rightX, rightY, color, 2);
    }

    // Указатель (галочка >) — две линии, без основания
    private static void drawPointer(DrawContext context, float cx, float cy, float angleDeg, float size, int color) {
        float a = (float) Math.toRadians(angleDeg);
        float len = 9f * size;
        float wid = 6f * size;

        // Вершина смотрит на цель
        float tipX = cx + (float)(Math.sin(a) * len);
        float tipY = cy - (float)(Math.cos(a) * len);
        // Задние точки
        float leftX = cx + (float)(Math.sin(a - 0.6) * len * 0.7f);
        float leftY = cy - (float)(Math.cos(a - 0.6) * len * 0.7f);
        float rightX = cx + (float)(Math.sin(a + 0.6) * len * 0.7f);
        float rightY = cy - (float)(Math.cos(a + 0.6) * len * 0.7f);

        drawLine(context, tipX, tipY, leftX, leftY, color, 2);
        drawLine(context, tipX, tipY, rightX, rightY, color, 2);
    }

    // Точка (кружок) — просто жирная точка
    private static void drawDot(DrawContext context, float cx, float cy, float size, int color) {
        int r = (int)(3f * size);
        // Рисуем залитый круг из квадратиков
        for (int x = -r; x <= r; x++) {
            for (int y = -r; y <= r; y++) {
                if (x * x + y * y <= r * r) {
                    context.fill((int)cx + x, (int)cy + y, (int)cx + x + 1, (int)cy + y + 1, color);
                }
            }
        }
        // Обводка снаружи (контур)
        for (int i = 0; i < 360; i += 10) {
            double rad = Math.toRadians(i);
            int ox = (int)(Math.cos(rad) * (r + 2));
            int oy = (int)(Math.sin(rad) * (r + 2));
            context.fill((int)cx + ox, (int)cy + oy, (int)cx + ox + 1, (int)cy + oy + 1, color);
        }
    }

    private static void drawLine(DrawContext context, float x1, float y1, float x2, float y2, int color, int thickness) {
        int steps = (int) Math.max(Math.abs(x2 - x1), Math.abs(y2 - y1));
        if (steps < 1) steps = 1;
        for (int i = 0; i <= steps; i++) {
            float t = (float) i / steps;
            float px = x1 + (x2 - x1) * t;
            float py = y1 + (y2 - y1) * t;
            context.fill((int)px - thickness, (int)py - thickness, (int)px + thickness, (int)py + thickness, color);
        }
    }
}
