package com.felest.render;

import com.felest.FelestDLC;
import com.felest.module.impl.Arrows;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

public class ArrowsRenderer {
    public static void register() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            if (FelestDLC.moduleManager == null) return;
            Arrows arrows = (Arrows) FelestDLC.moduleManager.getModuleByName("Arrows");
            if (arrows == null || !arrows.isEnabled()) return;

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null) return;
            if (mc.options.hudHidden) return;

            int screenW = mc.getWindow().getScaledWidth();
            int screenH = mc.getWindow().getScaledHeight();
            int centerX = screenW / 2;
            int centerY = screenH / 2;

            int color = arrows.getColor();
            float radius = arrows.radius.getFloat();
            float size = arrows.size.getFloat();
            String styleStr = arrows.style.getString();

            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof PlayerEntity)) continue;
                if (e == mc.player) continue;
                if (!e.isAlive()) continue;

                double dx = e.getX() - mc.player.getX();
                double dz = e.getZ() - mc.player.getZ();
                float angleToTarget = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
                float delta = MathHelper.wrapDegrees(angleToTarget - mc.player.getYaw());

                double rad = Math.toRadians(delta - 90);
                float arrowX = centerX + (float)(Math.cos(rad) * radius);
                float arrowY = centerY + (float)(Math.sin(rad) * radius);

                switch (styleStr) {
                    case "Указатель": drawPointer(context, arrowX, arrowY, delta, size, color); break;
                    case "Точка":     drawDot(context, arrowX, arrowY, size, color); break;
                    default:          drawArrow(context, arrowX, arrowY, delta, size, color); break;
                }

                if (arrows.showDistance.getBool()) {
                    int dist = (int) mc.player.distanceTo(e);
                    String text = dist + "m";
                    int tw = mc.textRenderer.getWidth(text);
                    float tx = arrowX + (float)(Math.cos(rad) * 16);
                    float ty = arrowY + (float)(Math.sin(rad) * 16);
                    context.drawTextWithShadow(mc.textRenderer, text, (int)tx - tw / 2, (int)ty - 4, color);
                }
            }
        });
    }

    private static void drawArrow(DrawContext context, float cx, float cy, float angleDeg, float size, int color) {
        float a = (float) Math.toRadians(angleDeg);
        float len = 9f * size;
        float wid = 5f * size;

        float tipX = cx + (float)(Math.sin(a) * len);
        float tipY = cy - (float)(Math.cos(a) * len);
        float backX = cx - (float)(Math.sin(a) * len * 0.4f);
        float backY = cy + (float)(Math.cos(a) * len * 0.4f);
        float leftX = backX + (float)(Math.cos(a) * wid);
        float leftY = backY + (float)(Math.sin(a) * wid);
        float rightX = backX - (float)(Math.cos(a) * wid);
        float rightY = backY - (float)(Math.sin(a) * wid);

        drawSmoothLine(context, tipX, tipY, leftX, leftY, color);
        drawSmoothLine(context, tipX, tipY, rightX, rightY, color);
        drawSmoothLine(context, leftX, leftY, rightX, rightY, color);
    }

    private static void drawPointer(DrawContext context, float cx, float cy, float angleDeg, float size, int color) {
        float a = (float) Math.toRadians(angleDeg);
        float len = 10f * size;

        float tipX = cx + (float)(Math.sin(a) * len);
        float tipY = cy - (float)(Math.cos(a) * len);
        float leftX = cx + (float)(Math.sin(a - 0.7) * len * 0.75f);
        float leftY = cy - (float)(Math.cos(a - 0.7) * len * 0.75f);
        float rightX = cx + (float)(Math.sin(a + 0.7) * len * 0.75f);
        float rightY = cy - (float)(Math.cos(a + 0.7) * len * 0.75f);

        drawSmoothLine(context, tipX, tipY, leftX, leftY, color);
        drawSmoothLine(context, tipX, tipY, rightX, rightY, color);
    }

    private static void drawDot(DrawContext context, float cx, float cy, float size, int color) {
        float r = 3.5f * size;
        int rInt = (int) Math.ceil(r) + 1;
        int a = (color >> 24) & 0xFF;
        int rr = (color >> 16) & 0xFF;
        int gg = (color >> 8) & 0xFF;
        int bb = color & 0xFF;

        final int SS = 8;
        for (int x = -rInt; x <= rInt; x++) {
            for (int y = -rInt; y <= rInt; y++) {
                int count = 0;
                for (int si = 0; si < SS; si++) {
                    for (int sj = 0; sj < SS; sj++) {
                        float px = x + (si + 0.5f) / SS;
                        float py = y + (sj + 0.5f) / SS;
                        if (px * px + py * py <= r * r) count++;
                    }
                }
                int alpha = (int) ((double) count / (SS * SS) * a + 0.5);
                if (alpha <= 0) continue;
                int c = (alpha << 24) | (rr << 16) | (gg << 8) | bb;
                context.fill((int)cx + x, (int)cy + y, (int)cx + x + 1, (int)cy + y + 1, c);
            }
        }
    }

    // Линия с SSAA: каждый пиксель в радиусе толщины получает свою альфу
    private static void drawSmoothLine(DrawContext context, float x1, float y1, float x2, float y2, int color) {
        int a = (color >> 24) & 0xFF;
        int rr = (color >> 16) & 0xFF;
        int gg = (color >> 8) & 0xFF;
        int bb = color & 0xFF;

        float dx = x2 - x1;
        float dy = y2 - y1;
        float len = (float)Math.sqrt(dx * dx + dy * dy);
        if (len < 0.001f) return;

        float nx = -dy / len; // нормаль
        float ny = dx / len;
        float thickness = 1.2f;

        float minX = Math.min(x1, x2) - thickness - 1;
        float maxX = Math.max(x1, x2) + thickness + 1;
        float minY = Math.min(y1, y2) - thickness - 1;
        float maxY = Math.max(y1, y2) + thickness + 1;

        final int SS = 4;
        int startX = (int)Math.floor(minX);
        int endX = (int)Math.ceil(maxX);
        int startY = (int)Math.floor(minY);
        int endY = (int)Math.ceil(maxY);

        for (int px = startX; px <= endX; px++) {
            for (int py = startY; py <= endY; py++) {
                int count = 0;
                for (int si = 0; si < SS; si++) {
                    for (int sj = 0; sj < SS; sj++) {
                        float sx = px + (si + 0.5f) / SS;
                        float sy = py + (sj + 0.5f) / SS;
                        // Расстояние от точки до отрезка
                        float t = ((sx - x1) * dx + (sy - y1) * dy) / (len * len);
                        if (t < 0) t = 0;
                        if (t > 1) t = 1;
                        float closestX = x1 + dx * t;
                        float closestY = y1 + dy * t;
                        float ddx = sx - closestX;
                        float ddy = sy - closestY;
                        float dist = (float)Math.sqrt(ddx * ddx + ddy * ddy);
                        if (dist <= thickness) count++;
                    }
                }
                int alpha = (int) ((double) count / (SS * SS) * a + 0.5);
                if (alpha <= 0) continue;
                int c = (alpha << 24) | (rr << 16) | (gg << 8) | bb;
                context.fill(px, py, px + 1, py + 1, c);
            }
        }
    }
}
