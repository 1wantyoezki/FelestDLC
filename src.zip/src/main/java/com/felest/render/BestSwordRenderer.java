package com.felest.render;

import com.felest.FelestDLC;
import com.felest.module.impl.BestSword;
import com.felest.util.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

public class BestSwordRenderer {
    private static float lastSwingProgress = 0f;
    private static long swingTime = 0L;
    private static float swingYaw = 0f;
    private static float swingPitch = 0f;
    private static double swingX, swingY, swingZ;

    public static void register() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            if (FelestDLC.moduleManager == null) return;
            BestSword bs = (BestSword) FelestDLC.moduleManager.getModuleByName("BestSword");
            if (bs == null || !bs.isEnabled()) return;

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null) return;
            if (mc.options.hudHidden) return;
            if (mc.gameRenderer == null) return;

            // Детект свинга: если progress резко изменился с 0 на >0 — новый удар
            float sp = mc.player.getHandSwingProgress(tickCounter.getTickDelta(false));
            if (sp > 0.1f && lastSwingProgress < 0.05f) {
                swingTime = System.currentTimeMillis();
                swingYaw = mc.player.getYaw();
                swingPitch = mc.player.getPitch();
                swingX = mc.player.getX();
                swingY = mc.player.getY() + mc.player.getEyeHeight(mc.player.getPose());
                swingZ = mc.player.getZ();
            }
            lastSwingProgress = sp;

            long elapsed = System.currentTimeMillis() - swingTime;
            float durMs = bs.duration.getFloat() * 1000f;
            if (elapsed > durMs) return;

            float progress = elapsed / durMs; // 0..1
            float alpha = 1.0f - progress; // затухание

            int color = bs.getColor();
            float a = ((color >> 24) & 0xFF) / 255f * alpha;
            float r = ((color >> 16) & 0xFF) / 255f;
            float g = ((color >> 8) & 0xFF) / 255f;
            float b = (color & 0xFF) / 255f;
            int argb = ((int)(a * 255) << 24) | ((int)(r * 255) << 16) | ((int)(g * 255) << 8) | (int)(b * 255);

            // Рисуем дугу в 3D-пространстве, проецируя на экран
            // Дуга = от правого бока к левому, через перед
            int screenW = mc.getWindow().getScaledWidth();
            int screenH = mc.getWindow().getScaledHeight();
            double fov = mc.options.getFov().getValue();

            // Дуга свинга: 5 точек от -60° до +60° вокруг yaw
            int points = 12;
            float prevX = -1, prevY = -1;

            float swingPhase = MathHelper.clamp(elapsed / (durMs * 0.5f), 0f, 1f);
            float arcStart = -80f + 160f * 0f;   // старт
            float arcEnd = -80f + 160f * swingPhase;

            for (int i = 0; i <= points; i++) {
                float t = (float) i / points;
                float angleOffset = arcStart + (arcEnd - arcStart) * t;
                float yaw = swingYaw + angleOffset;

                // Конец "меча": на 0.8 блока вперёд, на 0.3 вправо/влево
                double rad = Math.toRadians(yaw);
                double px = swingX - Math.sin(rad) * 0.9;
                double pz = swingZ + Math.cos(rad) * 0.9;
                double py = swingY - 0.2 + Math.sin(Math.toRadians(swingPitch)) * 0.3;

                float[] s = worldToScreen(px, py, pz, mc, screenW, screenH, fov);
                if (s == null) { prevX = -1; continue; }

                if (prevX >= 0) {
                    float thick = bs.width.getFloat() * (1f - t * 0.5f);
                    RenderUtil.smoothLine(context, prevX, prevY, s[0], s[1], thick, argb);
                }
                prevX = s[0];
                prevY = s[1];
            }
        });
    }

    private static float[] worldToScreen(double wx, double wy, double wz, MinecraftClient mc, int sw, int sh, double fov) {
        net.minecraft.client.render.Camera cam = mc.gameRenderer.getCamera();
        if (cam == null) return null;

        net.minecraft.util.math.Vec3d camPos = cam.getPos();
        org.joml.Quaternionf camRot = cam.getRotation();

        double dx = wx - camPos.x;
        double dy = wy - camPos.y;
        double dz = wz - camPos.z;

        org.joml.Quaternionf inv = new org.joml.Quaternionf(camRot).conjugate();
        org.joml.Vector3f view = new org.joml.Vector3f((float) dx, (float) dy, (float) dz);
        view.rotate(inv);

        if (view.z >= -0.1f) return null;

        float tanHalfFov = (float) Math.tan(Math.toRadians(fov) * 0.5);
        float aspect = (float) sw / sh;

        float ndcX = view.x / (-view.z * tanHalfFov * aspect);
        float ndcY = view.y / (-view.z * tanHalfFov);

        return new float[]{ (ndcX + 1.0f) * 0.5f * sw, (1.0f - ndcY) * 0.5f * sh };
    }
}
