package com.felest.render;

import com.felest.FelestDLC;
import com.felest.module.impl.BestSword;
import com.felest.util.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayDeque;
import java.util.Deque;

public class BestSwordRenderer {
    private static final Deque<TrailPoint> trail = new ArrayDeque<>();
    private static final int MAX_TRAIL = 30;

    private static float lastSwing = 0f;

    private static class TrailPoint {
        float x, y;
        long time;
        TrailPoint(float x, float y, long t) { this.x = x; this.y = y; this.time = t; }
    }

    public static void register() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            if (FelestDLC.moduleManager == null) return;
            BestSword bs = (BestSword) FelestDLC.moduleManager.getModuleByName("BestSword");
            if (bs == null || !bs.isEnabled()) return;

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null) return;
            if (mc.options.hudHidden) return;

            int sw = mc.getWindow().getScaledWidth();
            int sh = mc.getWindow().getScaledHeight();
            float tickDelta = tickCounter.getTickDelta(false);

            // ===== Главная рука =====
            float mainSwing = mc.player.getHandSwingProgress(tickDelta);
            if (mainSwing > 0.01f) {
                float[] pos = computeSwordTip(mainSwing, sw, sh, false);
                trail.addLast(new TrailPoint(pos[0], pos[1], System.currentTimeMillis()));
                while (trail.size() > MAX_TRAIL) trail.removeFirst();
            } else {
                if (!trail.isEmpty()) trail.clear();
            }

            // Рисуем трейл
            if (!trail.isEmpty()) {
                long now = System.currentTimeMillis();
                float durMs = bs.duration.getFloat() * 1000f;
                int color = bs.getColor();
                float baseThick = bs.thickness.getFloat();

                TrailPoint prev = null;
                int idx = 0;
                int total = trail.size();

                for (TrailPoint p : trail) {
                    if (prev != null) {
                        long age = now - p.time;
                        float t = MathHelper.clamp(age / durMs, 0f, 1f);
                        float alpha = 1.0f - t;
                        if (alpha > 0.02f) {
                            float thick = baseThick * alpha;
                            int c = withAlpha(color, (int)(alpha * 255));
                            RenderUtil.smoothLine(context, prev.x, prev.y, p.x, p.y, thick, c);
                        }
                    }
                    prev = p;
                    idx++;
                }
            }

            lastSwing = mainSwing;
        });
    }

    // Позиция "кончика" предмета на экране в зависимости от прогресса свинга
    private static float[] computeSwordTip(float swing, int sw, int sh, boolean offHand) {
        // Пивот — низ предмета
        float pivotX = offHand ? sw * 0.28f : sw * 0.72f;
        float pivotY = sh * 0.95f;
        float radius = sh * 0.35f;

        // Кривая свинга: 0 → 1 → 0
        float curve = MathHelper.sin(MathHelper.sqrt(swing) * (float)Math.PI);

        // Угол от вертикали
        // В покое — 40° (main) / -40° (off)
        // В свинге — добавляется до 100°
        float restAngle = offHand ? -50f : 50f;
        float swingAngle = offHand ? -120f * curve : 120f * curve;
        float totalAngle = restAngle + swingAngle;

        float rad = (float)Math.toRadians(totalAngle);
        float tipX = pivotX + (float)Math.sin(rad) * radius;
        float tipY = pivotY - (float)Math.cos(rad) * radius;

        return new float[]{tipX, tipY};
    }

    private static int withAlpha(int color, int alpha) {
        return (alpha << 24) | (color & 0x00FFFFFF);
    }
}
