package com.felest.render;

import com.felest.FelestDLC;
import com.felest.module.impl.BlockOverlay;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public class BlockOverlayRenderer {
    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            if (FelestDLC.moduleManager == null) return;
            BlockOverlay bo = (BlockOverlay) FelestDLC.moduleManager.getModuleByName("BlockOverlay");
            if (bo == null || !bo.isEnabled()) return;

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null) return;

            // Целевой блок
            HitResult hit = mc.crosshairTarget;
            if (hit == null || hit.getType() != HitResult.Type.BLOCK) return;
            BlockHitResult bhr = (BlockHitResult) hit;
            BlockPos pos = bhr.getBlockPos();
            if (mc.world.getBlockState(pos).isAir()) return;

            Vec3d cam = context.camera().getPos();
            MatrixStack matrices = context.matrixStack();
            VertexConsumerProvider.Immediate immediate = mc.getBufferBuilders().getEntityVertexConsumers();
            if (immediate == null) return;

            int color = bo.getColor();
            float a = ((color >> 24) & 0xFF) / 255f;
            float r = ((color >> 16) & 0xFF) / 255f;
            float g = ((color >> 8) & 0xFF) / 255f;
            float b = (color & 0xFF) / 255f;

            String mode = bo.mode.getString();
            float time = (System.currentTimeMillis() % 100000L) / 1000f;

            // Шейдерный режим — анимированный цвет
            if (mode.equals("Шейдер")) {
                float pulse = (float)(0.7 + 0.3 * Math.sin(time * 3));
                r *= pulse;
                g *= pulse;
                b *= pulse;
            }

            Box box = new Box(pos).expand(0.002);
            double x = box.minX - cam.x;
            double y = box.minY - cam.y;
            double z = box.minZ - cam.z;
            float sx = (float)(box.maxX - box.minX);
            float sy = (float)(box.maxY - box.minY);
            float sz = (float)(box.maxZ - box.minZ);

            // Обычный рендер (с depth — обводка как канон)
            matrices.push();
            matrices.translate(x, y, z);
            Matrix4f mat = matrices.peek().getPositionMatrix();
            VertexConsumer lineBuf = immediate.getBuffer(RenderLayer.getLines());
            drawOutline(lineBuf, mat, sx, sy, sz, r, g, b, a, bo.thickness.getFloat());

            if (mode.equals("Шейдер")) {
                // Внутренняя полупрозрачная заливка
                VertexConsumer fillBuf = immediate.getBuffer(RenderLayer.getDebugQuads());
                drawFill(fillBuf, mat, sx, sy, sz, r, g, b, a * 0.25f);
            }
            immediate.draw();
            matrices.pop();

            // Если Fill включён — рисуем второй раз, но БЕЗ depth (сквозь блоки)
            if (bo.fill.getBool()) {
                RenderSystem.disableDepthTest();
                RenderSystem.depthMask(false);

                matrices.push();
                matrices.translate(x, y, z);
                Matrix4f mat2 = matrices.peek().getPositionMatrix();
                VertexConsumer lineBuf2 = immediate.getBuffer(RenderLayer.getLines());
                drawOutline(lineBuf2, mat2, sx, sy, sz, r, g, b, a * 0.5f, bo.thickness.getFloat());
                immediate.draw();
                matrices.pop();

                RenderSystem.depthMask(true);
                RenderSystem.enableDepthTest();
            }
        });
    }

    private static void drawOutline(VertexConsumer buf, Matrix4f mat,
                                     float sx, float sy, float sz,
                                     float r, float g, float b, float a, float thickness) {
        float x1 = 0, y1 = 0, z1 = 0;
        float x2 = sx, y2 = sy, z2 = sz;
        float t = 0.002f * thickness;

        // Верх/низ
        edge(buf, mat, x1,y1,z1, x2,y1,z1, r,g,b,a, t);
        edge(buf, mat, x2,y1,z1, x2,y1,z2, r,g,b,a, t);
        edge(buf, mat, x2,y1,z2, x1,y1,z2, r,g,b,a, t);
        edge(buf, mat, x1,y1,z2, x1,y1,z1, r,g,b,a, t);
        edge(buf, mat, x1,y2,z1, x2,y2,z1, r,g,b,a, t);
        edge(buf, mat, x2,y2,z1, x2,y2,z2, r,g,b,a, t);
        edge(buf, mat, x2,y2,z2, x1,y2,z2, r,g,b,a, t);
        edge(buf, mat, x1,y2,z2, x1,y2,z1, r,g,b,a, t);
        // Вертикали
        edge(buf, mat, x1,y1,z1, x1,y2,z1, r,g,b,a, t);
        edge(buf, mat, x2,y1,z1, x2,y2,z1, r,g,b,a, t);
        edge(buf, mat, x2,y1,z2, x2,y2,z2, r,g,b,a, t);
        edge(buf, mat, x1,y1,z2, x1,y2,z2, r,g,b,a, t);
    }

    // Ребро — тонкий длинный бокс (чтобы было "толстое")
    private static void edge(VertexConsumer buf, Matrix4f mat,
                              float x1, float y1, float z1,
                              float x2, float y2, float z2,
                              float r, float g, float b, float a, float t) {
        float minX = Math.min(x1, x2) - t, maxX = Math.max(x1, x2) + t;
        float minY = Math.min(y1, y2) - t, maxY = Math.max(y1, y2) + t;
        float minZ = Math.min(z1, z2) - t, maxZ = Math.max(z1, z2) + t;
        // Упрощённый: 3 грани (север, юг, восток, запад) — тонкая полоска
        quad(buf, mat, minX,minY,minZ, maxX,minY,minZ, maxX,minY,maxZ, minX,minY,maxZ, r,g,b,a);
        quad(buf, mat, minX,maxY,minZ, minX,maxY,maxZ, maxX,maxY,maxZ, maxX,maxY,minZ, r,g,b,a);
        quad(buf, mat, minX,minY,minZ, minX,maxY,minZ, maxX,maxY,minZ, maxX,minY,minZ, r,g,b,a);
        quad(buf, mat, minX,minY,maxZ, maxX,minY,maxZ, maxX,maxY,maxZ, minX,maxY,maxZ, r,g,b,a);
        quad(buf, mat, minX,minY,minZ, minX,minY,maxZ, minX,maxY,maxZ, minX,maxY,minZ, r,g,b,a);
        quad(buf, mat, maxX,minY,minZ, maxX,maxY,minZ, maxX,maxY,maxZ, maxX,minY,maxZ, r,g,b,a);
    }

    private static void drawFill(VertexConsumer buf, Matrix4f mat,
                                  float sx, float sy, float sz,
                                  float r, float g, float b, float a) {
        float x1 = 0, y1 = 0, z1 = 0;
        float x2 = sx, y2 = sy, z2 = sz;
        quad(buf, mat, x1,y1,z1, x2,y1,z1, x2,y1,z2, x1,y1,z2, r,g,b,a);
        quad(buf, mat, x1,y2,z1, x1,y2,z2, x2,y2,z2, x2,y2,z1, r,g,b,a);
        quad(buf, mat, x1,y1,z1, x1,y2,z1, x2,y2,z1, x2,y1,z1, r,g,b,a);
        quad(buf, mat, x1,y1,z2, x2,y1,z2, x2,y2,z2, x1,y2,z2, r,g,b,a);
        quad(buf, mat, x1,y1,z1, x1,y1,z2, x1,y2,z2, x1,y2,z1, r,g,b,a);
        quad(buf, mat, x2,y1,z1, x2,y2,z1, x2,y2,z2, x2,y1,z2, r,g,b,a);
    }

    private static void quad(VertexConsumer buf, Matrix4f mat,
                              float x1, float y1, float z1,
                              float x2, float y2, float z2,
                              float x3, float y3, float z3,
                              float x4, float y4, float z4,
                              float r, float g, float b, float a) {
        buf.vertex(mat, x1, y1, z1).color(r, g, b, a);
        buf.vertex(mat, x2, y2, z2).color(r, g, b, a);
        buf.vertex(mat, x3, y3, z3).color(r, g, b, a);
        buf.vertex(mat, x4, y4, z4).color(r, g, b, a);
    }
}
