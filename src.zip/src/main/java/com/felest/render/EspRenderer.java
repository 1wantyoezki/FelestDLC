package com.felest.render;

import com.felest.FelestDLC;
import com.felest.module.impl.Esp;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class EspRenderer {
    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            if (FelestDLC.moduleManager == null) return;
            Esp esp = (Esp) FelestDLC.moduleManager.getModuleByName("ESP");
            if (esp == null || !esp.isEnabled()) return;

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null) return;

            Vec3d cam = context.camera().getPos();
            MatrixStack matrices = context.matrixStack();
            VertexConsumerProvider consumers = context.consumers();
            if (consumers == null) return;

            Camera camera = context.camera();
            Quaternionf camRot = camera.getRotation();
            Vector3f camRight = new Vector3f(1, 0, 0).rotate(camRot);
            Vector3f camUp = new Vector3f(0, 1, 0).rotate(camRot);

            int color = esp.getColor();
            float a = ((color >> 24) & 0xFF) / 255f;
            float r = ((color >> 16) & 0xFF) / 255f;
            float g = ((color >> 8) & 0xFF) / 255f;
            float b = (color & 0xFF) / 255f;

            // Отключаем depth — рисуется поверх и сквозь стены
            RenderSystem.disableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();

            // Заполненный хитбокс — через DebugQuads (без depth)
            VertexConsumer fillBuf = consumers.getBuffer(RenderLayer.getDebugQuads());

            for (Entity e : mc.world.getEntities()) {
                if (e == mc.player) continue;
                if (!esp.shouldRender(e)) continue;

                Box box = e.getBoundingBox();
                double x = box.minX - cam.x;
                double y = box.minY - cam.y;
                double z = box.minZ - cam.z;
                float sx = (float)(box.maxX - box.minX);
                float sy = (float)(box.maxY - box.minY);
                float sz = (float)(box.maxZ - box.minZ);

                matrices.push();
                matrices.translate(x, y, z);
                Matrix4f mat = matrices.peek().getPositionMatrix();
                drawFilledBox(fillBuf, mat, sx, sy, sz, r, g, b, a);
                matrices.pop();
            }

            RenderSystem.disableBlend();
            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();
        });
    }

    // Заполненный хитбокс — 6 граней
    private static void drawFilledBox(VertexConsumer buf, Matrix4f mat,
                                       float sx, float sy, float sz,
                                       float r, float g, float b, float a) {
        float x1 = 0, y1 = 0, z1 = 0;
        float x2 = sx, y2 = sy, z2 = sz;

        // Заполнение — 35% прозрачности, чтобы видеть сквозь
        float fillA = a * 0.35f;

        // 6 граней (каждая = quad)
        // Низ (y1)
        quad(buf, mat, x1,y1,z1, x2,y1,z1, x2,y1,z2, x1,y1,z2, r,g,b,fillA);
        // Верх (y2)
        quad(buf, mat, x1,y2,z1, x1,y2,z2, x2,y2,z2, x2,y2,z1, r,g,b,fillA);
        // Север (z1)
        quad(buf, mat, x1,y1,z1, x1,y2,z1, x2,y2,z1, x2,y1,z1, r,g,b,fillA);
        // Юг (z2)
        quad(buf, mat, x1,y1,z2, x2,y1,z2, x2,y2,z2, x1,y2,z2, r,g,b,fillA);
        // Запад (x1)
        quad(buf, mat, x1,y1,z1, x1,y1,z2, x1,y2,z2, x1,y2,z1, r,g,b,fillA);
        // Восток (x2)
        quad(buf, mat, x2,y1,z1, x2,y2,z1, x2,y2,z2, x2,y1,z2, r,g,b,fillA);

        // Яркие рёбра — рисуем тонкие полосы (2 quad на ребро)
        float edgeA = a;
        float t = 0.015f; // толщина ребра

        // 4 вертикальных ребра
        drawEdge(buf, mat, x1,y1,z1, x1,y2,z1, r,g,b,edgeA,t);
        drawEdge(buf, mat, x2,y1,z1, x2,y2,z1, r,g,b,edgeA,t);
        drawEdge(buf, mat, x2,y1,z2, x2,y2,z2, r,g,b,edgeA,t);
        drawEdge(buf, mat, x1,y1,z2, x1,y2,z2, r,g,b,edgeA,t);

        // 4 нижних рёбра
        drawEdge(buf, mat, x1,y1,z1, x2,y1,z1, r,g,b,edgeA,t);
        drawEdge(buf, mat, x2,y1,z1, x2,y1,z2, r,g,b,edgeA,t);
        drawEdge(buf, mat, x2,y1,z2, x1,y1,z2, r,g,b,edgeA,t);
        drawEdge(buf, mat, x1,y1,z2, x1,y1,z1, r,g,b,edgeA,t);

        // 4 верхних рёбра
        drawEdge(buf, mat, x1,y2,z1, x2,y2,z1, r,g,b,edgeA,t);
        drawEdge(buf, mat, x2,y2,z1, x2,y2,z2, r,g,b,edgeA,t);
        drawEdge(buf, mat, x2,y2,z2, x1,y2,z2, r,g,b,edgeA,t);
        drawEdge(buf, mat, x1,y2,z2, x1,y2,z1, r,g,b,edgeA,t);
    }

    // Ребро как очень тонкий "кубик" (3 оси)
    private static void drawEdge(VertexConsumer buf, Matrix4f mat,
                                  float x1, float y1, float z1,
                                  float x2, float y2, float z2,
                                  float r, float g, float b, float a, float t) {
        // Просто рисуем 4 грани тонкого прямоугольника вдоль ребра.
        // Для простоты — рисуем как 3 вытянутых тонких quad'а (X, Y, Z).
        float minX = Math.min(x1, x2) - t, maxX = Math.max(x1, x2) + t;
        float minY = Math.min(y1, y2) - t, maxY = Math.max(y1, y2) + t;
        float minZ = Math.min(z1, z2) - t, maxZ = Math.max(z1, z2) + t;

        // Рисуем "полый" бокс — 4 боковых грани (без верха/низа)
        // Низ
        quad(buf, mat, minX,minY,minZ, maxX,minY,minZ, maxX,minY,maxZ, minX,minY,maxZ, r,g,b,a);
        // Верх
        quad(buf, mat, minX,maxY,minZ, minX,maxY,maxZ, maxX,maxY,maxZ, maxX,maxY,minZ, r,g,b,a);
        // Север
        quad(buf, mat, minX,minY,minZ, minX,maxY,minZ, maxX,maxY,minZ, maxX,minY,minZ, r,g,b,a);
        // Юг
        quad(buf, mat, minX,minY,maxZ, maxX,minY,maxZ, maxX,maxY,maxZ, minX,maxY,maxZ, r,g,b,a);
    }

    private static void quad(VertexConsumer buf, Matrix4f mat,
                              float x1, float y1, float z1,
                              float x2, float y2, float z2,
                              float x3, float y3, float z3,
                              float x4, float y4, float z4,
                              float r, float g, float b, float a) {
        buf.vertex(mat, x1, y1, z1).color(r, g, b, a);
        buf.vertex(mat, x2, y2, z2).color(r, g, b, a);
        buf.vertex(mat, x3, y3, z3).color(r, g, b, a);
        buf.vertex(mat, x4, y4, z4).color(r, g, b, a);
    }
}
