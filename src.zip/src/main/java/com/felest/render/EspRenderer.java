package com.felest.render;

import com.felest.FelestDLC;
import com.felest.module.impl.Esp;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public class EspRenderer {
    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            if (FelestDLC.moduleManager == null) return;
            Esp esp = (Esp) FelestDLC.moduleManager.getModuleByName("ESP");
            if (esp == null || !esp.isEnabled()) return;

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null) return;

            Vec3d cam = context.camera().getPos();
            MatrixStack matrices = context.matrixStack();
            VertexConsumerProvider.Immediate immediate = mc.getBufferBuilders().getEntityVertexConsumers();
            if (immediate == null) return;

            int color = esp.getColor();
            float a = ((color >> 24) & 0xFF) / 255f;
            float r = ((color >> 16) & 0xFF) / 255f;
            float g = ((color >> 8) & 0xFF) / 255f;
            float b = (color & 0xFF) / 255f;

            RenderSystem.disableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();

            VertexConsumer lineBuf = immediate.getBuffer(RenderLayer.getLines());
            VertexConsumer fillBuf = immediate.getBuffer(RenderLayer.getDebugQuads());

            for (Entity e : mc.world.getEntities()) {
                if (e == mc.player) continue;
                if (!esp.shouldRender(e)) continue;

                Box box = e.getBoundingBox();
                double x = box.minX - cam.x;
                double y = box.minY - cam.y;
                double z = box.minZ - cam.z;
                float sx = (float)(box.maxX - box.minX);
                float sy = (float)(box.maxY - box.minY);
                float sz = (float)(box.maxZ - box.minZ);

                matrices.push();
                matrices.translate(x, y, z);
                Matrix4f mat = matrices.peek().getPositionMatrix();
                drawFill(fillBuf, mat, sx, sy, sz, r, g, b, a * 0.4f);
                drawOutline(lineBuf, mat, sx, sy, sz, r, g, b, a);
                matrices.pop();
            }

            immediate.draw();
            RenderSystem.disableBlend();
            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();
        });
    }

    private static void drawOutline(VertexConsumer buf, Matrix4f mat,
                                     float sx, float sy, float sz,
                                     float r, float g, float b, float a) {
        float x1 = 0, y1 = 0, z1 = 0;
        float x2 = sx, y2 = sy, z2 = sz;
        line(buf, mat, x1, y1, z1, x2, y1, z1, r, g, b, a);
        line(buf, mat, x2, y1, z1, x2, y1, z2, r, g, b, a);
        line(buf, mat, x2, y1, z2, x1, y1, z2, r, g, b, a);
        line(buf, mat, x1, y1, z2, x1, y1, z1, r, g, b, a);
        line(buf, mat, x1, y2, z1, x2, y2, z1, r, g, b, a);
        line(buf, mat, x2, y2, z1, x2, y2, z2, r, g, b, a);
        line(buf, mat, x2, y2, z2, x1, y2, z2, r, g, b, a);
        line(buf, mat, x1, y2, z2, x1, y2, z1, r, g, b, a);
        line(buf, mat, x1, y1, z1, x1, y2, z1, r, g, b, a);
        line(buf, mat, x2, y1, z1, x2, y2, z1, r, g, b, a);
        line(buf, mat, x2, y1, z2, x2, y2, z2, r, g, b, a);
        line(buf, mat, x1, y1, z2, x1, y2, z2, r, g, b, a);
    }

    private static void drawFill(VertexConsumer buf, Matrix4f mat,
                                  float sx, float sy, float sz,
                                  float r, float g, float b, float a) {
        float x1 = 0, y1 = 0, z1 = 0;
        float x2 = sx, y2 = sy, z2 = sz;
        quad(buf, mat, x1,y1,z1, x2,y1,z1, x2,y1,z2, x1,y1,z2, r,g,b,a);
        quad(buf, mat, x1,y2,z1, x1,y2,z2, x2,y2,z2, x2,y2,z1, r,g,b,a);
        quad(buf, mat, x1,y1,z1, x1,y2,z1, x2,y2,z1, x2,y1,z1, r,g,b,a);
        quad(buf, mat, x1,y1,z2, x2,y1,z2, x2,y2,z2, x1,y2,z2, r,g,b,a);
        quad(buf, mat, x1,y1,z1, x1,y1,z2, x1,y2,z2, x1,y2,z1, r,g,b,a);
        quad(buf, mat, x2,y1,z1, x2,y2,z1, x2,y2,z2, x2,y1,z2, r,g,b,a);
    }

    private static void quad(VertexConsumer buf, Matrix4f mat,
                              float x1, float y1, float z1,
                              float x2, float y2, float z2,
                              float x3, float y3, float z3,
                              float x4, float y4, float z4,
                              float r, float g, float b, float a) {
        buf.vertex(mat, x1, y1, z1).color(r, g, b, a);
        buf.vertex(mat, x2, y2, z2).color(r, g, b, a);
        buf.vertex(mat, x3, y3, z3).color(r, g, b, a);
        buf.vertex(mat, x4, y4, z4).color(r, g, b, a);
    }

    private static void line(VertexConsumer buf, Matrix4f mat,
                              float x1, float y1, float z1,
                              float x2, float y2, float z2,
                              float r, float g, float b, float a) {
        buf.vertex(mat, x1, y1, z1).color(r, g, b, a).normal(0f, 1f, 0f);
        buf.vertex(mat, x2, y2, z2).color(r, g, b, a).normal(0f, 1f, 0f);
    }
}
