package com.felest.render;

import com.felest.FelestDLC;
import com.felest.module.impl.Esp;
import com.felest.util.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class EspRenderer {
    public static void register() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            if (FelestDLC.moduleManager == null) return;
            Esp esp = (Esp) FelestDLC.moduleManager.getModuleByName("ESP");
            if (esp == null || !esp.isEnabled()) return;

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null) return;
            if (mc.options.hudHidden) return;
            if (mc.gameRenderer == null) return;

            Camera camera = mc.gameRenderer.getCamera();
            if (camera == null) return;

            int screenW = mc.getWindow().getScaledWidth();
            int screenH = mc.getWindow().getScaledHeight();
            double fov = mc.options.getFov().getValue();

            int color = esp.getColor();

            for (Entity e : mc.world.getEntities()) {
                if (e == mc.player) continue;
                if (!esp.shouldRender(e)) continue;

                Box box = e.getBoundingBox();
                Vec3d[] corners = new Vec3d[]{
                        new Vec3d(box.minX, box.minY, box.minZ),
                        new Vec3d(box.maxX, box.minY, box.minZ),
                        new Vec3d(box.minX, box.maxY, box.minZ),
                        new Vec3d(box.maxX, box.maxY, box.minZ),
                        new Vec3d(box.minX, box.minY, box.maxZ),
                        new Vec3d(box.maxX, box.minY, box.maxZ),
                        new Vec3d(box.minX, box.maxY, box.maxZ),
                        new Vec3d(box.maxX, box.maxY, box.maxZ),
                };

                float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE;
                float maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
                boolean behind = false;

                for (Vec3d c : corners) {
                    float[] s = worldToScreen(c, camera, screenW, screenH, fov);
                    if (s == null) { behind = true; break; }
                    if (s[0] < minX) minX = s[0];
                    if (s[0] > maxX) maxX = s[0];
                    if (s[1] < minY) minY = s[1];
                    if (s[1] > maxY) maxY = s[1];
                }
                if (behind) continue;

                // Ограничиваем размеры экрана
                if (maxX < 0 || minX > screenW || maxY < 0 || minY > screenH) continue;

                int x = (int) minX;
                int y = (int) minY;
                int w = (int) (maxX - minX);
                int h = (int) (maxY - minY);

                if (w < 2 || h < 2) continue;

                // Заливка
                RenderUtil.roundedRect(context, x, y, w, h, 3, RenderUtil.withAlpha(color, 50));
                // Обводка
                RenderUtil.roundedOutline(context, x, y, w, h, 3, color, 1);
            }
        });
    }

    private static float[] worldToScreen(Vec3d pos, Camera camera, int screenW, int screenH, double fov) {
        Vec3d camPos = camera.getPos();
        Quaternionf camRot = camera.getRotation();

        double dx = pos.x - camPos.x;
        double dy = pos.y - camPos.y;
        double dz = pos.z - camPos.z;

        // Inverse rotate (для unit quaternion inverse = conjugate)
        Quaternionf inv = new Quaternionf(camRot).conjugate();
        Vector3f view = new Vector3f((float) dx, (float) dy, (float) dz);
        view.rotate(inv);

        // Если точка позади камеры — не рисуем
        if (view.z >= -0.1f) return null;

        float tanHalfFov = (float) Math.tan(Math.toRadians(fov) * 0.5);
        float aspect = (float) screenW / screenH;

        float ndcX = view.x / (-view.z * tanHalfFov * aspect);
        float ndcY = view.y / (-view.z * tanHalfFov);

        float sx = (ndcX + 1.0f) * 0.5f * screenW;
        float sy = (1.0f - ndcY) * 0.5f * screenH;

        return new float[]{sx, sy};
    }
}
