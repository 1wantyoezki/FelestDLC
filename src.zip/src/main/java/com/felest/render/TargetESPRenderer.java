package com.felest.render;

import com.felest.FelestDLC;
import com.felest.module.impl.TargetESP;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public class TargetESPRenderer {
    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            if (FelestDLC.moduleManager == null) return;
            TargetESP esp = (TargetESP) FelestDLC.moduleManager.getModuleByName("TargetESP");
            if (esp == null || !esp.isEnabled()) return;
            LivingEntity target = esp.currentTarget;
            if (target == null) return;

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null) return;

            Vec3d cam = context.camera().getPos();
            Vec3d smooth = esp.getSmoothPos();

            // Смещение относительно камеры
            double x = smooth.x - cam.x;
            double y = smooth.y - cam.y;
            double z = smooth.z - cam.z;

            MatrixStack matrices = context.matrixStack();
            matrices.push();
            matrices.translate(x, y, z);

            VertexConsumerProvider consumers = context.consumers();
            if (consumers == null) { matrices.pop(); return; }
            VertexConsumer buffer = consumers.getBuffer(RenderLayer.getLines());
            Matrix4f mat = matrices.peek().getPositionMatrix();

            int accent = esp.getAccentColor();
            float size = esp.size.getFloat();
            float speed = esp.rotation.getFloat();
            float time = (System.currentTimeMillis() % 1000000L) / 1000f * speed;
            String mode = esp.mode.getString();

            if (mode.equals("Квадрат")) drawSquare(buffer, mat, target, size, time, accent);
            else if (mode.equals("Души")) drawSouls(buffer, mat, target, size, time, accent, (int) esp.soulsCount.getFloat());

            matrices.pop();
        });
    }

    // Квадрат — вращается вокруг игрока по горизонтали
    private static void drawSquare(VertexConsumer buf, Matrix4f mat, LivingEntity target, float size, float time, int accent) {
        float rot = time * 60f;
        // Два квадрата — верхний и нижний — вращаются в одну сторону
        // Верхний квадрат на высоте +0.4 от центра, нижний на -0.4
        float[] levels = { 0.4f, -0.4f };
        for (int lvl = 0; lvl < 2; lvl++) {
            float off = lvl * 22.5f; // смещение по углу
            for (int i = 0; i < 4; i++) {
                float a1 = (float)Math.toRadians(rot + off + i * 90);
                float a2 = (float)Math.toRadians(rot + off + (i + 1) * 90);
                float y1 = levels[lvl];
                float y2 = levels[lvl];
                line(buf, mat,
                        MathHelper.cos(a1) * size, y1, MathHelper.sin(a1) * size,
                        MathHelper.cos(a2) * size, y2, MathHelper.sin(a2) * size,
                        accent);
            }
        }
        // Соединяющие линии между верхним и нижним квадратами
        for (int i = 0; i < 4; i++) {
            float a = (float)Math.toRadians(rot + i * 90);
            float xx = MathHelper.cos(a) * size;
            float zz = MathHelper.sin(a) * size;
            line(buf, mat, xx, 0.4f, zz, xx, -0.4f, zz, accent);
        }
    }

    // Души — крестики, кружатся вокруг игрока по орбитам
    private static void drawSouls(VertexConsumer buf, Matrix4f mat, LivingEntity target, float size, float time, int accent, int count) {
        if (count < 1) count = 1;
        for (int i = 0; i < count; i++) {
            float angle = (float)Math.toRadians(time * 50 + i * (360f / count));
            // Плавное покачивание по высоте
            float yy = (float)(Math.sin(time * 1.2 + i * 0.8) * (target.getHeight() / 2.0) * 0.8);
            float xx = MathHelper.cos(angle) * size;
            float zz = MathHelper.sin(angle) * size;

            // Крестик-дух
            float s = 0.08f;
            line(buf, mat, xx - s, yy, zz, xx + s, yy, zz, accent);
            line(buf, mat, xx, yy - s, zz, xx, yy + s, zz, accent);
        }
    }

    private static void line(VertexConsumer buf, Matrix4f mat,
                              float x1, float y1, float z1, float x2, float y2, float z2, int argb) {
        float a = ((argb >> 24) & 0xFF) / 255f;
        float r = ((argb >> 16) & 0xFF) / 255f;
        float g = ((argb >> 8) & 0xFF) / 255f;
        float b = (argb & 0xFF) / 255f;
        buf.vertex(mat, x1, y1, z1).color(r, g, b, a).normal(0f, 1f, 0f);
        buf.vertex(mat, x2, y2, z2).color(r, g, b, a).normal(0f, 1f, 0f);
    }
}
