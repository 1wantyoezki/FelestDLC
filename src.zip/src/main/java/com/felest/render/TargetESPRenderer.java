package com.felest.render;

import com.felest.FelestDLC;
import com.felest.module.impl.TargetESP;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public class TargetESPRenderer {
    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            if (FelestDLC.moduleManager == null) return;
            TargetESP esp = (TargetESP) FelestDLC.moduleManager.getModuleByName("TargetESP");
            if (esp == null || !esp.isEnabled()) return;
            LivingEntity target = esp.currentTarget;
            if (target == null) return;

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null) return;

            Vec3d cam = context.camera().getPos();
            Vec3d smooth = esp.getSmoothPos();

            double x = smooth.x - cam.x;
            double y = smooth.y - cam.y;
            double z = smooth.z - cam.z;

            MatrixStack matrices = context.matrixStack();
            matrices.push();
            matrices.translate(x, y, z);

            VertexConsumerProvider consumers = context.consumers();
            if (consumers == null) { matrices.pop(); return; }
            VertexConsumer buffer = consumers.getBuffer(RenderLayer.getLines());
            Matrix4f mat = matrices.peek().getPositionMatrix();

            int accent = esp.getAccentColor();
            float size = esp.size.getFloat();
            float thickness = esp.thickness.getFloat();
            float speed = esp.rotation.getFloat();
            float time = (System.currentTimeMillis() % 1000000L) / 1000f * speed;
            String mode = esp.mode.getString();

            if (mode.equals("Квадрат")) drawSquare(buffer, mat, size, time, accent, thickness);
            else if (mode.equals("Души")) drawSouls(buffer, mat, size, time, accent, (int) esp.soulsCount.getFloat(), esp.soulsSize.getFloat(), target.getHeight());

            matrices.pop();
        });
    }

    // 2D квадрат с толстыми гранями, вращается вокруг вертикальной оси
    private static void drawSquare(VertexConsumer buf, Matrix4f mat, float size, float time, int accent, float thickness) {
        float rot = time * 60f;
        // 4 вершины квадрата (2D, на плоскости XZ)
        float[][] corners = new float[4][2];
        for (int i = 0; i < 4; i++) {
            float a = (float)Math.toRadians(rot + i * 90);
            corners[i][0] = MathHelper.cos(a) * size;
            corners[i][1] = MathHelper.sin(a) * size;
        }

        // Рисуем каждую грань толстой — несколько параллельных линий
        int lines = (int) Math.max(1, thickness);
        float step = 0.015f;
        for (int i = 0; i < 4; i++) {
            int j = (i + 1) % 4;
            float x1 = corners[i][0], z1 = corners[i][1];
            float x2 = corners[j][0], z2 = corners[j][1];
            // Направление грани
            float dx = x2 - x1, dz = z2 - z1;
            float len = (float) Math.sqrt(dx * dx + dz * dz);
            if (len < 0.001f) continue;
            // Перпендикуляр (нормаль) — по нему сдвигаем копии
            float nx = -dz / len;
            float nz = dx / len;

            for (int k = 0; k < lines; k++) {
                float offset = (k - (lines - 1) / 2f) * step * thickness;
                line(buf, mat,
                        x1 + nx * offset, 0, z1 + nz * offset,
                        x2 + nx * offset, 0, z2 + nz * offset,
                        accent);
            }
        }
    }

    // Души — маленькие вращающиеся кубики вокруг цели
    private static void drawSouls(VertexConsumer buf, Matrix4f mat, float size, float time, int accent, int count, float soulSize, float targetHeight) {
        if (count < 1) count = 1;
        float half = soulSize;
        for (int i = 0; i < count; i++) {
            float angle = (float)Math.toRadians(time * 50 + i * (360f / count));
            float yy = (float)(Math.sin(time * 1.2 + i * 0.8) * (targetHeight / 2.0) * 0.7);
            float xx = MathHelper.cos(angle) * size;
            float zz = MathHelper.sin(angle) * size;

            // Вращение самого кубика
            float selfRot = (float)Math.toRadians(time * 80 + i * 47);

            drawCube(buf, mat, xx, yy, zz, half, selfRot, accent);
        }
    }

    // Маленький кубик (12 рёбер)
    private static void drawCube(VertexConsumer buf, Matrix4f mat, float cx, float cy, float cz, float half, float rotY, int accent) {
        // 8 вершин куба с вращением вокруг Y
        float[][] v = new float[8][3];
        int idx = 0;
        for (int xi = -1; xi <= 1; xi += 2) {
            for (int yi = -1; yi <= 1; yi += 2) {
                for (int zi = -1; zi <= 1; zi += 2) {
                    float px = xi * half;
                    float py = yi * half;
                    float pz = zi * half;
                    // Вращение вокруг Y
                    float rx = px * MathHelper.cos(rotY) - pz * MathHelper.sin(rotY);
                    float rz = px * MathHelper.sin(rotY) + pz * MathHelper.cos(rotY);
                    v[idx][0] = cx + rx;
                    v[idx][1] = cy + py;
                    v[idx][2] = cz + rz;
                    idx++;
                }
            }
        }

        // Рёбра куба (попарно соединяем вершины)
        int[][] edges = {
                {0,1},{0,2},{0,4},
                {1,3},{1,5},
                {2,3},{2,6},
                {3,7},
                {4,5},{4,6},
                {5,7},
                {6,7}
        };
        for (int[] e : edges) {
            line(buf, mat, v[e[0]][0], v[e[0]][1], v[e[0]][2], v[e[1]][0], v[e[1]][1], v[e[1]][2], accent);
        }
    }

    private static void line(VertexConsumer buf, Matrix4f mat,
                              float x1, float y1, float z1, float x2, float y2, float z2, int argb) {
        float a = ((argb >> 24) & 0xFF) / 255f;
        float r = ((argb >> 16) & 0xFF) / 255f;
        float g = ((argb >> 8) & 0xFF) / 255f;
        float b = (argb & 0xFF) / 255f;
        buf.vertex(mat, x1, y1, z1).color(r, g, b, a).normal(0f, 1f, 0f);
        buf.vertex(mat, x2, y2, z2).color(r, g, b, a).normal(0f, 1f, 0f);
    }
}
