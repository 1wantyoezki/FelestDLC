package com.felest.render;

import com.felest.FelestDLC;
import com.felest.module.impl.TargetESP;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class TargetESPRenderer {
    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            if (FelestDLC.moduleManager == null) return;
            TargetESP esp = (TargetESP) FelestDLC.moduleManager.getModuleByName("TargetESP");
            if (esp == null || !esp.isEnabled()) return;
            LivingEntity target = esp.currentTarget;
            if (target == null) return;

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null) return;

            Vec3d cam = context.camera().getPos();
            Vec3d pos = esp.getTargetPos();
            if (pos.equals(Vec3d.ZERO)) return;

            double x = pos.x - cam.x;
            double y = pos.y - cam.y;
            double z = pos.z - cam.z;

            Camera camera = context.camera();
            Quaternionf camRot = camera.getRotation();
            Vector3f camRight = new Vector3f(1, 0, 0).rotate(camRot);
            Vector3f camUp = new Vector3f(0, 1, 0).rotate(camRot);

            MatrixStack matrices = context.matrixStack();
            matrices.push();
            matrices.translate(x, y, z);

            VertexConsumerProvider consumers = context.consumers();
            if (consumers == null) { matrices.pop(); return; }
            Matrix4f mat = matrices.peek().getPositionMatrix();

            int accent = esp.getAccentColor();
            float size = esp.size.getFloat();
            float ring = esp.ringWidth.getFloat();
            float speed = esp.rotation.getFloat();
            float time = (System.currentTimeMillis() % 1000000L) / 1000f * speed;

            RenderSystem.disableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();

            VertexConsumer buf = consumers.getBuffer(RenderLayer.getDebugQuads());

            drawRoundedRingSquare(buf, mat, size, ring, time, accent, camRight, camUp);

            RenderSystem.disableBlend();
            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();

            matrices.pop();
        });
    }

    // Строго 2D billboard: правый и верхний вектора — из камеры. Никаких поворотов вокруг осей мира.
    private static void drawRoundedRingSquare(VertexConsumer buf, Matrix4f mat,
                                               float size, float ringPct, float time, int accent,
                                               Vector3f camRight, Vector3f camUp) {
        // Пульсация размера
        float pulse = 1.0f + (float)(Math.sin(time * 3) * 0.03);
        float half = size * pulse;
        float inner = half * (1.0f - ringPct);
        float corner = half * 0.25f; // радиус закругления

        float a = ((accent >> 24) & 0xFF) / 255f;
        float r = ((accent >> 16) & 0xFF) / 255f;
        float g = ((accent >> 8) & 0xFF) / 255f;
        float b = (accent & 0xFF) / 255f;

        float fillA = 0.55f * a;
        float lineA = a;

        // ===== ВНЕШНИЙ КОНТУР (скруглённый) =====
        drawRoundedOutline(buf, mat, camRight, camUp, 0, 0, half, corner, r, g, b, lineA);
        // ===== ВНУТРЕННИЙ КОНТУР =====
        drawRoundedOutline(buf, mat, camRight, camUp, 0, 0, inner, corner * (inner / half), r, g, b, lineA);

        // ===== ЗАПОЛНЕНИЕ КОЛЬЦА =====
        // Прямые части (4 полосы)
        // Верх
        quad2D(buf, mat, camRight, camUp, -half + corner, inner, half - corner, half, r, g, b, fillA);
        // Низ
        quad2D(buf, mat, camRight, camUp, -half + corner, -half, half - corner, -inner, r, g, b, fillA);
        // Лево
        quad2D(buf, mat, camRight, camUp, -half, -inner, -inner, inner, r, g, b, fillA);
        // Право
        quad2D(buf, mat, camRight, camUp, inner, -inner, half, inner, r, g, b, fillA);

        // Углы — заполняем полосками по дуге
        drawCornerFill(buf, mat, camRight, camUp, -half + corner, half - corner, corner, inner, half, corner, 0, r, g, b, fillA);       // top-left
        drawCornerFill(buf, mat, camRight, camUp, half - corner, half - corner, corner, inner, half, corner, 1, r, g, b, fillA);        // top-right
        drawCornerFill(buf, mat, camRight, camUp, half - corner, -half + corner, corner, inner, half, corner, 2, r, g, b, fillA);       // bottom-right
        drawCornerFill(buf, mat, camRight, camUp, -half + corner, -half + corner, corner, inner, half, corner, 3, r, g, b, fillA);      // bottom-left

        // ===== УЗОРЫ (ромбики по центру сторон) =====
        float diamondSize = (half - inner) * 0.4f;
        float midRing = (half + inner) / 2f;
        drawDiamond2D(buf, mat, camRight, camUp, 0, midRing, diamondSize, r, g, b, a * 0.9f);
        drawDiamond2D(buf, mat, camRight, camUp, 0, -midRing, diamondSize, r, g, b, a * 0.9f);
        drawDiamond2D(buf, mat, camRight, camUp, midRing, 0, diamondSize, r, g, b, a * 0.9f);
        drawDiamond2D(buf, mat, camRight, camUp, -midRing, 0, diamondSize, r, g, b, a * 0.9f);
    }

    // Закруглённый контур (только обводка)
    private static void drawRoundedOutline(VertexConsumer buf, Matrix4f mat, Vector3f right, Vector3f up,
                                            float cx, float cy, float half, float corner,
                                            float r, float g, float b, float a) {
        float thickness = 0.012f;

        // Прямые части
        drawThickLine(buf, mat, right, up, -half + corner, half, half - corner, half, thickness, r, g, b, a); // top
        drawThickLine(buf, mat, right, up, half, half - corner, half, -half + corner, thickness, r, g, b, a); // right
        drawThickLine(buf, mat, right, up, half - corner, -half, -half + corner, -half, thickness, r, g, b, a); // bottom
        drawThickLine(buf, mat, right, up, -half, -half + corner, -half, half - corner, thickness, r, g, b, a); // left

        // Углы — рисуем дугу
        drawArc(buf, mat, right, up, -half + corner, half - corner, corner, 90, 180, thickness, r, g, b, a);   // top-left
        drawArc(buf, mat, right, up, half - corner, half - corner, corner, 0, 90, thickness, r, g, b, a);       // top-right
        drawArc(buf, mat, right, up, half - corner, -half + corner, corner, -90, 0, thickness, r, g, b, a);     // bottom-right
        drawArc(buf, mat, right, up, -half + corner, -half + corner, corner, 180, 270, thickness, r, g, b, a);  // bottom-left
    }

    private static void drawArc(VertexConsumer buf, Matrix4f mat, Vector3f right, Vector3f up,
                                 float cx, float cy, float radius,
                                 float startDeg, float endDeg,
                                 float thickness, float r, float g, float b, float a) {
        int segments = 8;
        float start = (float)Math.toRadians(startDeg);
        float end = (float)Math.toRadians(endDeg);
        for (int i = 0; i < segments; i++) {
            float a1 = start + (end - start) * i / segments;
            float a2 = start + (end - start) * (i + 1) / segments;
            float x1 = cx + MathHelper.cos(a1) * radius;
            float y1 = cy + MathHelper.sin(a1) * radius;
            float x2 = cx + MathHelper.cos(a2) * radius;
            float y2 = cy + MathHelper.sin(a2) * radius;
            drawThickLine(buf, mat, right, up, x1, y1, x2, y2, thickness, r, g, b, a);
        }
    }

    private static void drawCornerFill(VertexConsumer buf, Matrix4f mat, Vector3f right, Vector3f up,
                                        float cx, float cy, float cornerRadius,
                                        float innerHalf, float outerHalf, float corner,
                                        int cornerIndex,
                                        float r, float g, float b, float a) {
        // Для заполнения угла кольца: соединяем внешнюю дугу и внутреннюю дугу
        int segments = 8;
        float startDeg = 0, endDeg = 0;
        switch (cornerIndex) {
            case 0: startDeg = 90; endDeg = 180; break;   // top-left
            case 1: startDeg = 0; endDeg = 90; break;     // top-right
            case 2: startDeg = -90; endDeg = 0; break;    // bottom-right
            case 3: startDeg = 180; endDeg = 270; break;  // bottom-left
        }
        float start = (float)Math.toRadians(startDeg);
        float end = (float)Math.toRadians(endDeg);
        // Внутренний радиус в углу
        float innerCorner = cornerRadius * (innerHalf / outerHalf);

        for (int i = 0; i < segments; i++) {
            float a1 = start + (end - start) * i / segments;
            float a2 = start + (end - start) * (i + 1) / segments;

            float outerX1 = cx + MathHelper.cos(a1) * cornerRadius;
            float outerY1 = cy + MathHelper.sin(a1) * cornerRadius;
            float outerX2 = cx + MathHelper.cos(a2) * cornerRadius;
            float outerY2 = cy + MathHelper.sin(a2) * cornerRadius;

            float innerX1 = cx + MathHelper.cos(a1) * innerCorner;
            float innerY1 = cy + MathHelper.sin(a1) * innerCorner;
            float innerX2 = cx + MathHelper.cos(a2) * innerCorner;
            float innerY2 = cy + MathHelper.sin(a2) * innerCorner;

            // Квад между двумя дугами
            quad4(buf, mat, right, up, innerX1, innerY1, outerX1, outerY1, outerX2, outerY2, innerX2, innerY2, r, g, b, a);
        }
    }

    private static void drawThickLine(VertexConsumer buf, Matrix4f mat, Vector3f right, Vector3f up,
                                       float x1, float y1, float x2, float y2,
                                       float thickness, float r, float g, float b, float a) {
        float dx = x2 - x1;
        float dy = y2 - y1;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 0.001f) return;
        float nx = -dy / len * thickness;
        float ny = dx / len * thickness;

        quad4(buf, mat, right, up,
                x1 + nx, y1 + ny,
                x2 + nx, y2 + ny,
                x2 - nx, y2 - ny,
                x1 - nx, y1 - ny,
                r, g, b, a);
    }

    private static void drawDiamond2D(VertexConsumer buf, Matrix4f mat, Vector3f right, Vector3f up,
                                       float cx, float cy, float size,
                                       float r, float g, float b, float a) {
        quad4(buf, mat, right, up,
                cx, cy + size,
                cx + size, cy,
                cx, cy - size,
                cx - size, cy,
                r, g, b, a);
    }

    // Универсальный quad2D (прямоугольник по 2 углам)
    private static void quad2D(VertexConsumer buf, Matrix4f mat, Vector3f right, Vector3f up,
                                float x1, float y1, float x2, float y2,
                                float r, float g, float b, float a) {
        quad4(buf, mat, right, up, x1, y1, x2, y1, x2, y2, x1, y2, r, g, b, a);
    }

    // 4 точки в 2D-плоскости, преобразованные в мир
    private static void quad4(VertexConsumer buf, Matrix4f mat, Vector3f right, Vector3f up,
                               float x1, float y1, float x2, float y2,
                               float x3, float y3, float x4, float y4,
                               float r, float g, float b, float a) {
        float[] v = toWorld(right, up, x1, y1);
        float[] v2 = toWorld(right, up, x2, y2);
        float[] v3 = toWorld(right, up, x3, y3);
        float[] v4 = toWorld(right, up, x4, y4);

        buf.vertex(mat, v[0], v[1], v[2]).color(r, g, b, a);
        buf.vertex(mat, v2[0], v2[1], v2[2]).color(r, g, b, a);
        buf.vertex(mat, v3[0], v3[1], v3[2]).color(r, g, b, a);
        buf.vertex(mat, v4[0], v4[1], v4[2]).color(r, g, b, a);
    }

    private static float[] toWorld(Vector3f right, Vector3f up, float x, float y) {
        return new float[] {
                right.x * x + up.x * y,
                right.y * x + up.y * y,
                right.z * x + up.z * y
        };
    }
}
