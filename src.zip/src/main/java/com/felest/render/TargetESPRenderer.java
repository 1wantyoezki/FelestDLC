package com.felest.render;

import com.felest.FelestDLC;
import com.felest.module.impl.TargetESP;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class TargetESPRenderer {
    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            if (FelestDLC.moduleManager == null) return;
            TargetESP esp = (TargetESP) FelestDLC.moduleManager.getModuleByName("TargetESP");
            if (esp == null || !esp.isEnabled()) return;
            LivingEntity target = esp.currentTarget;
            if (target == null) return;

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null) return;

            Vec3d cam = context.camera().getPos();
            Vec3d smooth = esp.getSmoothPos();

            double x = smooth.x - cam.x;
            double y = smooth.y - cam.y;
            double z = smooth.z - cam.z;

            Camera camera = context.camera();
            Quaternionf camRot = camera.getRotation();
            Vector3f camRight = new Vector3f(1, 0, 0).rotate(camRot);
            Vector3f camUp = new Vector3f(0, 1, 0).rotate(camRot);

            MatrixStack matrices = context.matrixStack();
            matrices.push();
            matrices.translate(x, y, z);

            VertexConsumerProvider consumers = context.consumers();
            if (consumers == null) { matrices.pop(); return; }

            Matrix4f mat = matrices.peek().getPositionMatrix();

            int accent = esp.getAccentColor();
            float size = esp.size.getFloat();
            float thickness = esp.thickness.getFloat();
            float speed = esp.rotation.getFloat();
            float time = (System.currentTimeMillis() % 1000000L) / 1000f * speed;
            String mode = esp.mode.getString();

            // Отключаем depth test — чтобы всё рисовалось ПОВЕРХ игрока
            RenderSystem.disableDepthTest();
            RenderSystem.depthMask(false);

            if (mode.equals("Квадрат")) {
                VertexConsumer fillBuf = consumers.getBuffer(RenderLayer.getDebugFilledBox());
                VertexConsumer lineBuf = consumers.getBuffer(RenderLayer.getLines());
                drawSquare(fillBuf, lineBuf, mat, size, time, accent, thickness, camRight, camUp);
            } else if (mode.equals("Души")) {
                VertexConsumer fillBuf = consumers.getBuffer(RenderLayer.getDebugFilledBox());
                drawSouls(fillBuf, mat, size, time, accent,
                        (int) esp.soulsCount.getFloat(), esp.soulsSize.getFloat(),
                        target.getHeight(), camRight, camUp);
            }

            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();

            matrices.pop();
        });
    }

    // Квадрат — billboard, всегда лицом к нам, заполненный + контур
    private static void drawSquare(VertexConsumer fillBuf, VertexConsumer lineBuf, Matrix4f mat,
                                    float size, float time, int accent, float thickness,
                                    Vector3f camRight, Vector3f camUp) {
        float rot = (float)Math.toRadians(time * 60f);
        float half = size;

        // Вращаем camRight и camUp на угол rot — квадрат крутится
        Vector3f right = new Vector3f(camRight).mul(MathHelper.cos(rot)).add(new Vector3f(camUp).mul(MathHelper.sin(rot)));
        Vector3f up = new Vector3f(camUp).mul(MathHelper.cos(rot)).sub(new Vector3f(camRight).mul(MathHelper.sin(rot)));

        float rx = right.x * half, ry = right.y * half, rz = right.z * half;
        float ux = up.x * half, uy = up.y * half, uz = up.z * half;

        float v1x = rx + ux, v1y = ry + uy, v1z = rz + uz;
        float v2x = -rx + ux, v2y = -ry + uy, v2z = -rz + uz;
        float v3x = -rx - ux, v3y = -ry - uy, v3z = -rz - uz;
        float v4x = rx - ux, v4y = ry - uy, v4z = rz - uz;

        float a = ((accent >> 24) & 0xFF) / 255f;
        float r = ((accent >> 16) & 0xFF) / 255f;
        float g = ((accent >> 8) & 0xFF) / 255f;
        float b = (accent & 0xFF) / 255f;

        // Полупрозрачное заполнение
        float fillA = 0.35f * a;
        fillQuad(fillBuf, mat, v1x, v1y, v1z, v2x, v2y, v2z, v3x, v3y, v3z, v4x, v4y, v4z, r, g, b, fillA);

        // Толстый контур — линии параллельно каждой грани
        int lines = (int) Math.max(1, thickness);
        float stepPx = 0.012f;

        // 4 грани
        float[][] corners = { {v1x,v1y,v1z}, {v2x,v2y,v2z}, {v3x,v3y,v3z}, {v4x,v4y,v4z} };
        for (int i = 0; i < 4; i++) {
            int j = (i + 1) % 4;
            float[] c1 = corners[i];
            float[] c2 = corners[j];
            // Направление грани
            float dx = c2[0] - c1[0], dy = c2[1] - c1[1], dz = c2[2] - c1[2];
            float len = (float) Math.sqrt(dx*dx + dy*dy + dz*dz);
            if (len < 0.001f) continue;
            // Нормаль внутри плоскости (перпендикуляр к грани, лежит в плоскости квадрата)
            // = cross(edge, normal_of_square) но проще — сдвиг вдоль camRight/camUp не подходит.
            // Используем перпендикуляр к грани в плоскости billboard:
            float nx = dy * (right.z * up.y - right.y * up.z) - dz * (right.x * up.y - right.y * up.x);
            float ny = dz * (right.x * up.z - right.z * up.x) - dx * (right.z * up.y - right.y * up.z);
            float nz = dx * (right.y * up.x - right.x * up.y) - dy * (right.x * up.z - right.z * up.x);
            float nlen = (float) Math.sqrt(nx*nx + ny*ny + nz*nz);
            if (nlen < 0.001f) continue;
            nx /= nlen; ny /= nlen; nz /= nlen;

            for (int k = 0; k < lines; k++) {
                float off = (k - (lines - 1) / 2f) * stepPx * thickness * 2;
                line(lineBuf, mat,
                        c1[0] + nx * off, c1[1] + ny * off, c1[2] + nz * off,
                        c2[0] + nx * off, c2[1] + ny * off, c2[2] + nz * off,
                        accent);
            }
        }
    }

    private static void drawSouls(VertexConsumer buf, Matrix4f mat, float size, float time, int accent,
                                   int count, float soulSize, float targetHeight,
                                   Vector3f camRight, Vector3f camUp) {
        if (count < 1) count = 1;

        float a = ((accent >> 24) & 0xFF) / 255f;
        float r = ((accent >> 16) & 0xFF) / 255f;
        float g = ((accent >> 8) & 0xFF) / 255f;
        float b = (accent & 0xFF) / 255f;

        for (int i = 0; i < count; i++) {
            float angle = (float)Math.toRadians(time * 50 + i * (360f / count));
            float yy = (float)(Math.sin(time * 1.2 + i * 0.8) * (targetHeight / 2.0) * 0.7);
            float xx = MathHelper.cos(angle) * size;
            float zz = MathHelper.sin(angle) * size;

            drawBillboardOrb(buf, mat, xx, yy, zz, soulSize, camRight, camUp, r, g, b, 0.35f * a);
            drawBillboardOrb(buf, mat, xx, yy, zz, soulSize * 0.7f, camRight, camUp, r, g, b, 0.7f * a);
            drawBillboardOrb(buf, mat, xx, yy, zz, soulSize * 0.4f, camRight, camUp, r, g, b, a);
        }
    }

    private static void drawBillboardOrb(VertexConsumer buf, Matrix4f mat,
                                          float cx, float cy, float cz, float radius,
                                          Vector3f camRight, Vector3f camUp,
                                          float r, float g, float b, float a) {
        float rx1 = camRight.x * radius, ry1 = camRight.y * radius, rz1 = camRight.z * radius;
        float ux1 = camUp.x * radius, uy1 = camUp.y * radius, uz1 = camUp.z * radius;

        float v1x = cx + rx1 + ux1, v1y = cy + ry1 + uy1, v1z = cz + rz1 + uz1;
        float v2x = cx - rx1 + ux1, v2y = cy - ry1 + uy1, v2z = cz - rz1 + uz1;
        float v3x = cx - rx1 - ux1, v3y = cy - ry1 - uy1, v3z = cz - rz1 - uz1;
        float v4x = cx + rx1 - ux1, v4y = cy + ry1 - uy1, v4z = cz + rz1 - uz1;

        fillQuad(buf, mat, v1x, v1y, v1z, v2x, v2y, v2z, v3x, v3y, v3z, v4x, v4y, v4z, r, g, b, a);
    }

    private static void fillQuad(VertexConsumer buf, Matrix4f mat,
                                  float x1, float y1, float z1,
                                  float x2, float y2, float z2,
                                  float x3, float y3, float z3,
                                  float x4, float y4, float z4,
                                  float r, float g, float b, float a) {
        buf.vertex(mat, x1, y1, z1).color(r, g, b, a);
        buf.vertex(mat, x2, y2, z2).color(r, g, b, a);
        buf.vertex(mat, x3, y3, z3).color(r, g, b, a);
        buf.vertex(mat, x4, y4, z4).color(r, g, b, a);
    }

    private static void line(VertexConsumer buf, Matrix4f mat,
                              float x1, float y1, float z1, float x2, float y2, float z2, int argb) {
        float a = ((argb >> 24) & 0xFF) / 255f;
        float r = ((argb >> 16) & 0xFF) / 255f;
        float g = ((argb >> 8) & 0xFF) / 255f;
        float b = (argb & 0xFF) / 255f;
        buf.vertex(mat, x1, y1, z1).color(r, g, b, a).normal(0f, 1f, 0f);
        buf.vertex(mat, x2, y2, z2).color(r, g, b, a).normal(0f, 1f, 0f);
    }
}
