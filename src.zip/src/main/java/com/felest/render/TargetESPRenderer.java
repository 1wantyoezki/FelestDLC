package com.felest.render;

import com.felest.FelestDLC;
import com.felest.module.impl.TargetESP;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public class TargetESPRenderer {
    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            if (FelestDLC.moduleManager == null) return;
            TargetESP esp = (TargetESP) FelestDLC.moduleManager.getModuleByName("TargetESP");
            if (esp == null || !esp.isEnabled()) return;
            LivingEntity target = esp.currentTarget;
            if (target == null) return;

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null) return;

            Vec3d cam = context.camera().getPos();
            double x = target.getX() - cam.x;
            double y = target.getY() - cam.y;
            double z = target.getZ() - cam.z;

            MatrixStack matrices = context.matrixStack();
            matrices.push();
            matrices.translate(x, y, z);

            VertexConsumerProvider consumers = context.consumers();
            if (consumers == null) { matrices.pop(); return; }
            VertexConsumer buffer = consumers.getBuffer(RenderLayer.getLines());
            Matrix4f mat = matrices.peek().getPositionMatrix();

            int accent = esp.getAccentColor();
            float size = esp.size.getFloat();
            float speed = esp.rotation.getFloat();
            float time = (System.currentTimeMillis() % 100000L) / 1000f * speed;
            String mode = esp.mode.getString();

            if (mode.equals("Квадрат")) drawSquare(buffer, mat, target, size, time, accent);
            else if (mode.equals("Цепи")) drawChains(buffer, mat, target, size, time, accent);
            else if (mode.equals("Души")) drawSouls(buffer, mat, target, size, time, accent);

            matrices.pop();
        });
    }

    private static void drawSquare(VertexConsumer buf, Matrix4f mat, LivingEntity target, float size, float time, int accent) {
        float height = target.getHeight();
        float rot = time * 60f;
        // 2 вращающихся квадрата сверху и снизу
        for (int level = 0; level < 2; level++) {
            float yy = level == 0 ? 0.15f : height - 0.15f;
            float off = level * 45f;
            for (int i = 0; i < 4; i++) {
                float a1 = (float)Math.toRadians(rot + off + i * 90);
                float a2 = (float)Math.toRadians(rot + off + (i + 1) * 90);
                line(buf, mat,
                        MathHelper.cos(a1) * size, yy, MathHelper.sin(a1) * size,
                        MathHelper.cos(a2) * size, yy, MathHelper.sin(a2) * size,
                        accent);
            }
        }
        // вертикальные связи
        for (int i = 0; i < 4; i++) {
            float a = (float)Math.toRadians(rot + i * 90);
            float xx = MathHelper.cos(a) * size;
            float zz = MathHelper.sin(a) * size;
            line(buf, mat, xx, 0.15f, zz, xx, height - 0.15f, zz, accent);
        }
    }

    private static void drawChains(VertexConsumer buf, Matrix4f mat, LivingEntity target, float size, float time, int accent) {
        float height = target.getHeight();
        int count = 6;
        for (int i = 0; i < count; i++) {
            float angle = (float)Math.toRadians(time * 40 + i * (360f / count));
            float xx = MathHelper.cos(angle) * size;
            float zz = MathHelper.sin(angle) * size;
            int seg = 8;
            for (int s = 0; s < seg; s++) {
                float y1 = 0.1f + (height - 0.2f) * s / seg;
                float y2 = 0.1f + (height - 0.2f) * (s + 1) / seg;
                line(buf, mat, xx, y1, zz, xx, y2, zz, accent);
                // поперечные кольца
                if (s % 2 == 0) {
                    line(buf, mat, xx - 0.06f, y1, zz, xx + 0.06f, y1, zz, accent);
                }
            }
        }
    }

    private static void drawSouls(VertexConsumer buf, Matrix4f mat, LivingEntity target, float size, float time, int accent) {
        float height = target.getHeight();
        int count = 5;
        for (int i = 0; i < count; i++) {
            float phase = ((time * 0.3f + i * 0.2f) % 1.0f);
            float yy = phase * height;
            float angle = (float)Math.toRadians(time * 30 + i * (360f / count));
            float xx = MathHelper.cos(angle) * size;
            float zz = MathHelper.sin(angle) * size;
            // маленький крестик-дух
            line(buf, mat, xx - 0.07f, yy, zz, xx + 0.07f, yy, zz, accent);
            line(buf, mat, xx, yy - 0.07f, zz, xx, yy + 0.07f, zz, accent);
        }
    }

    private static void line(VertexConsumer buf, Matrix4f mat,
                              float x1, float y1, float z1, float x2, float y2, float z2, int argb) {
        float a = ((argb >> 24) & 0xFF) / 255f;
        float r = ((argb >> 16) & 0xFF) / 255f;
        float g = ((argb >> 8) & 0xFF) / 255f;
        float b = (argb & 0xFF) / 255f;
        buf.vertex(mat, x1, y1, z1).color(r, g, b, a).normal(0f, 1f, 0f);
        buf.vertex(mat, x2, y2, z2).color(r, g, b, a).normal(0f, 1f, 0f);
    }
}
