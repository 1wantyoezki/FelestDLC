package com.felest.render;

import com.felest.FelestDLC;
import com.felest.module.impl.Trajectories;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.EggItem;
import net.minecraft.item.EnderPearlItem;
import net.minecraft.item.FireworkRocketItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.LingeringPotionItem;
import net.minecraft.item.SnowballItem;
import net.minecraft.item.SplashPotionItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

public class TrajectoriesRenderer {
    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            if (FelestDLC.moduleManager == null) return;
            Trajectories tr = (Trajectories) FelestDLC.moduleManager.getModuleByName("Trajectories");
            if (tr == null || !tr.isEnabled()) return;

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null) return;

            ItemStack stack = mc.player.getMainHandStack();
            if (stack.isEmpty()) stack = mc.player.getOffHandStack();
            if (stack.isEmpty()) return;

            float velocity;
            float gravity;
            float drag;

            if (stack.getItem() instanceof BowItem) {
                velocity = 3.0f;
                // Если лук заряжен — используем реальную скорость
                int useTicks = mc.player.getItemUseTime();
                float pull = useTicks / 20f;
                pull = (pull * pull + pull * 2f) / 3f;
                if (pull > 1f) pull = 1f;
                velocity = pull * 3.0f;
                if (velocity < 0.1f) velocity = 3.0f;
                gravity = 0.05f;
                drag = 0.99f;
            } else if (stack.getItem() instanceof CrossbowItem) {
                velocity = 3.15f;
                gravity = 0.05f;
                drag = 0.99f;
            } else if (stack.getItem() instanceof TridentItem) {
                velocity = 2.5f;
                gravity = 0.05f;
                drag = 0.99f;
            } else if (stack.getItem() instanceof SnowballItem
                    || stack.getItem() instanceof EggItem
                    || stack.getItem() instanceof EnderPearlItem
                    || stack.getItem() instanceof SplashPotionItem
                    || stack.getItem() instanceof LingeringPotionItem
                    || stack.getItem() instanceof FireworkRocketItem) {
                velocity = 1.5f;
                gravity = 0.03f;
                drag = 0.99f;
            } else {
                return;
            }

            Vec3d start = mc.player.getCameraPosVec(1.0f);
            float yaw = mc.player.getYaw();
            float pitch = mc.player.getPitch();

            // Направление взгляда
            double dx = -Math.sin(Math.toRadians(yaw)) * Math.cos(Math.toRadians(pitch));
            double dy = -Math.sin(Math.toRadians(pitch));
            double dz = Math.cos(Math.toRadians(yaw)) * Math.cos(Math.toRadians(pitch));

            Vec3d pos = start;
            Vec3d vel = new Vec3d(dx, dy, dz).multiply(velocity);

            List<Vec3d> points = new ArrayList<>();
            points.add(pos);

            for (int i = 0; i < 200; i++) {
                Vec3d next = pos.add(vel);
                BlockHitResult hit = mc.world.raycast(new RaycastContext(
                        pos, next, RaycastContext.ShapeType.COLLIDER,
                        RaycastContext.FluidHandling.NONE, mc.player));
                if (hit.getType() == HitResult.Type.BLOCK) {
                    points.add(hit.getPos());
                    break;
                }
                points.add(next);
                pos = next;
                vel = vel.multiply(drag).add(0, -gravity, 0);

                // Стоп если ушло слишком далеко
                if (next.distanceTo(start) > 200) break;
            }

            if (points.size() < 2) return;

            Vec3d cam = context.camera().getPos();
            MatrixStack matrices = context.matrixStack();
            VertexConsumerProvider.Immediate immediate = mc.getBufferBuilders().getEntityVertexConsumers();
            if (immediate == null) return;

            int color = tr.getColor();
            float a = ((color >> 24) & 0xFF) / 255f;
            float r = ((color >> 16) & 0xFF) / 255f;
            float g = ((color >> 8) & 0xFF) / 255f;
            float b = (color & 0xFF) / 255f;

            matrices.push();
            Matrix4f mat = matrices.peek().getPositionMatrix();
            VertexConsumer lineBuf = immediate.getBuffer(RenderLayer.getLines());

            for (int i = 0; i < points.size() - 1; i++) {
                Vec3d p1 = points.get(i).subtract(cam);
                Vec3d p2 = points.get(i + 1).subtract(cam);
                lineBuf.vertex(mat, (float)p1.x, (float)p1.y, (float)p1.z).color(r, g, b, a).normal(0f, 1f, 0f);
                lineBuf.vertex(mat, (float)p2.x, (float)p2.y, (float)p2.z).color(r, g, b, a).normal(0f, 1f, 0f);
            }
            immediate.draw();
            matrices.pop();
        });
    }
}
