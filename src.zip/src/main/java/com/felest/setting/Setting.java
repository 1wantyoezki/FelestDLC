package com.felest.setting;
import java.util.Arrays;
import java.util.List;
public class Setting {
    private final String name;
    private Object value;
    private final List<Object> options;
    public Setting(String name, Object defaultValue, Object... options) {
        this.name = name;
        this.value = defaultValue;
        this.options = Arrays.asList(options);
    }
    public String getName() { return name; }
    public Object getValue() { return value; }
    public void setValue(Object value) { this.value = value; }
    public List<Object> getOptions() { return options; }
    public boolean isMode() { return options.size() > 1; }
    public boolean isBoolean() { return value instanceof Boolean; }
    public boolean getBool() { return value instanceof Boolean && (Boolean) value; }
    public String getString() { return String.valueOf(value); }
    public void nextOption() {
        if (!isMode()) return;
        int idx = options.indexOf(value);
        if (idx == -1 || idx == options.size() - 1) {
            value = options.get(0);
        } else {
            value = options.get(idx + 1);
        }
    }
}
