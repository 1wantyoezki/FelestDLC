package com.felest.setting;
import java.util.Arrays;
import java.util.List;
public class Setting {
    private final String name;
    private Object value;
    private final List<Object> options;
    private float min = 0f;
    private float max = 1f;
    private float step = 0.1f;
    private boolean slider = false;
    public Setting(String name, Object defaultValue, Object... options) {
        this.name = name;
        this.value = defaultValue;
        this.options = Arrays.asList(options);
    }
    public Setting(String name, float defaultValue, float min, float max, float step) {
        this.name = name;
        this.value = defaultValue;
        this.options = Arrays.asList();
        this.min = min;
        this.max = max;
        this.step = step;
        this.slider = true;
    }
    public String getName() { return name; }
    public Object getValue() { return value; }
    public void setValue(Object value) { this.value = value; }
    public List<Object> getOptions() { return options; }
    public boolean isMode() { return options.size() > 1; }
    public boolean isBoolean() { return value instanceof Boolean; }
    public boolean isSlider() { return slider; }
    public float getFloat() { return value instanceof Float ? (Float) value : 0f; }
    public boolean getBool() { return value instanceof Boolean && (Boolean) value; }
    public String getString() { return String.valueOf(value); }
    public float getMin() { return min; }
    public float getMax() { return max; }
    public float getStep() { return step; }
    public void nextOption() {
        if (!isMode()) return;
        int idx = options.indexOf(value);
        if (idx == -1 || idx == options.size() - 1) value = options.get(0);
        else value = options.get(idx + 1);
    }
    public void setFromPercent(float percent) {
        if (!slider) return;
        float val = min + (max - min) * percent;
        val = Math.round(val / step) * step;
        val = Math.max(min, Math.min(max, val));
        value = val;
    }
}
