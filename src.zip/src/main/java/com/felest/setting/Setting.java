package com.felest.setting;

import java.util.ArrayList;
import java.util.List;

public class Setting {
    private final String name;
    private String value;
    private final List<String> options = new ArrayList<>();
    private boolean toggled;

    public Setting(String name, String defaultValue) {
        this.name = name;
        this.value = defaultValue;
    }

    public Setting(String name, String defaultValue, String... options) {
        this.name = name;
        this.value = defaultValue;
        for (String o : options) this.options.add(o);
    }

    public String getName() { return name; }
    public String getValue() { return value; }
    public List<String> getOptions() { return options; }
    public boolean isToggled() { return toggled; }

    public void setValue(String value) { this.value = value; }
    public void setToggled(boolean toggled) { this.toggled = toggled; }
    public void toggle() { this.toggled = !this.toggled; }

    public void next() {
        if (options.isEmpty()) return;
        int i = options.indexOf(value);
        if (i == -1 || i == options.size() - 1) value = options.get(0);
        else value = options.get(i + 1);
    }
}
