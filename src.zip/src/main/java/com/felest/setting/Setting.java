package com.felest.setting;

import java.util.Arrays;
import java.util.List;

public class Setting<T> {
    private final String name;
    private T value;
    private final List<T> options;
    private final T defaultValue;

    @SafeVarargs
    public Setting(String name, T defaultValue, T... options) {
        this.name = name;
        this.defaultValue = defaultValue;
        this.value = defaultValue;
        this.options = Arrays.asList(options);
    }

    public String getName() { return name; }
    public T getValue() { return value; }
    public void setValue(T value) { this.value = value; }
    public T getDefaultValue() { return defaultValue; }
    public List<T> getOptions() { return options; }
    public boolean isMode() { return options.size() > 1; }
    public boolean isBoolean() { return value instanceof Boolean; }

    public void nextOption() {
        if (!isMode()) return;
        int idx = options.indexOf(value);
        if (idx == -1 || idx == options.size() - 1) {
            value = options.get(0);
        } else {
            value = options.get(idx + 1);
        }
    }
}
