package com.felest.util;

import com.felest.FelestDLC;
import com.felest.module.Module;
import com.felest.module.impl.Hud;
import com.felest.setting.Setting;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final File CONFIG_FILE = new File(
            FabricLoader.getInstance().getConfigDir().toFile(), "felestdlc.json");

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Module m : FelestDLC.moduleManager.getModules()) {
                JsonObject mod = new JsonObject();
                mod.addProperty("enabled", m.isEnabled());
                mod.addProperty("keybind", m.getKeyBind());

                JsonObject settings = new JsonObject();
                for (Setting s : m.getSettings()) {
                    if (s.isBoolean()) settings.addProperty(s.getName(), s.getBool());
                    else if (s.isSlider()) settings.addProperty(s.getName(), s.getFloat());
                    else settings.addProperty(s.getName(), s.getString());
                }
                mod.add("settings", settings);

                if (m instanceof Hud) {
                    Hud h = (Hud) m;
                    JsonObject pos = new JsonObject();
                    pos.addProperty("watermarkX", h.watermarkX); pos.addProperty("watermarkY", h.watermarkY);
                    pos.addProperty("keybindsX", h.keybindsX);   pos.addProperty("keybindsY", h.keybindsY);
                    pos.addProperty("schedulesX", h.schedulesX); pos.addProperty("schedulesY", h.schedulesY);
                    pos.addProperty("targetX", h.targetX);       pos.addProperty("targetY", h.targetY);
                    pos.addProperty("bpsX", h.bpsX);             pos.addProperty("bpsY", h.bpsY);
                    mod.add("hudPos", pos);
                }
                root.add(m.getName(), mod);
            }
            CONFIG_FILE.getParentFile().mkdirs();
            FileWriter w = new FileWriter(CONFIG_FILE);
            GSON.toJson(root, w);
            w.close();
        } catch (Exception e) {
            System.out.println("[FelestDLC] Ошибка сохранения: " + e.getMessage());
        }
    }

    public static void load() {
        if (!CONFIG_FILE.exists()) return;
        try {
            FileReader r = new FileReader(CONFIG_FILE);
            JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
            r.close();

            for (Module m : FelestDLC.moduleManager.getModules()) {
                if (!root.has(m.getName())) continue;
                JsonObject mod = root.getAsJsonObject(m.getName());
                if (mod.has("enabled")) m.setEnabled(mod.get("enabled").getAsBoolean());
                if (mod.has("keybind")) m.setKeyBind(mod.get("keybind").getAsInt());
                if (mod.has("settings")) {
                    JsonObject st = mod.getAsJsonObject("settings");
                    for (Setting s : m.getSettings()) {
                        if (!st.has(s.getName())) continue;
                        if (s.isBoolean()) s.setValue(st.get(s.getName()).getAsBoolean());
                        else if (s.isSlider()) s.setValue(st.get(s.getName()).getAsFloat());
                        else s.setValue(st.get(s.getName()).getAsString());
                    }
                }
                if (m instanceof Hud && mod.has("hudPos")) {
                    Hud h = (Hud) m;
                    JsonObject p = mod.getAsJsonObject("hudPos");
                    if (p.has("watermarkX")) h.watermarkX = p.get("watermarkX").getAsFloat();
                    if (p.has("watermarkY")) h.watermarkY = p.get("watermarkY").getAsFloat();
                    if (p.has("keybindsX")) h.keybindsX = p.get("keybindsX").getAsFloat();
                    if (p.has("keybindsY")) h.keybindsY = p.get("keybindsY").getAsFloat();
                    if (p.has("schedulesX")) h.schedulesX = p.get("schedulesX").getAsFloat();
                    if (p.has("schedulesY")) h.schedulesY = p.get("schedulesY").getAsFloat();
                    if (p.has("targetX")) h.targetX = p.get("targetX").getAsFloat();
                    if (p.has("targetY")) h.targetY = p.get("targetY").getAsFloat();
                    if (p.has("bpsX")) h.bpsX = p.get("bpsX").getAsFloat();
                    if (p.has("bpsY")) h.bpsY = p.get("bpsY").getAsFloat();
                }
            }
        } catch (Exception e) {
            System.out.println("[FelestDLC] Ошибка загрузки: " + e.getMessage());
        }
    }
}
