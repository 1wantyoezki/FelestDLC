package com.felest.util;

import com.felest.FelestDLC;
import com.felest.module.Module;
import com.felest.module.impl.Hud;
import com.felest.setting.Setting;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final File CONFIG_FILE = new File(
            FabricLoader.getInstance().getConfigDir().toFile(), "felestdlc.json");

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Module m : FelestDLC.moduleManager.getModules()) {
                JsonObject mod = new JsonObject();
                mod.addProperty("enabled", m.isEnabled());
                mod.addProperty("keybind", m.getKeyBind());

                JsonObject settings = new JsonObject();
                for (Setting s : m.getSettings()) {
                    if (s.isBoolean()) settings.addProperty(s.getName(), s.getBool());
                    else if (s.isSlider()) settings.addProperty(s.getName(), s.getFloat());
                    else settings.addProperty(s.getName(), s.getString());
                }
                mod.add("settings", settings);

                // HUD позиции
                if (m instanceof Hud) {
                    Hud h = (Hud) m;
                    JsonObject pos = new JsonObject();
                    pos.addProperty("watermarkX", h.watermarkX);
                    pos.addProperty("watermarkY", h.watermarkY);
                    pos.addProperty("cooldownsX", h.cooldownsX);
                    pos.addProperty("cooldownsY", h.cooldownsY);
                    pos.addProperty("potionsX", h.potionsX);
                    pos.addProperty("potionsY", h.potionsY);
                    pos.addProperty("targetX", h.targetX);
                    pos.addProperty("targetY", h.targetY);
                    pos.addProperty("bpsX", h.bpsX);
                    pos.addProperty("bpsY", h.bpsY);
                    mod.add("hudPos", pos);
                }

                root.add(m.getName(), mod);
            }
            CONFIG_FILE.getParentFile().mkdirs();
            FileWriter w = new FileWriter(CONFIG_FILE);
            GSON.toJson(root, w);
            w.close();
            System.out.println("[FelestDLC] Config сохранён");
        } catch (Exception e) {
            System.out.println("[FelestDLC] Ошибка сохранения config: " + e.getMessage());
        }
    }

    public static void load() {
        if (!CONFIG_FILE.exists()) return;
        try {
            FileReader r = new FileReader(CONFIG_FILE);
            JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
            r.close();

            for (Module m : FelestDLC.moduleManager.getModules()) {
                if (!root.has(m.getName())) continue;
                JsonObject mod = root.getAsJsonObject(m.getName());

                if (mod.has("enabled")) m.setEnabled(mod.get("enabled").getAsBoolean());
                if (mod.has("keybind")) m.setKeyBind(mod.get("keybind").getAsInt());

                if (mod.has("settings")) {
                    JsonObject settings = mod.getAsJsonObject("settings");
                    for (Setting s : m.getSettings()) {
                        if (!settings.has(s.getName())) continue;
                        if (s.isBoolean()) s.setValue(settings.get(s.getName()).getAsBoolean());
                        else if (s.isSlider()) s.setValue(settings.get(s.getName()).getAsFloat());
                        else s.setValue(settings.get(s.getName()).getAsString());
                    }
                }

                if (m instanceof Hud && mod.has("hudPos")) {
                    Hud h = (Hud) m;
                    JsonObject pos = mod.getAsJsonObject("hudPos");
                    if (pos.has("watermarkX")) h.watermarkX = pos.get("watermarkX").getAsFloat();
                    if (pos.has("watermarkY")) h.watermarkY = pos.get("watermarkY").getAsFloat();
                    if (pos.has("cooldownsX")) h.cooldownsX = pos.get("cooldownsX").getAsFloat();
                    if (pos.has("cooldownsY")) h.cooldownsY = pos.get("cooldownsY").getAsFloat();
                    if (pos.has("potionsX")) h.potionsX = pos.get("potionsX").getAsFloat();
                    if (pos.has("potionsY")) h.potionsY = pos.get("potionsY").getAsFloat();
                    if (pos.has("targetX")) h.targetX = pos.get("targetX").getAsFloat();
                    if (pos.has("targetY")) h.targetY = pos.get("targetY").getAsFloat();
                    if (pos.has("bpsX")) h.bpsX = pos.get("bpsX").getAsFloat();
                    if (pos.has("bpsY")) h.bpsY = pos.get("bpsY").getAsFloat();
                }
            }
            System.out.println("[FelestDLC] Config загружен");
        } catch (Exception e) {
            System.out.println("[FelestDLC] Ошибка загрузки config: " + e.getMessage());
        }
    }
}
