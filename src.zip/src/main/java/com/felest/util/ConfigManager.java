package com.felest.util;

import com.felest.FelestDLC;
import com.felest.module.Module;
import com.felest.setting.Setting;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Map;

public class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final File CONFIG_FILE = new File(
            FabricLoader.getInstance().getConfigDir().toFile(), "felestdlc.json");

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Module m : FelestDLC.moduleManager.getModules()) {
                JsonObject mod = new JsonObject();
                mod.addProperty("enabled", m.isEnabled());
                mod.addProperty("keybind", m.getKeyBind());

                JsonObject settings = new JsonObject();
                for (Setting s : m.getSettings()) {
                    if (s.isBoolean()) settings.addProperty(s.getName(), s.getBool());
                    else if (s.isSlider()) settings.addProperty(s.getName(), s.getFloat());
                    else settings.addProperty(s.getName(), s.getString());
                }
                mod.add("settings", settings);
                root.add(m.getName(), mod);
            }
            CONFIG_FILE.getParentFile().mkdirs();
            FileWriter w = new FileWriter(CONFIG_FILE);
            GSON.toJson(root, w);
            w.close();
            System.out.println("[FelestDLC] Config сохранён");
        } catch (Exception e) {
            System.out.println("[FelestDLC] Ошибка сохранения config: " + e.getMessage());
        }
    }

    public static void load() {
        if (!CONFIG_FILE.exists()) return;
        try {
            FileReader r = new FileReader(CONFIG_FILE);
            JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
            r.close();

            for (Module m : FelestDLC.moduleManager.getModules()) {
                if (!root.has(m.getName())) continue;
                JsonObject mod = root.getAsJsonObject(m.getName());

                if (mod.has("enabled")) m.setEnabled(mod.get("enabled").getAsBoolean());
                if (mod.has("keybind")) m.setKeyBind(mod.get("keybind").getAsInt());

                if (mod.has("settings")) {
                    JsonObject settings = mod.getAsJsonObject("settings");
                    for (Setting s : m.getSettings()) {
                        if (!settings.has(s.getName())) continue;
                        if (s.isBoolean()) s.setValue(settings.get(s.getName()).getAsBoolean());
                        else if (s.isSlider()) s.setValue(settings.get(s.getName()).getAsFloat());
                        else s.setValue(settings.get(s.getName()).getAsString());
                    }
                }
            }
            System.out.println("[FelestDLC] Config загружен");
        } catch (Exception e) {
            System.out.println("[FelestDLC] Ошибка загрузки config: " + e.getMessage());
        }
    }
}
