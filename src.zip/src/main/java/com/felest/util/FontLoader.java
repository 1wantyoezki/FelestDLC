package com.felest.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;

import java.awt.Font;
import java.io.InputStream;

public class FontLoader {

    private static Font customFont;

    public static void load() {
        try {
            InputStream is = FontLoader.class.getResourceAsStream("/assets/felestdlc/font/font.ttf");
            if (is == null) {
                System.out.println("[FelestDLC] Шрифт не найден, используется стандартный.");
                return;
            }
            customFont = Font.createFont(Font.TRUETYPE_FONT, is).deriveFont(20f);
            System.out.println("[FelestDLC] Шрифт загружен!");
        } catch (Exception e) {
            System.out.println("[FelestDLC] Ошибка загрузки шрифта: " + e.getMessage());
        }
    }

    public static Font getFont() {
        return customFont != null ? customFont : new Font("Arial", Font.PLAIN, 20);
    }

    public static TextRenderer getRenderer() {
        return MinecraftClient.getInstance().textRenderer;
    }
}
