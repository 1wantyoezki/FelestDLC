package com.felest.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;
import java.awt.Font;
import java.io.InputStream;

public class FontLoader {
    public static Font inter = null;
    private static boolean loaded = false;

    public static Font getFont() {
        if (loaded && inter != null) return inter;
        loaded = true;
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc == null) throw new Exception("mc null");
            Identifier id = Identifier.of("felestdlc", "font/inter-bold.ttf");
            InputStream is = mc.getResourceManager().getResource(id).get().getInputStream();
            inter = Font.createFont(Font.TRUETYPE_FONT, is).deriveFont(18f);
            is.close();
            System.out.println("[FelestDLC] Шрифт Inter загружен!");
        } catch (Exception e) {
            System.out.println("[FelestDLC] Шрифт не загружен, fallback Arial: " + e.getMessage());
            inter = new Font("Arial", Font.BOLD, 18);
        }
        return inter;
    }

    // Оставляем для совместимости со старым кодом
    public static void load() {
        // теперь грузится лениво
    }
}
