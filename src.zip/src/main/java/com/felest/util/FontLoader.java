package com.felest.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;
import java.awt.Font;
import java.io.InputStream;

public class FontLoader {
    public static Font rubik;

    public static void load() {
        try {
            Identifier id = Identifier.of("felestdlc", "font/inter-bold.ttf");
            InputStream is = MinecraftClient.getInstance().getResourceManager().getResource(id).get().getInputStream();
            rubik = Font.createFont(Font.TRUETYPE_FONT, is).deriveFont(18f);
            is.close();
            System.out.println("[FelestDLC] Шрифт Inter загружен!");
        } catch (Exception e) {
            System.out.println("[FelestDLC] Ошибка загрузки шрифта: " + e.getMessage());
            rubik = new Font("Arial", Font.BOLD, 18);
        }
    }
}
