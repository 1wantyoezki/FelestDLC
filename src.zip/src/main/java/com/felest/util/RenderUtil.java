package com.felest.util;

import net.minecraft.client.gui.DrawContext;

public class RenderUtil {
    private static final int SS = 20;

    public static void roundedRect(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        if (r > w / 2) r = w / 2;
        if (r > h / 2) r = h / 2;
        if (r < 1) { ctx.fill(x, y, x + w, y + h, color); return; }

        int a = (color >> 24) & 0xFF;
        int rr = (color >> 16) & 0xFF;
        int gg = (color >> 8) & 0xFF;
        int bb = color & 0xFF;

        ctx.fill(x + r, y, x + w - r, y + h, color);
        ctx.fill(x, y + r, x + r, y + h - r, color);
        ctx.fill(x + w - r, y + r, x + w, y + h - r, color);

        double rSq = (double) r * r;
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < r; j++) {
                int count = 0;
                for (int si = 0; si < SS; si++) {
                    for (int sj = 0; sj < SS; sj++) {
                        double dx = r - (i + (si + 0.5) / SS);
                        double dy = r - (j + (sj + 0.5) / SS);
                        if (dx * dx + dy * dy <= rSq) count++;
                    }
                }
                int alpha = (int) Math.round((double) count / (SS * SS) * a);
                if (alpha <= 0) continue;
                int c = (alpha << 24) | (rr << 16) | (gg << 8) | bb;
                ctx.fill(x + i, y + j, x + i + 1, y + j + 1, c);
                ctx.fill(x + w - i - 1, y + j, x + w - i, y + j + 1, c);
                ctx.fill(x + i, y + h - j - 1, x + i + 1, y + h - j, c);
                ctx.fill(x + w - i - 1, y + h - j - 1, x + w - i, y + h - j, c);
            }
        }
    }

    public static void gradientRectV(DrawContext ctx, int x, int y, int w, int h, int top, int bottom) {
        int ta = (top >> 24) & 0xFF, tr = (top >> 16) & 0xFF, tg = (top >> 8) & 0xFF, tb = top & 0xFF;
        int ba = (bottom >> 24) & 0xFF, br = (bottom >> 16) & 0xFF, bg = (bottom >> 8) & 0xFF, bb = bottom & 0xFF;
        for (int i = 0; i < h; i++) {
            float t = (float) i / (h - 1);
            int a = (int)(ta + (ba - ta) * t);
            int r = (int)(tr + (br - tr) * t);
            int g = (int)(tg + (bg - tg) * t);
            int b = (int)(tb + (bb - tb) * t);
            ctx.fill(x, y + i, x + w, y + i + 1, (a << 24) | (r << 16) | (g << 8) | b);
        }
    }

    public static void roundedGradient(DrawContext ctx, int x, int y, int w, int h, int r, int top, int bottom) {
        if (r > w / 2) r = w / 2;
        if (r > h / 2) r = h / 2;
        if (r < 1) { gradientRectV(ctx, x, y, w, h, top, bottom); return; }

        int ta = (top >> 24) & 0xFF, tr = (top >> 16) & 0xFF, tg = (top >> 8) & 0xFF, tb = top & 0xFF;
        int ba = (bottom >> 24) & 0xFF, br = (bottom >> 16) & 0xFF, bg = (bottom >> 8) & 0xFF, bb = bottom & 0xFF;

        gradientRectV(ctx, x + r, y, w - 2 * r, h, top, bottom);
        ctx.fill(x, y + r, x + r, y + h - r, top);
        ctx.fill(x + w - r, y + r, x + w, y + h - r, top);

        double rSq = (double) r * r;
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < r; j++) {
                int count = 0;
                for (int si = 0; si < SS; si++) {
                    for (int sj = 0; sj < SS; sj++) {
                        double dx = r - (i + (si + 0.5) / SS);
                        double dy = r - (j + (sj + 0.5) / SS);
                        if (dx * dx + dy * dy <= rSq) count++;
                    }
                }
                int ca = (int) Math.round((double) count / (SS * SS) * ta);
                int cb = (int) Math.round((double) count / (SS * SS) * ba);
                if (ca <= 0) continue;
                int cTop = (ca << 24) | (tr << 16) | (tg << 8) | tb;
                ctx.fill(x + i, y + j, x + i + 1, y + j + 1, cTop);
                ctx.fill(x + w - i - 1, y + j, x + w - i, y + j + 1, cTop);
                int cBot = (cb << 24) | (br << 16) | (bg << 8) | bb;
                ctx.fill(x + i, y + h - j - 1, x + i + 1, y + h - j, cBot);
                ctx.fill(x + w - i - 1, y + h - j - 1, x + w - i, y + h - j, cBot);
            }
        }
    }

    public static void shadow(DrawContext ctx, int x, int y, int w, int h, int r) {
        for (int s = 6; s >= 1; s--) {
            int alpha = 8 + (6 - s) * 4;
            int color = (alpha << 24);
            roundedRect(ctx, x - s, y - s + 2, w + s * 2, h + s * 2, r + s, color);
        }
    }

    public static void roundedOutline(DrawContext ctx, int x, int y, int w, int h, int r, int color, int thickness) {
        if (r > w / 2) r = w / 2;
        if (r > h / 2) r = h / 2;
        if (r < 1) return;

        ctx.fill(x + r, y, x + w - r, y + thickness, color);
        ctx.fill(x + r, y + h - thickness, x + w - r, y + h, color);
        ctx.fill(x, y + r, x + thickness, y + h - r, color);
        ctx.fill(x + w - thickness, y + r, x + w, y + h - r, color);

        int a = (color >> 24) & 0xFF;
        int rr = (color >> 16) & 0xFF, gg = (color >> 8) & 0xFF, bb = color & 0xFF;
        double rOut = r, rIn = r - thickness;
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < r; j++) {
                int count = 0;
                for (int si = 0; si < SS; si++) {
                    for (int sj = 0; sj < SS; sj++) {
                        double dx = r - (i + (si + 0.5) / SS);
                        double dy = r - (j + (sj + 0.5) / SS);
                        double d2 = dx * dx + dy * dy;
                        if (d2 <= rOut * rOut && d2 >= rIn * rIn) count++;
                    }
                }
                int alpha = (int) Math.round((double) count / (SS * SS) * a);
                if (alpha <= 0) continue;
                int c = (alpha << 24) | (rr << 16) | (gg << 8) | bb;
                ctx.fill(x + i, y + j, x + i + 1, y + j + 1, c);
                ctx.fill(x + w - i - 1, y + j, x + w - i, y + j + 1, c);
                ctx.fill(x + i, y + h - j - 1, x + i + 1, y + h - j, c);
                ctx.fill(x + w - i - 1, y + h - j - 1, x + w - i, y + h - j, c);
            }
        }
    }

    public static void smoothLine(DrawContext ctx, float x1, float y1, float x2, float y2, float thickness, int color) {
        int a = (color >> 24) & 0xFF;
        int rr = (color >> 16) & 0xFF, gg = (color >> 8) & 0xFF, bb = color & 0xFF;
        float dx = x2 - x1, dy = y2 - y1;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 0.001f) return;
        float lenSq = len * len;
        int minX = (int) Math.floor(Math.min(x1, x2) - thickness - 1);
        int maxX = (int) Math.ceil(Math.max(x1, x2) + thickness + 1);
        int minY = (int) Math.floor(Math.min(y1, y2) - thickness - 1);
        int maxY = (int) Math.ceil(Math.max(y1, y2) + thickness + 1);

        for (int px = minX; px <= maxX; px++) {
            for (int py = minY; py <= maxY; py++) {
                int count = 0;
                for (int si = 0; si < SS; si++) {
                    for (int sj = 0; sj < SS; sj++) {
                        float sx = px + (si + 0.5f) / SS;
                        float sy = py + (sj + 0.5f) / SS;
                        float t = ((sx - x1) * dx + (sy - y1) * dy) / lenSq;
                        if (t < 0) t = 0;
                        if (t > 1) t = 1;
                        float cx = x1 + dx * t, cy = y1 + dy * t;
                        float ddx = sx - cx, ddy = sy - cy;
                        if (ddx * ddx + ddy * ddy <= thickness * thickness) count++;
                    }
                }
                int alpha = (int) Math.round((double) count / (SS * SS) * a);
                if (alpha <= 0) continue;
                int c = (alpha << 24) | (rr << 16) | (gg << 8) | bb;
                ctx.fill(px, py, px + 1, py + 1, c);
            }
        }
    }

    public static void circle(DrawContext ctx, float cx, float cy, float radius, int color) {
        int a = (color >> 24) & 0xFF;
        int rr = (color >> 16) & 0xFF, gg = (color >> 8) & 0xFF, bb = color & 0xFF;
        int minX = (int) Math.floor(cx - radius - 1);
        int maxX = (int) Math.ceil(cx + radius + 1);
        int minY = (int) Math.floor(cy - radius - 1);
        int maxY = (int) Math.ceil(cy + radius + 1);
        double rSq = radius * radius;
        for (int px = minX; px <= maxX; px++) {
            for (int py = minY; py <= maxY; py++) {
                int count = 0;
                for (int si = 0; si < SS; si++) {
                    for (int sj = 0; sj < SS; sj++) {
                        double sx = px + (si + 0.5) / SS - cx;
                        double sy = py + (sj + 0.5) / SS - cy;
                        if (sx * sx + sy * sy <= rSq) count++;
                    }
                }
                int alpha = (int) Math.round((double) count / (SS * SS) * a);
                if (alpha <= 0) continue;
                int c = (alpha << 24) | (rr << 16) | (gg << 8) | bb;
                ctx.fill(px, py, px + 1, py + 1, c);
            }
        }
    }

    public static int withAlpha(int color, int alpha) {
        return (alpha << 24) | (color & 0x00FFFFFF);
    }
}
