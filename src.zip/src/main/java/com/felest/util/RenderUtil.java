package com.felest.util;

import net.minecraft.client.gui.DrawContext;

public class RenderUtil {

    // Закруглённый прямоугольник с плотным SSAA (8x8 подпикселей на границе)
    public static void roundedRect(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        if (r > w / 2) r = w / 2;
        if (r > h / 2) r = h / 2;
        if (r < 1) r = 1;

        int a = (color >> 24) & 0xFF;
        int rr = (color >> 16) & 0xFF;
        int gg = (color >> 8) & 0xFF;
        int bb = color & 0xFF;

        // Основные прямоугольники (без углов)
        ctx.fill(x + r, y, x + w - r, y + h, color);              // центральная часть
        ctx.fill(x, y + r, x + r, y + h - r, color);              // левая полоса
        ctx.fill(x + w - r, y + r, x + w, y + h - r, color);      // правая полоса

        // Углы — supersampling
        final int SS = 8; // 8x8 = 64 подпикселя на каждый пиксель угла
        double rSq = (double) r * r;

        for (int i = 0; i < r; i++) {
            for (int j = 0; j < r; j++) {
                int count = 0;
                for (int si = 0; si < SS; si++) {
                    for (int sj = 0; sj < SS; sj++) {
                        double dx = r - (i + (si + 0.5) / SS);
                        double dy = r - (j + (sj + 0.5) / SS);
                        if (dx * dx + dy * dy <= rSq) count++;
                    }
                }
                int alpha = (int) ((double) count / (SS * SS) * a + 0.5);
                if (alpha <= 0) continue;
                int c = (alpha << 24) | (rr << 16) | (gg << 8) | bb;

                // 4 угла
                ctx.fill(x + i, y + j, x + i + 1, y + j + 1, c);                                  // top-left
                ctx.fill(x + w - i - 1, y + j, x + w - i, y + j + 1, c);                          // top-right
                ctx.fill(x + i, y + h - j - 1, x + i + 1, y + h - j, c);                          // bottom-left
                ctx.fill(x + w - i - 1, y + h - j - 1, x + w - i, y + h - j, c);                  // bottom-right
            }
        }
    }

    // Обводка (толстый контур)
    public static void roundedOutline(DrawContext ctx, int x, int y, int w, int h, int r, int color, int thickness) {
        if (r > w / 2) r = w / 2;
        if (r > h / 2) r = h / 2;
        if (r < 1) r = 1;

        // Прямые части
        ctx.fill(x + r, y, x + w - r, y + thickness, color);                     // top
        ctx.fill(x + r, y + h - thickness, x + w - r, y + h, color);             // bottom
        ctx.fill(x, y + r, x + thickness, y + h - r, color);                     // left
        ctx.fill(x + w - thickness, y + r, x + w, y + h - r, color);             // right

        int a = (color >> 24) & 0xFF;
        int rr = (color >> 16) & 0xFF;
        int gg = (color >> 8) & 0xFF;
        int bb = color & 0xFF;

        final int SS = 8;
        double rOuter = r;
        double rInner = r - thickness;

        for (int i = 0; i < r; i++) {
            for (int j = 0; j < r; j++) {
                int count = 0;
                for (int si = 0; si < SS; si++) {
                    for (int sj = 0; sj < SS; sj++) {
                        double dx = r - (i + (si + 0.5) / SS);
                        double dy = r - (j + (sj + 0.5) / SS);
                        double distSq = dx * dx + dy * dy;
                        if (distSq <= rOuter * rOuter && distSq >= rInner * rInner) count++;
                    }
                }
                int alpha = (int) ((double) count / (SS * SS) * a + 0.5);
                if (alpha <= 0) continue;
                int c = (alpha << 24) | (rr << 16) | (gg << 8) | bb;

                ctx.fill(x + i, y + j, x + i + 1, y + j + 1, c);
                ctx.fill(x + w - i - 1, y + j, x + w - i, y + j + 1, c);
                ctx.fill(x + i, y + h - j - 1, x + i + 1, y + h - j, c);
                ctx.fill(x + w - i - 1, y + h - j - 1, x + w - i, y + h - j, c);
            }
        }
    }
}
