package com.felest.util;

import net.minecraft.client.gui.DrawContext;

public class RenderUtil {

    // Закруглённый прямоугольник с антиалиасингом
    public static void roundedRect(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        // Ограничиваем радиус
        if (r > w / 2) r = w / 2;
        if (r > h / 2) r = h / 2;

        int a = (color >> 24) & 0xFF;
        int rr = (color >> 16) & 0xFF;
        int gg = (color >> 8) & 0xFF;
        int bb = color & 0xFF;

        // Основные прямоугольники (без углов)
        ctx.fill(x + r, y, x + w - r, y + h, color);            // центр
        ctx.fill(x, y + r, x + r, y + h - r, color);            // левая полоса
        ctx.fill(x + w - r, y + r, x + w, y + h - r, color);    // правая полоса

        // Углы — дуги с антиалиасингом
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < r; j++) {
                double dx = r - i - 0.5;
                double dy = r - j - 0.5;
                double dist = Math.sqrt(dx * dx + dy * dy);

                // Плавный переход
                int alpha;
                if (dist <= r - 1.0) alpha = 255;
                else if (dist >= r) alpha = 0;
                else alpha = (int) ((r - dist) * 255);

                if (alpha <= 0) continue;

                int c = ((alpha * a / 255) << 24) | (rr << 16) | (gg << 8) | bb;

                // Верх-лево
                ctx.fill(x + i, y + j, x + i + 1, y + j + 1, c);
                // Верх-право
                ctx.fill(x + w - i - 1, y + j, x + w - i, y + j + 1, c);
                // Низ-лево
                ctx.fill(x + i, y + h - j - 1, x + i + 1, y + h - j, c);
                // Низ-право
                ctx.fill(x + w - i - 1, y + h - j - 1, x + w - i, y + h - j, c);
            }
        }
    }

    // Обводка (контур) закруглённого прямоугольника
    public static void roundedOutline(DrawContext ctx, int x, int y, int w, int h, int r, int color, int thickness) {
        if (r > w / 2) r = w / 2;
        if (r > h / 2) r = h / 2;

        // Прямые части
        // Верх
        ctx.fill(x + r, y, x + w - r, y + thickness, color);
        // Низ
        ctx.fill(x + r, y + h - thickness, x + w - r, y + h, color);
        // Лево
        ctx.fill(x, y + r, x + thickness, y + h - r, color);
        // Право
        ctx.fill(x + w - thickness, y + r, x + w, y + h - r, color);

        // Углы — дуги
        int a = (color >> 24) & 0xFF;
        int rr = (color >> 16) & 0xFF;
        int gg = (color >> 8) & 0xFF;
        int bb = color & 0xFF;

        for (int i = 0; i < r; i++) {
            for (int j = 0; j < r; j++) {
                double dx = r - i - 0.5;
                double dy = r - j - 0.5;
                double dist = Math.sqrt(dx * dx + dy * dy);

                if (dist > r || dist < r - thickness) continue;

                int alpha;
                if (dist <= r - 0.5) alpha = 255;
                else if (dist >= r) alpha = 0;
                else alpha = (int) ((r - dist) * 255);

                int c = ((alpha * a / 255) << 24) | (rr << 16) | (gg << 8) | bb;

                ctx.fill(x + i, y + j, x + i + 1, y + j + 1, c);
                ctx.fill(x + w - i - 1, y + j, x + w - i, y + j + 1, c);
                ctx.fill(x + i, y + h - j - 1, x + i + 1, y + h - j, c);
                ctx.fill(x + w - i - 1, y + h - j - 1, x + w - i, y + h - j, c);
            }
        }
    }
}
