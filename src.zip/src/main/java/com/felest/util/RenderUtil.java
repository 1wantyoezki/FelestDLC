package com.felest.util;

import net.minecraft.client.gui.DrawContext;

public class RenderUtil {
    private static final int SS = 20;

    public static void roundedRect(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        if (r > w / 2) r = w / 2;
        if (r > h / 2) r = h / 2;
        if (r < 1) { ctx.fill(x, y, x + w, y + h, color); return; }

        int a = (color >> 24) & 0xFF;
        int rr = (color >> 16) & 0xFF;
        int gg = (color >> 8) & 0xFF;
        int bb = color & 0xFF;

        ctx.fill(x + r, y, x + w - r, y + h, color);
        ctx.fill(x, y + r, x + r, y + h - r, color);
        ctx.fill(x + w - r, y + r, x + w, y + h - r, color);

        double rSq = (double) r * r;
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < r; j++) {
                int count = 0;
                for (int si = 0; si < SS; si++) {
                    for (int sj = 0; sj < SS; sj++) {
                        double dx = r - (i + (si + 0.5) / SS);
                        double dy = r - (j + (sj + 0.5) / SS);
                        if (dx * dx + dy * dy <= rSq) count++;
                    }
                }
                int alpha = (int) Math.round((double) count / (SS * SS) * a);
                if (alpha <= 0) continue;
                int c = (alpha << 24) | (rr << 16) | (gg << 8) | bb;
                ctx.fill(x + i, y + j, x + i + 1, y + j + 1, c);
                ctx.fill(x + w - i - 1, y + j, x + w - i, y + j + 1, c);
                ctx.fill(x + i, y + h - j - 1, x + i + 1, y + h - j, c);
                ctx.fill(x + w - i - 1, y + h - j - 1, x + w - i, y + h - j, c);
            }
        }
    }

    public static void gradientRectV(DrawContext ctx, int x, int y, int w, int h, int top, int bottom) {
        int ta = (top >> 24) & 0xFF, tr = (top >> 16) & 0xFF, tg = (top >> 8) & 0xFF, tb = top & 0xFF;
        int ba = (bottom >> 24) & 0xFF, br = (bottom >> 16) & 0xFF, bg = (bottom >> 8) & 0xFF, bb = bottom & 0xFF;
        for (int i = 0; i < h; i++) {
            float t = (float) i / (h - 1);
            int a = (int)(ta + (ba - ta) * t);
            int r = (int)(tr + (br - tr) * t);
            int g = (int)(tg + (bg - tg) * t);
            int b = (int)(tb + (bb - tb) * t);
            ctx.fill(x, y + i, x + w, y + i + 1, (a << 24) | (r << 16) | (g << 8) | b);
        }
    }

    public static void roundedGradient(DrawContext ctx, int x, int y, int w, int h, int r, int top, int bottom) {
        if (r > w / 2) r = w / 2;
        if (r > h / 2) r = h / 2;
        if (r < 1) { gradientRectV(ctx, x, y, w, h, top, bottom); return; }

        int ta = (top >> 24) & 0xFF, tr = (top >> 16) & 0xFF, tg = (top >> 8) & 0xFF, tb = top & 0xFF;
        int ba = (bottom >> 24) & 0xFF, br = (bottom >> 16) & 0xFF, bg = (bottom >> 8) & 0xFF, bb = bottom & 0xFF;

        gradientRectV(ctx, x + r, y, w - 2 * r, h, top, bottom);
        ctx.fill(x, y + r, x + r, y + h - r, top);
        ctx.fill(x + w - r, y + r, x + w, y + h - r, top);

        double rSq = (double) r * r;
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < r; j++) {
                int count = 0;
                for (int si = 0; si < SS; si++) {
                    for (int sj = 0; sj < SS; sj++) {
                        double dx = r - (i + (si + 0.5) / SS);
                        double dy = r - (j + (sj + 0.5) / SS);
                        if (dx * dx + dy * dy <= rSq) count++;
                    }
                }
                int ca = (int) Math.round((double) count / (SS * SS) * ta);
                int cb = (int) Math.round((double) count / (SS * SS) * ba);
                if (ca <= 0) continue;
                int cTop = (ca << 24) | (tr << 16) | (tg << 8) | tb;
                ctx.fill(x + i, y + j, x + i + 1, y + j + 1, cTop);
                ctx.fill(x + w - i - 1, y + j, x + w - i, y + j + 1, cTop);
                int cBot = (cb << 24) | (br << 16) | (bg << 8) | bb;
                ctx.fill(x + i, y + h - j - 1, x + i + 1, y + h - j, cBot);
                ctx.fill(x + w - i - 1, y + h - j - 1, x + w - i, y + h - j, cBot);
            }
        }
    }

    public static void shadow(DrawContext ctx, int x, int y, int w, int h, int r) {
        for (int s = 6; s >= 1; s--) {
            int alpha = 8 + (6 - s) * 4;
            int color = (alpha << 24);
            roundedRect(ctx, x - s, y - s + 2, w + s * 2, h + s * 2, r + s, color);
        }
    }

    public static void roundedOutline(DrawContext ctx, int x, int y, int w, int h, int r, int color, int thickness) {
        if (r > w / 2) r = w / 2;
        if (r > h / 2) r = h / 2;
        if (r < 1) return;

        ctx.fill(x + r, y, x + w - r, y + thickness, color);
        ctx.fill(x + r, y + h - thickness, x + w - r, y + h, color);
        ctx.fill(x, y + r, x + thickness, y + h - r, color);
        ctx.fill(x + w - thickness, y + r, x + w, y + h - r, color);

        int a = (color >> 24) & 0xFF;
        int rr = (color >> 16) & 0xFF, gg = (color >> 8) & 0xFF, bb = color & 0xFF;
        double rOut = r, rIn = r - thickness;
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < r; j++) {
                int count = 0;
                for (int si = 0; si < SS; si++) {
                    for (int sj = 0; sj < SS; sj++) {
                        double dx = r - (i + (si + 0.5) / SS);
                        double dy = r - (j + (sj + 0.5) / SS);
                        double d2 = dx * dx + dy * dy;
                        if (d2 <= rOut * rOut && d2 >= rIn * rIn) count++;
                    }
                }
                int alpha = (int) Math.round((double) count / (SS * SS) * a);
                if (alpha <= 0) continue;
                int c = (alpha << 24) | (rr << 16) | (gg << 8) | bb;
                ctx.fill(x + i, y + j, x + i + 1, y + j + 1, c);
                ctx.fill(x + w - i - 1, y + j, x + w - i, y + j + 1, c);
                ctx.fill(x + i, y + h - j - 1, x + i + 1, y + h - j, c);
                ctx.fill(x + w - i - 1, y + h - j - 1, x + w - i, y + h - j, c);
            }
        }
    }

    // ===== ПЛАВНАЯ ЛИНИЯ — через расстояние (быстрее и ровнее чем SS) =====
    public static void smoothLine(DrawContext ctx, float x1, float y1, float x2, float y2, float thickness, int color) {
        float dx = x2 - x1, dy = y2 - y1;
        float lenSq = dx * dx + dy * dy;
        if (lenSq < 0.0001f) return;

        float halfThick = thickness * 0.5f;
        float aa = 0.8f; // ширина антиалиасинга

        int minX = (int) Math.floor(Math.min(x1, x2) - halfThick - aa);
        int maxX = (int) Math.ceil(Math.max(x1, x2) + halfThick + aa);
        int minY = (int) Math.floor(Math.min(y1, y2) - halfThick - aa);
        int maxY = (int) Math.ceil(Math.max(y1, y2) + halfThick + aa);

        int a = (color >> 24) & 0xFF;
        int rr = (color >> 16) & 0xFF, gg = (color >> 8) & 0xFF, bb = color & 0xFF;

        for (int py = minY; py <= maxY; py++) {
            for (int px = minX; px <= maxX; px++) {
                float cx = px + 0.5f;
                float cy = py + 0.5f;
                float t = ((cx - x1) * dx + (cy - y1) * dy) / lenSq;
                if (t < 0) t = 0;
                if (t > 1) t = 1;
                float projX = x1 + dx * t;
                float projY = y1 + dy * t;
                float ddx = cx - projX, ddy = cy - projY;
                float dist = (float) Math.sqrt(ddx * ddx + ddy * ddy);

                float alpha;
                if (dist <= halfThick) alpha = 1.0f;
                else if (dist >= halfThick + aa) alpha = 0.0f;
                else alpha = (halfThick + aa - dist) / aa;

                int ai = (int) (alpha * a);
                if (ai <= 0) continue;
                int c = (ai << 24) | (rr << 16) | (gg << 8) | bb;
                ctx.fill(px, py, px + 1, py + 1, c);
            }
        }
    }

    public static void circle(DrawContext ctx, float cx, float cy, float radius, int color) {
        int a = (color >> 24) & 0xFF;
        int rr = (color >> 16) & 0xFF, gg = (color >> 8) & 0xFF, bb = color & 0xFF;
        int minX = (int) Math.floor(cx - radius - 1);
        int maxX = (int) Math.ceil(cx + radius + 1);
        int minY = (int) Math.floor(cy - radius - 1);
        int maxY = (int) Math.ceil(cy + radius + 1);
        double rSq = radius * radius;
        float aa = 0.7f;
        for (int px = minX; px <= maxX; px++) {
            for (int py = minY; py <= maxY; py++) {
                double sx = px + 0.5 - cx;
                double sy = py + 0.5 - cy;
                double dist = Math.sqrt(sx * sx + sy * sy);
                float alpha;
                if (dist <= radius - aa) alpha = 1.0f;
                else if (dist >= radius + aa) alpha = 0.0f;
                else alpha = (float)((radius + aa - dist) / (2 * aa));
                int ai = (int) (alpha * a);
                if (ai <= 0) continue;
                int c = (ai << 24) | (rr << 16) | (gg << 8) | bb;
                ctx.fill(px, py, px + 1, py + 1, c);
            }
        }
    }

    public static int withAlpha(int color, int alpha) {
        return (alpha << 24) | (color & 0x00FFFFFF);
    }
}
