package com.felest.util;

import java.awt.Color;

public class Theme {
    public static String current = "Фиолетовый";

    public static final String[] COLORS = {"Синий", "Фиолетовый", "Зелёный", "Жёлтый", "Оранжевый", "Серый", "Белый"};

    public static int getAccent() {
        switch (current) {
            case "Синий":      return new Color(60, 120, 220).getRGB();
            case "Фиолетовый": return new Color(160, 60, 220).getRGB();
            case "Зелёный":    return new Color(60, 200, 100).getRGB();
            case "Жёлтый":     return new Color(230, 210, 60).getRGB();
            case "Оранжевый":  return new Color(240, 140, 40).getRGB();
            case "Серый":      return new Color(150, 150, 160).getRGB();
            case "Белый":      return new Color(240, 240, 240).getRGB();
            default:           return new Color(160, 60, 220).getRGB();
        }
    }

    public static int getColorByName(String name) {
        switch (name) {
            case "Синий":      return new Color(60, 120, 220).getRGB();
            case "Фиолетовый": return new Color(160, 60, 220).getRGB();
            case "Зелёный":    return new Color(60, 200, 100).getRGB();
            case "Жёлтый":     return new Color(230, 210, 60).getRGB();
            case "Оранжевый":  return new Color(240, 140, 40).getRGB();
            case "Серый":      return new Color(150, 150, 160).getRGB();
            case "Белый":      return new Color(240, 240, 240).getRGB();
            default:           return new Color(160, 60, 220).getRGB();
        }
    }
}
