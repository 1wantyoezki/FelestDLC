package ru.argentoz.launcher;

import celestial.rrzL_2;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import javax.crypto.NoSuchPaddingException;

public class Launcher {
   public static void main(String[] var0) throws NoSuchPaddingException, NoSuchAlgorithmException, IOException, NoSuchFieldException, InvalidKeyException, IllegalAccessException {
      rrzL_2.id_class(var0);
   }
}
