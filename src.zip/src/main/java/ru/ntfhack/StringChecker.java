package ru.ntfhack;

public final class StringChecker {
   private static final int[] hashTable = new int[16];
   private static final String[] stringTable = new String[16];

   private static void detect() {
   }

   public static void init(String... ignored) {
   }

   private static void lambda$init$0() {
   }
}
